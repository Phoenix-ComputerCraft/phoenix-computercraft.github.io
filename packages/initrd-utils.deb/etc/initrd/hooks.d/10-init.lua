local a=[==[
print("initrd: init running")
]==]if config.hook_preflight then for b,c in ipairs(config.hook_preflight)do a=a..'print("initrd: running hook '..c..'")\ndofile("'..c..'")\n'end end;a=a..[==[
print("initrd: mounting root filesystem")
local _, args = coroutine.yield("syscall", "kernargs")
local options = {}
if args.rootflags then
    for m in args.rootflags:gmatch "[^,]+" do
        local k, v = m:match("^([^=]+)=(.*)$")
        if k and v then
            if v == "true" then options[k] = true
            elseif v == "false" then options[k] = false
            else options[k] = tonumber(v) or v end
        else options[m] = true end
    end
end
coroutine.yield("syscall", "unmount", "/")
local ok, err = coroutine.yield("syscall", "mount", args.rootfstype or "craftos", args.root, "/", options)
if not ok then
    coroutine.yield("syscall", "syslog", {module = "initrd", level = 6}, "initrd: could not mount root device: " .. err .. "\n")
    while true do coroutine.yield() end
    return false
end
-- TODO: reopen log file
]==]if config.hook_postflight then for b,c in ipairs(config.hook_postflight)do a=a..'print("initrd: running hook '..c..'")\ndofile("'..c..'")\n'end end;a=a..[==[
print("initrd: starting real init")
if args.init then coroutine.yield("syscall", "exec", args.init) end
print("Could not find provided init, trying default locations")
coroutine.yield("syscall", "exec", "/sbin/init")
coroutine.yield("syscall", "exec", "/etc/init")
coroutine.yield("syscall", "exec", "/bin/init")
coroutine.yield("syscall", "exec", "/bin/sh")
io.stderr:write("initrd: no working init found")
return false
]==]local d=assert(io.open(rootDirectory.."/init.lua","w"))d:write(a)d:close()
