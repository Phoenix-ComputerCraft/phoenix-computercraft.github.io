/** @noSelfInFile **/
/** @noResolution **/
declare module "muxzcat" {
    export function DecompressXzOrLzmaFile(input: string|LuaFile, output: string|LuaFile): LuaMultiReturn<[boolean, number]>;
    export function DecompressXzOrLzmaString(input: string): LuaMultiReturn<[string, number|null] | [null, number]>;
    export function GetError(err: number): string|null;
    export const Errors: {
        UNKNOWN_ERROR: number,
        OK: number,
        ERROR_DATA: number,
        ERROR_MEM: number,
        ERROR_CRC: number,
        ERROR_UNSUPPORTED: number,
        ERROR_PARAM: number,
        ERROR_INPUT_EOF: number,
        ERROR_OUTPUT_EOF: number,
        ERROR_READ: number,
        ERROR_WRITE: number,
        ERROR_FINISHED_WITH_MARK: number,
        ERROR_NOT_FINISHED: number,
        ERROR_NEEDS_MORE_INPUT: number,
        ERROR_CHUNK_NOT_CONSUMED: number,
        ERROR_NEEDS_MORE_INPUT_PARTIAL: number,
        ERROR_BAD_MAGIC: number,
        ERROR_BAD_STREAM_FLAGS: number,
        ERROR_UNSUPPORTED_FILTER_COUNT: number,
        ERROR_BAD_BLOCK_FLAGS: number,
        ERROR_UNSUPPORTED_FILTER_ID: number,
        ERROR_UNSUPPORTED_FILTER_PROPERTIES_SIZE: number,
        ERROR_BAD_PADDING: number,
        ERROR_BLOCK_HEADER_TOO_LONG: number,
        ERROR_BAD_CHUNK_CONTROL_BYTE: number,
        ERROR_BAD_CHECKSUM_TYPE: number,
        ERROR_BAD_DICTIONARY_SIZE: number,
        ERROR_UNSUPPORTED_DICTIONARY_SIZE: number,
        ERROR_FEED_CHUNK: number,
        ERROR_NOT_FINISHED_WITH_MARK: number,
        ERROR_BAD_DICPOS: number,
        ERROR_MISSING_INITPROP: number,
        ERROR_BAD_LCLPPB_PROP: number
    }
}