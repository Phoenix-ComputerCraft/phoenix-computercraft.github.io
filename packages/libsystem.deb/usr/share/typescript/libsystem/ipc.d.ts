/** @noSelfInFile **/
/** @noResolution **/
declare module "system.ipc" {
    export const signal: {
        SIGHUP: number,
        SIGINT: number,
        SIGQUIT: number,
        SIGTRAP: number,
        SIGABRT: number,
        SIGKILL: number,
        SIGPIPE: number,
        SIGTERM: number,
        SIGCONT: number,
        SIGSTOP: number,
        SIGTTIN: number,
        SIGTTOU: number
    };
    export function kill(pid: number, signal: number): void;
    export function sigaction(signal: number, fn: ((signal: number) => void) | (() => void) | null): void;
    export function sendEvent(pid: number, event: string, param: Object): boolean;
    export function register(name: string): boolean;
    export function lookup(name: string): number|null;
    export function sendServiceEvent(name: string, event: string, param: Object): boolean;
    export function receiveEvent(pid?: number, event?: string, timeout?: number): LuaMultiReturn<[string, Object] | [null, null]>;
}