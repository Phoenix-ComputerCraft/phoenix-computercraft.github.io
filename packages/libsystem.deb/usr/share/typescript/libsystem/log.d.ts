/** @noSelfInFile **/
/** @noResolution **/
declare module "system.log" {
    type LogOptions = {
        name: string|null,
        category: string|null,
        level: 0|1|2|3|4|5|"debug"|"info"|"notice"|"warning"|"error"|"critical"|null,
        time: number|null,
        process: number|null,
        thread: number|null,
        module: string|null,
        traceback: boolean|null
    }
    /** @noSelf **/
    interface Log {
        log(options: LogOptions, ...args: any[]): void;
        log(...args: any[]): void;
        debug(options: LogOptions, ...args: any[]): void;
        debug(...args: any[]): void;
        info(options: LogOptions, ...args: any[]): void;
        info(...args: any[]): void;
        notice(options: LogOptions, ...args: any[]): void;
        notice(...args: any[]): void;
        warning(options: LogOptions, ...args: any[]): void;
        warning(...args: any[]): void;
        warn(options: LogOptions, ...args: any[]): void;
        warn(...args: any[]): void;
        error(options: LogOptions, ...args: any[]): void;
        error(...args: any[]): void;
        crtitical(options: LogOptions, ...args: any[]): void;
        crtitical(...args: any[]): void;
        traceback(message: string): void;
    }

    const log: Log & {
        levels: {debug: number, info: number, notice: number, warning: number, error: number, critical: number},
        create(this: void, name: string, streamed?: boolean, file?: string): Log,
        remove(this: void, name: string): void,
        open(this: void, name: string, filter?: string): number,
        close(this: void, name: string|number): void,
        setTTY(this: void, name: string, tty: TTY|null, level?: number): void
    } & {[name: string]: Log};
    export = log;
}