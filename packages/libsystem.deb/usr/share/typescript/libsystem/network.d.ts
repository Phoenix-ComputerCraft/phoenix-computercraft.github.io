/** @noSelfInFile **/
/** @noResolution **/
declare module "system.network" {
    export interface NetworkHandle {
        status(): LuaMultiReturn<["ready"|"connecting"|"error"|"open"|"closed", string|null]>;
        read(...mode: ("*a"|"*l"|"*L"|"*n"|"a"|"l"|"L"|"n"|number)[]): LuaMultiReturn<(string|number|null)[]>;
        read(mode: "*a"|"*l"|"*L"|"a"|"l"|"L"|number): string|null;
        read(mode: "*n"|"n"): number|null;
        write(...data: any[]): void;
        close(): void;
    }
    export interface HTTPHandle extends NetworkHandle {
        responseHeaders(): Object;
        responseCode(): number;
    }
    export type ConnectOptions = {
        url: string,
        encoding: "utf8" | "utf-8" | "binary" | null,
        headers: Object | null,
        method: "GET" | "POST" | "PUT" | "DELETE" | "OPTIONS" | "HEAD" | null,
        redirect: boolean | null,
        device: string | null
    };
    export type IPConfig = {
        ip: string|number,
        netmask: number|string,
        up: boolean
    };
    export type Route = {
        source: string,
        sourceNetmask: number,
        action: "unicast" | "broadcast" | "local" | "unreachable" | "prohibit" | "blackhole",
        device: string | null,
        destination: string | null
    };

    export function connect(options: string|ConnectOptions): LuaMultiReturn<[NetworkHandle|null, null|string]>;
    export function get(options: string|ConnectOptions): LuaMultiReturn<[NetworkHandle|null, null|string]>;
    export function head(options: string|ConnectOptions): LuaMultiReturn<[NetworkHandle|null, null|string]>;
    export function options(options: string|ConnectOptions): LuaMultiReturn<[NetworkHandle|null, null|string]>;
    export function post(options: string|ConnectOptions): LuaMultiReturn<[NetworkHandle|null, null|string]>;
    export function put(options: string|ConnectOptions): LuaMultiReturn<[NetworkHandle|null, null|string]>;
    export function getData(url: string, headers?: Object): LuaMultiReturn<[string|null, null|string]>;
    export function listen(uri: string): void;
    export function unlisten(uri: string): void;
    export function ipconfig(device: string, info?: IPConfig): IPConfig|null;
    export function control(ip: string, type: string, err?: string): void;
    export function events(state?: boolean): boolean;
    export function checkURI(uri: string): boolean;
    /** @noSelf **/
    export namespace route {
        function list(num?: number): Route[];
        function add(options: Route & {table: number | null}): void;
        function remove(source: string, mask: number, num?: number): void;
    }
    /** @noSelf **/
    export namespace arp {
        function list(device: string): {[ip: string]: number};
        function set(device: string, ip: string, id: number|null): void;
    }
}