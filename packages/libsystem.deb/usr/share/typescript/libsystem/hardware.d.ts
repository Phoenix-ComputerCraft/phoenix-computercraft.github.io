/** @noSelfInFile **/
type device = {[method: string]: Function} & {[property: string]: any};

/** @noSelf **/
declare interface CommandDevice extends device {
    command: string;
    run(): LuaMultiReturn<[boolean, string|null]>;
}

/** @noSelf **/
declare interface ComputerDevice extends device {
    readonly isOn: boolean;
    readonly label: string|null;
    turnOn(): void;
    shutdown(): void;
    reboot(): void;
}

/** @noSelf **/
declare interface RootComputerDevice extends ComputerDevice {
    label: string|null;
    shutdown(): never;
    reboot(): never;
}

/** @noSelf **/
declare interface DriveDevice extends device {
    readonly state: {
        audio: string|null,
        label: string|null,
        id: number|null
    } | null;
    setLabel(label: string|null): void;
    play(): void;
    stop(): void;
    eject(): void;
    insert(path: string): void;
}

/** @noSelf **/
declare interface EnergyStorageDevice extends device {
    readonly energy: number;
}

/** @noSelf **/
declare interface FluidStorageDevice extends device {
    readonly tanks: {name: string, amount: number}[];
    push(to: string, limit?: number, name?: string): number;
    pull(from: string, limit?: number, name?: string): number;
}

type ItemDetail = {
    name: string,
    count: number,
    nbt?: string,
    displayName: string,
    maxCount: number,
    damage?: number,
    maxDamage?: number,
    durability?: number,
    lore?: string[],
    enchantments?: {name: string, level: number, displayName: string}[],
    unbreakable?: boolean
}

/** @noSelf **/
declare interface InventoryDevice extends device {
    readonly items: {name: string, count: number, nbt: string|null}[];
    detail(slot: number): ItemDetail|null;
    limit(slot: number): number;
    push(to: string, slot: number, limit?: number, toSlot?: number): number;
    pull(from: string, slot: number, limit?: number, toSlot?: number): number;
}

/** @noSelf **/
declare interface ModemDevice extends device {
    readonly remainingChannels: number;
    open(channel: number): void;
    isOpen(channel: number): boolean;
    close(channel: number): void;
    closeAll(): void;
    transmit(channel: number, replyChannel: number|null, payload: any): void;
}

/** @noSelf **/
declare interface MonitorDevice extends device {
    scale: number;
    readonly size: {width: number, height: number};
    write(...value: any[]): void;
    termctl(flags?: TermFlags): TermFlags;
    openterm(): LuaMultiReturn<[Terminal] | [null, string]>;
    opengfx(): LuaMultiReturn<[GFXTerminal] | [null, string]>;
}

/** @noSelf **/
declare interface PrinterPage {
    readonly size: {width: number, height: number};
    cursor: {x: number, y: number};
    title: string|null;
    write(...text: any[]): void;
    close(): boolean;
}

/** @noSelf **/
declare interface PrinterDevice extends device {
    readonly inkLevel: number;
    readonly paperLevel: number;
    page(): PrinterPage|null;
}

/** @noSelf **/
declare interface RedstoneDevice extends device {
    readonly input: number|null;
    output: number|null;
    readonly bundledInput: number|null;
    bundledOutput: number|null;
}

/** @noSelf **/
interface SpeakerDevice extends device {
    playNote(instrument: string, volume?: number, pitch?: number): boolean;
    playSound(name: string, volume?: number, speed?: number): boolean;
    playAudio(audio: number[], volume?: number): boolean;
    stop(): void;
}

/** @noResolution **/
declare module "system.hardware" {
    export type HWInfo = {
        id: string,                      // Device hardware ID
        uuid: string,                    // Assigned UUID
        alias: string|null,              // User-specified alias
        parent: string,                  // Path to parent device
        displayName: string,             // Display name for users
        types: {[type: string]: string}, // Types of devices implemented: type = driver name
        metadata: Object                 // Extra static metadata provided by drivers
    }
    export type devicetree = {[name: string]: devicetree|null};
    type _devspec = string | device | devicetree;

    export const tree: devicetree;
    export function wrap(device: _devspec): device | null;
    export function find(type: string): LuaMultiReturn<device[]>;
    export function path(device: _devspec): LuaMultiReturn<string[]>;
    export function hasType(device: _devspec, type: string): boolean;
    export function info(device: _devspec): HWInfo|null;
    export function methods(device: _devspec): string[];
    export function properties(device: _devspec): string[];
    export function children(device: _devspec): string[];
    export function call(device: _devspec, method: string, ...args: any[]): LuaMultiReturn<any[]>;
    export function listen(device: _devspec, state?: boolean): void;
    export function lock(device: _devspec, wait?: boolean): boolean;
    export function unlock(device: _devspec): void;
}