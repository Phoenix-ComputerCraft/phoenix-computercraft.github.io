/** @noSelfInFile **/
/** @noResolution **/
declare module "system.framebuffer" {
    /** @noSelf **/
    interface _Window<T extends Terminal | GFXTerminal> {
        getPosition(): LuaMultiReturn<[number, number]>;
        reposition(x?: number, y?: number, width?: number, height?: number, parent?: T): void;
        resize(width?: number, height?: number): void;
        reparent(parent?: T): void;
        restoreCursor(this: _Window<Terminal>): void;
    }
    /** @noSelf **/
    interface _Framebuffer<T extends Terminal | GFXTerminal> extends _Window<T> {
        redraw(full?: boolean): void;
        isVisible(): boolean;
        setVisible(visible: boolean): void;
    }
    export type Window<T extends Terminal | GFXTerminal> = T & _Window<T>;
    export type Framebuffer<T extends Terminal | GFXTerminal> = T & _Framebuffer<T>;

    export const empty: {text: Terminal, graphics: GFXTerminal};
    export function window(parent: Terminal, x: number, y: number, width: number, height: number): Window<Terminal>;
    export function window(parent: GFXTerminal, x: number, y: number, width: number, height: number): Window<GFXTerminal>;
    export function framebuffer(parent: Terminal, x: number, y: number, width: number, height: number, visible?: boolean): Framebuffer<Terminal>;
    export function framebuffer(parent: GFXTerminal, x: number, y: number, width: number, height: number, visible?: boolean): Framebuffer<GFXTerminal>;
}