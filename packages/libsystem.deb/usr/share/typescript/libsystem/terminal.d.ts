/** @noSelfInFile **/
type Color = 0|1|2|3|4|5|6|7|8|9|10|11|12|13|14|15;
type Colour = Color;

/** @noSelf **/
declare interface ITerminalBase {
    close(): void;
    clear(): void;
    getSize(): LuaMultiReturn<[number, number]>;
    getPaletteColor(color: Color): LuaMultiReturn<[number, number, number]>;
    setPaletteColor(color: Color, rgb: number): void;
    setPaletteColor(color: Color, r: number, g: number, b: number): void;
    getPaletteColour(colour: Color): LuaMultiReturn<[number, number, number]>;
    setPaletteColour(colour: Color, rgb: number): void;
    setPaletteColour(colour: Color, r: number, g: number, b: number): void;
}

/** @noSelf **/
declare interface Terminal extends ITerminalBase {
    write(text: string): void;
    blit(text: string, fg: string, bg: string): void;
    clearLine(): void;
    getCursorPos(): LuaMultiReturn<[number, number]>;
    setCursorPos(x: number, y: number): void;
    getCursorBlink(): boolean;
    setCursorBlink(blink: boolean): void;
    isColor(): boolean;
    isColour(): boolean;
    scroll(lines: number): void;
    getTextColor(): Color;
    setTextColor(color: Color): void;
    getBackgroundColor(): Color;
    setBackgroundColor(color: Color): void;
    getTextColour(): Color;
    setTextColour(colour: Color): void;
    getBackgroundColour(): Color;
    setBackgroundColour(colour: Color): void;
    getLine(y: number): LuaMultiReturn<[string, string, string]>;
}

/** @noSelf **/
declare interface GFXTerminal extends ITerminalBase {
    getPixel(x: number, y: number): number;
    setPixel(x: number, y: number, color: number): void;
    getPixels(x: number, y: number, width: number, height: number, asStr?: false): Color[][];
    getPixels(x: number, y: number, width: number, height: number, asStr: true): string[];
    drawPixels(x: number, y: number, data: ((Color|null)[]|string)[], width?: number, height?: number): void;
    drawPixels(x: number, y: number, data: number, width: number, height: number): void;
    getFrozen(): boolean;
    setFrozen(frozen: boolean): void;
}

type TTY = [string, string, string][] & {
    isTTY: true,
    flags: {
        cbreak: boolean,
        delay: boolean,
        echo: boolean,
        keypad: boolean,
        nlcr: boolean,
        raw: boolean
    },
    cursor: {x: number, y: number},
    cursorBlink: boolean,
    colors: {fg: string, bg: string, bold: boolean},
    size: {width: number, height: number},
    dirtyLines: number[],
    palette: [number, number, number][],
    dirtyPalette: number[],
    buffer: string,
    preBuffer: string,
    isLocked: boolean,
    isGraphics: boolean,
    textBuffer: [string, string, string][] & {
        cursor: {x: number, y: number},
        cursorBlink: boolean,
        colors: {fg: string, bg: string, bold: boolean},
        dirtyLines: number[],
        palette: [number, number, number][],
        dirtyPalette: number[]
    },
    graphicsBuffer: string[] & {
        palette: [number, number, number][],
        dirtyPalette: number[],
        dirtyRects: ({x: number, y: number, color: Color} | {x: number, y: number, width: number, height: number})[],
        frozen: boolean
    },
    eof: boolean
};

type TermFlags = {
    cbreak?: boolean,
    delay?: boolean,
    echo?: boolean,
    keypad?: boolean,
    nlcr?: boolean,
    raw?: boolean
};

/** @noResolution **/
declare module "system.terminal" {
    type _Colors = {
        white: Color,
        orange: Color,
        magenta: Color,
        lightBlue: Color,
        yellow: Color,
        lime: Color,
        pink: Color,
        gray: Color,
        grey: Color,
        lightGray: Color,
        lightGrey: Color,
        cyan: Color,
        purple: Color,
        blue: Color,
        brown: Color,
        green: Color,
        red: Color,
        black: Color
    };
    export interface Readable {
        read(count?: number): string|null;
    }
    export interface Writable {
        write(str: string): void;
    }

    export const colors: _Colors;
    export const colours: _Colors;
    export function toEscape(color: Color, background?: boolean): string;
    export function write(...args: any[]): void;
    export function writeerr(...args: any[]): void;
    export function read(n: number): string|null;
    export function readline(): string|null;
    export function readline2(history?: string[], completion?: (partial: string) => string[]): string|null;
    export function termctl(flags?: TermFlags): TermFlags|null;
    export function openterm(): LuaMultiReturn<[Terminal] | [null, string]>;
    export function opengfx(): LuaMultiReturn<[GFXTerminal] | [null, string]>;
    export function mktty(width: number, height: number): TTY;
    export function stdin(handle: number|TTY|Readable|null): void;
    export function stdout(handle: number|TTY|Writable|null): void;
    export function stderr(handle: number|TTY|Writable|null): void;
    export function istty(): LuaMultiReturn<[boolean, boolean]>;
    export function termsize(): LuaMultiReturn<[number, number] | []>;
}