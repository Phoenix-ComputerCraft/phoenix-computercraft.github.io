/** @noSelfInFile **/
/** @noResolution **/
declare module "system.util" {
    export const syscall: {[method: string]: (...args: any[]) => LuaMultiReturn<any[]>};
    export function argparse(arguments: {"": {stopProcessingOnPositionalArgument?: boolean}} & {[arg: string]: boolean | "number" | "multiple" | "multiple number" | `@${string}`}, ...args: string[]): LuaMultiReturn<[{[arg: string]: true|string} & string[]] | [null, string]>;
    export function timer(time: number): number;
    export function alarm(time: number): number;
    export function cancel(id: number): number;
    export function sleep(time: number): void;
    export function pullEvent(): LuaMultiReturn<[string, Object]>;
    export function filterEvent(...types: string[]): LuaMultiReturn<[string, Object]>;
    export function queueEvent(event: string, param: Object): void;
    export function split(str: string, sep?: string, includeEmpty?: boolean): string[];
    export function copy<T>(value: T): T;
    export function addEventListener(event: string, callback: (event: string, param: Object) => boolean): void;
    export function removeEventListener(event: string, callback: (event: string, param: Object) => boolean): void;
    export function runEvents(): string;
    export function startEvents(): number;
    export function type(value: any): string;
    export function crc32(str: string, polynomial?: number|number[], crc?: number): number;
}