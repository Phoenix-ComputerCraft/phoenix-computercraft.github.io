/** @noSelfInFile **/
/** @noResolution **/
declare module "system.serialization" {
    /** @noSelf **/
    export namespace base64 {
        function encode(str: string): string;
        function decode(str: string): string;
    }
    /** @noSelf **/
    export namespace json {
        function encode(val: any): string;
        function decode(str: string): any;
        function save(val: any, path: string): void;
        function load(path: string): any;
    }
    /** @noSelf **/
    export namespace lua {
        type EncodeOptions = {minified?: boolean, allow_functions?: boolean};
        type DecodeOptions = {allow_functions?: boolean};
        function encode(val: any, opts?: EncodeOptions): string;
        function decode(str: string, opts?: DecodeOptions): any;
        function save(val: any, path: string, opts?: EncodeOptions): void;
        function load(path: string, opts?: DecodeOptions): any;
    }
}