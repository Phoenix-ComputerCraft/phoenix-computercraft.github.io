/** @noSelfInFile **/
/** @noResolution **/
declare module "system.filesystem" {
    /** @noSelf **/
    export interface FileHandle {
        close(): void;
    }
    /** @noSelf **/
    export interface ReadFileHandle extends FileHandle {
        read(n: number): string|number|null;
        readLine(newline?: boolean): string|null;
        readAll(): string|null;
    }
    /** @noSelf **/
    export interface WriteFileHandle extends FileHandle {
        write(val: any): void;
        writeLine(val: any): void;
        flush(): void;
    }
    /** @noSelf **/
    export interface BinaryFileHandle {
        seek(mode?: "set"|"cur"|"end", offset?: number): number;
    }
    export type Permission = {read: boolean|null, write: boolean|null, execute: boolean|null};
    export type FileStat = {
        size: number,
        type: "file" | "directory" | "link" | "fifo" | "special",
        created: number,
        modified: number,
        owner: string | null,
        mountpoint: string,
        capacity: number,
        freeSpace: number,
        permissions: {[key: string]: Permission},
        worldPermissions: Permission,
        setuser: boolean,
        special: LuaTable | null
    };
    export type MountInfo = {
        path: string,
        type: string,
        source: string,
        options: {[key: string]: any}
    };

    export function open(path: string, mode: "r"): LuaMultiReturn<[ReadFileHandle|null, null|string]>;
    export function open(path: string, mode: "w"|"a"): LuaMultiReturn<[WriteFileHandle|null, null|string]>;
    export function open(path: string, mode: "rb"): LuaMultiReturn<[(ReadFileHandle & BinaryFileHandle)|null, null|string]>;
    export function open(path: string, mode: "wb"|"ab"): LuaMultiReturn<[(WriteFileHandle & BinaryFileHandle)|null, null|string]>;
    export function list(path: string): string[];
    export function stat(path: string, nolink?: boolean): LuaMultiReturn<[FileStat|null, null|string]>;
    export function remove(path: string): void;
    export function rename(from: string, to: string): void;
    export function mkdir(path: string): void;
    export function link(path: string, location: string): void;
    export function mkfifo(path: string): void;
    export function chmod(path: string, user: string|null, mode: number|string|Permission): void;
    export function chown(path: string, user: string): void;
    export function chroot(path: string): void;
    export function mount(type: string, src: string, dest: string, options?: Object): void;
    export function unmount(path: string): void;
    export function mountlist(): MountInfo[];
    export function combine(...args: string[]): string;
    export function copy(from: string, to: string, preserve?: boolean): void;
    export function move(from: string, to: string): void;
    export function basename(path: string): string;
    export function dirname(path: string): string;
    export function find(wildcard: string): string[];
    export function exists(path: string): boolean;
    export function isFile(path: string): boolean;
    export function isDir(path: string): boolean;
    export function isLink(path: string): boolean;
    export function effectivePermissions(file: string|FileStat, user?: string): Permission|null;
}