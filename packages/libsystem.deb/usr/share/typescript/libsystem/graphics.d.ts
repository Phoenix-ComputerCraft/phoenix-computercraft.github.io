/** @noSelfInFile **/
/** @noResolution **/
declare module "system.graphics" {
    export function drawPixel(term: Terminal|GFXTerminal, x: number, y: number, color: Color): void;
    export function drawLine(term: Terminal|GFXTerminal, x1: number, y1: number, x2: number, y2: number, color: Color): void;
    export function drawBox(term: Terminal|GFXTerminal, x: number, y: number, width: number, height: number, color: Color): void;
    export function drawFilledBox(term: Terminal|GFXTerminal, x: number, y: number, width: number, height: number, color: Color): void;
    export function drawCircle(term: Terminal|GFXTerminal, x: number, y: number, width: number, height: number, color: Color, startAngle?: number, arcCircumference?: number): void;
    export function drawFilledTriangle(term: Terminal|GFXTerminal, x1: number, y1: number, x2: number, y2: number, x3: number, y3: number, color: Color): void;
    export function drawImage(term: Terminal, x: number, y: number, image: [string, string, string][] | string[] | (Color|null)[][]): void;
    export function drawImage(term: GFXTerminal, x: number, y: number, image: string[] | (Color|null)[][]): void;
}