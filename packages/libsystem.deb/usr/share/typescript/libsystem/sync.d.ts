/** @noSelfInFile **/
/** @noResolution **/
declare module "system.sync" {
    export interface mutex {
        lock(): void;
        unlock(): void;
        tryLock(): boolean;
        tryLockFor(timeout: number): boolean;
    }
    export const mutex: {new: (this: void, recursive?: boolean) => mutex};
    export interface semaphore {
        acquire(): void;
        tryAcquireFor(timeout: number): boolean;
        release(): void;
    }
    export const semaphore: {new: (this: void, init?: number) => mutex};
    export interface conditionVariable {
        wait(): void;
        waitFor(timeout: number): boolean;
        notifyOne(): void;
        notifyAll(): void;
    }
    export const conditionVariable: {new: (this: void) => conditionVariable};
    export interface barrier {
        wait(): boolean;
    }
    export const barrier: {new: (this: void, count: number) => barrier};
    export interface rwLock {
        lockRead(): void;
        unlockRead(): void;
        lockWrite(): void;
        unlockWrite(): void;
    }
    export const rwLock: {new: (this: void) => rwLock};
}