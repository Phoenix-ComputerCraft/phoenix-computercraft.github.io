/** @noSelfInFile **/
/** @noResolution **/
declare module "system.process" {
    export type ProcessInfo = {
        id: number,
        name: string,
        user: string,
        parent: number | null,
        dir: string,
        stdin: number | null,
        stdout: number | null,
        stderr: number | null,
        cputime: number,
        systime: number,
        threads: {id: number, name: string, status: string}[];
    };
    export function getpid(): number;
    export function getppid(): number;
    export function getuser(): string;
    export function setuser(user: string): void;
    export function clock(): number;
    export function getenv(): LuaTable;
    export function getname(): string;
    export function getcwd(): string;
    export function chdir(dir: string): void;
    export function fork(func: Function, name: string, ...args: any[]): number;
    export function exec(path: string, ...args: any[]): never;
    export function execp(command: string, ...args: any[]): never;
    export function start(path: string, ...args: any[]): number;
    export function run(path: string, ...args: any[]): LuaMultiReturn<[true, any] | [false, string]>;
    export function newthread(func: Function, ...args: any[]): number;
    export function exit(code?: number): never;
    export function getplist(): number[];
    export function getpinfo(pid: number): ProcessInfo|null;
}