/** @noResolution **/
declare module "libdeflate" {
    export interface Dictionary {
        adler32: number;
        hash_tables: number[][];
        string_table: string[];
        strlen: number;
    }
    export type CompressionConfigs = {
        level?: 0|1|2|3|4|5|6|7|8|9|null,
        strategy?: "fixed" | "huffman_only" | "dynamic"
    }

    export function CRC32(str: string, crc?: number): number;
    export function Adler32(str: string): number;
    export function IsEqualAdler32(actual: number, expected: number): boolean;
    export function CreateDictionary(str: string, strlen: number, adler32: number): Dictionary;
    export function CompressDeflate(str: string, configs?: CompressionConfigs): LuaMultiReturn<[string, number]>;
    export function CompressDeflateWithDict(str: string, dictionary: Dictionary, configs?: CompressionConfigs): LuaMultiReturn<[string, number]>;
    export function CompressZlib(str: string, configs?: CompressionConfigs): LuaMultiReturn<[string, number]>;
    export function CompressZlibWithDict(str: string, dictionary: Dictionary, configs?: CompressionConfigs): LuaMultiReturn<[string, number]>;
}