io.write("Enter encryption password: ")coroutine.yield("syscall","termctl",{echo=false})options.encryptfs_password=io.read()io.write("\n")coroutine.yield("syscall","termctl",{echo=true})
