<summary>GitHub read-only FUSE filesystem</summary>
# NAME
githubfs - GitHub read-only FUSE filesystem

# DESCRIPTION
**githubfs** is a FUSE filesystem that allows mounting GitHub repositories to
the local filesystem. It allows read-only access to public repositories, as well
as private repositories with a personal access key.

# USAGE
Simply mount the repo URL using a **fuse**(7) mount:

```sh
mount -t fuse -o fs=githubfs https://github.com/username/repo /mnt/path
```

The URL must be in the form `http[s]://github.com/<username>/<repo>[/|.git]`.

The following extra options are available:
- **token**: The PAK to use for authorization, if desired. This is required for
  private repositories.
- **branch**: The branch to access (defaults to the repo's default branch).

# SEE ALSO
**mount**(1), **fuse**(7)

# AUTHORS
**githubfs** was written by JackMacWindows for Phoenix.
