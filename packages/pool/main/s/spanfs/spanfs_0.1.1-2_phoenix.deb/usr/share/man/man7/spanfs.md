<summary>RAID-like spanning filesystem across disk peripherals</summary>
# NAME
spanfs - RAID-like spanning filesystem across disk peripherals

# DESCRIPTION
spanfs is a kernel module that implements a spanning filesystem layer across a
number of disk peripherals. It concatenates the contents of the disks together
into a single drive, which can store large files across multiple disks.

spanfs stores file information using a single index disk, which holds the
entire filesystem structure, plus up to 65535 of disks to store file
contents. Each disk has a file called ".spanfs", which contains three lines:
the user-friendly name of the filesystem, a UUID identifying it, and the ID
of the disk in the array. The ID is used to identify the disk's position in
the array regardless of mountpoint.

Disk ID 0 is the index disk. This disk contains only one file called "index"
which is a binary file that stores the entire filesystem tree, including
file names, metadata, and directory contents. A directory entry consists of
the following data (all integers are little-endian):

| Format | Size | Description       |
|--------|------|-------------------|
| `I`    | 4    | Directory entry length (excluding contents) |
| `I`    | 4    | File size         |
| `I8`   | 8    | Creation date     |
| `I8`   | 8    | Modification date |
| `B`    | 1    | Type (using TAR file types) |
| `B`    | 1    | Bits 0-2: world permissions, bit 7: set user |
| `s2`   | 2+x  | File name         |
| `s2`   | 2+x  | Owner name        |
| `B`    | 1    | Number of permission entries |
| `s2B`* | (3+x)*y | List of permissions - each entry is a name followed by a 3-bit mode |

The index file consists of one directory entry for the root of the
filesystem, which is always of type "directory".

If the entry points to a file, it is followed by a 16-byte string containing
the UUID of the file data, then a 2-byte integer indicating the number of
disks the file is split across, and then a list of 2-byte integers holding
the IDs of the disks which hold the data, in sequence, and finally a CRC-32
checksum of the file (4 bytes).

If the entry is a directory, it is followed by a 4-byte integer with the
number of files in the directory, followed by each entry in sequence. If the
entry is a link, it is followed by a 2-byte length string with the path that
the link points to. If the entry is a FIFO there is no data after the entry.

Note that the entry length does not include the length of the contents -
this is to allow the format to be extended for more metadata in the future.
Skip over the entire entry length to get to the contents - do not rely on
the contents being at the end of the above table! The order of the above
fields will not change in the future - fields will only be added at the end.

File data is stored by a random UUID assigned to the file. Each part of a
file is distributed across independent chunks on each disk, with each chunk
named with the file's UUID. The file can be reconstructed by concatenating
the contents of each chunk in the order specified in the ID list in the file
entry.

The default allocation algorithm will first attempt to store the entire file
on a single disk, finding the disk with the least amount of free space that
can still fit the whole file. If there are no disks that can store the
entire file, then the file will be split across as few disks as possible,
using the disks with the largest free space in order. If two disks have the
same amount of free space, the disk with the lowest ID is preferred.

# CONFIGURATION
**spanfs** can be installed by dropping the `spanfs.lua` kernel module into
`/lib/modules`. Ensure the file is not world-writable, and is executable by root.

Use the **mkspanfs**(8) program to create new spanfs volumes across disks.

# SEE ALSO
**mkspanfs**(8), **spaninfo**(8)