<summary>access and administrate YellowBox boxes</summary>
# NAME
yellowbox - access and administrate YellowBox boxes

# SYNOPSIS
**yellowbox status**  
**yellowbox start** [*options*] ...
**yellowbox stop** *id*
**yellowbox view** *id*
**yellowbox get-bios** [*version*]

# DESCRIPTION
**yellowbox** 

# EXAMPLE


# SEE ALSO
**yellowbox**(7)