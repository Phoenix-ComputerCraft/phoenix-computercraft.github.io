<summary>kernel level CraftOS virtualization</summary>
# NAME
YellowBox - kernel level CraftOS virtualization

# DESCRIPTION
**yellowbox** is a kernel module which implements a ComputerCraft virtual machine for running CraftOS programs on Phoenix. It acts as a more robust alternative to **libcraftos**, which is a simple translation layer from CraftOS APIs to Phoenix syscalls - instead, it runs a full CraftOS machine, which avoids the quirks that come from call translation.

YellowBox operates on constructs known as *boxes*. A box holds an entire CraftOS runtime, and is represented by a numerical ID (which corresponds to the user process for the box). Boxes have a main coroutine, a TTY, and a process associated with them, among other things. The TTY holds the contents of the computer's terminal, which can be read to display the screen elsewhere. The box's process represents the box in userspace, and it sends events coming from Phoenix programs into the machine, as well as triggering the machine to continue running.

To ensure compatibility with CraftOS programs, YellowBox runs as a kernel service, which avoids issues caused by yielding for preemption or system calls. The ComputerCraft APIs directly call the respective underlying kernel routines, which means that no yielding is required (though some filesystems which yield internally may cause spurious yields - this is mitigated through some hacks). This also means that Phoenix programs will not run while the box is running - avoid running heavy programs inside the box.

While YellowBox runs directly in the kernel instead of userspace, the APIs exposed still call out to Phoenix syscalls and functions. The box has an associated root directory and user, and filesystem calls go through the Phoenix VFS layer, allowing permissions and mounts to be used from CraftOS. 

# INTERFACING WITH BOXES
The **yellowbox** kernel module exposes a module API (i.e. the `callmodule` syscall) which allows programs to interact with boxes. To create a box, call the **create** method, which takes a single table argument with options for the box, and returns the ID of the box. Creating a box requires root privileges, as boxes run at a higher privilege level. The options available include:
- *bios*: The contents of the BIOS program to use (required)
- *root*: The root directory for the box
- *user*: The user to run as
- *peripherals*: A key-value mapping of peripherals to expose to the machine (key is CraftOS name, value is Phoenix hardware node path/UUID)
- *http*: A boolean specifying whether to expose the `http` API

The box will start executing directly after calling this method. To access the TTY with the box's terminal contents, call the **getTTY** method with the ID of the box. This will return a TTY object like `mktty` does. It will also assign the calling process to the TTY, meaning that it will get `tty_redraw` events when the box writes to the screen. Note that the box only uses the exclusive-text-mode buffer (`tty.textBuffer`), so the main buffer will always be empty.

Events that are requested by CraftOS APIs, as well as peripheral events for devices that are forwarded, will be sent to the machine automatically. However, user-interactive events like `key` aren't handled by YellowBox itself. To send events to the box, including user-interactive events, send a remote event to the userspace program (whose PID is the box ID). The remote event name should be the event to queue, and the parameter should be a list of parameters for the event, with an optional `n` field for the number of parameters. The event will be queued into the box with no modification. Because of this, for `key` events, make sure to convert the key ID to a proper CraftOS key code. The included library contains a routine to convert Phoenix keycodes into CraftOS keycodes using a `keys` API loaded from the CraftOS ROM.

The box can be restarted or shut down using the `reboot` and `shutdown` methods, respectively. The box can also be stopped entirely by calling the `stop` method, which requires root privileges.

# SEE ALSO
**yellowbox**(1)