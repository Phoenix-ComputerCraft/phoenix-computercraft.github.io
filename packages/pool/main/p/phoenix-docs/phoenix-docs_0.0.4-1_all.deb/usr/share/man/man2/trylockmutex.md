<summary>attempts to lock the mutex</summary>
# NAME
trylockmutex - attempts to lock the mutex

# LIBRARY
Standard system library, synchronization module (*libsystem*, `system.sync`)

# SYNOPSIS
**trylockmutex**(*mtx*: mutex): boolean

# DESCRIPTION
Attempts to lock the mutex, returning immediately if the mutex could not be locked.

# PARAMETERS
1. `mtx`: The mutex to lock.

# RETURN VALUE
Whether the mutex could be locked.

# ERRORS
This syscall may throw an error if:
* The mutex is already claimed by the current thread and is not recursive.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**lockmutex**(2), **unlockmutex**(2)
