<summary>mounts a disk device to a path</summary>
# NAME
mount - mounts a disk device to a path

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**mount**(*type*: string, *src*: string, *dest*: string, *options*: table?)

# DESCRIPTION
Mounts a disk device to a path using the specified filesystem and options.

# PARAMETERS
1. `type`: The filesystem type to use when mounting.
2. `src`: The source device to mount. This argument's meaning depends on the filesystem type.
3. `dest`: The directory to mount the new filesystem to.
4. `options`: A table of options to pass to the filesystem mounter. The available options are specified by each individual filesystem.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The filesystem type does not exist.
* The source device is invalid for the specified filesystem type.
* The destination path does not exist.
* The options passed to the mounter are invalid for the specified filesystem type.
* The current user does not have permission to access to the source device.
* The current user does not have permission to write to to the destination path.
* The mounter ran into an issue while mounting the device.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**mountlist**(2), **unmount**(2)
