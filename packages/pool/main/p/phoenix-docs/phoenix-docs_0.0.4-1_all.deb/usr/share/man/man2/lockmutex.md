<summary>locks the specified mutex</summary>
# NAME
lockmutex - locks the specified mutex

# LIBRARY
Standard system library, synchronization module (*libsystem*, `system.sync`)

# SYNOPSIS
**lockmutex**(*mtx*: mutex)

# DESCRIPTION
Locks the specified mutex, waiting for the resource to be freed before claiming it.

# PARAMETERS
1. `mtx`: The mutex to lock.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The mutex is already claimed by the current thread and is not recursive.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**timelockmutex**(2) **trylockmutex**(2), **unlockmutex**(2)
