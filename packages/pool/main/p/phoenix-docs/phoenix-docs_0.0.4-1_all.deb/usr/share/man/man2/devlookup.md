<summary>returns all paths to devices that have the specified node name</summary>
# NAME
devlookup - returns all paths to devices that have the specified node name

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**devlookup**(*name*: string): string...

# DESCRIPTION
Returns all paths to devices that have the specified node name. If a path or UUID is specified, returns the path of the singular device node.

# PARAMETERS
1. `name`: The device name to search for

# RETURN VALUE
The path to each node in the device tree that has the specified name.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**devfind**(2)
