<summary>returns a list of names of all children of the current device</summary>
# NAME
devchildren - returns a list of names of all children of the current device

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
devchildren(device: string): string[]

# DESCRIPTION
Returns a list of names of all children of the current device.

# PARAMETERS
1. `device`: The device path or UUID to look up

# RETURN VALUE
A list of child names, in an unspecified order. This table may be empty.

# ERRORS
This syscall may throw an error if:
* The specified device does not exist.

# HISTORY
Introduced in Phoenix 0.0.1.
