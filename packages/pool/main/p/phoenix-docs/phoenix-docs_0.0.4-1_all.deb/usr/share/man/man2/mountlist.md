<summary>returns a list of mounts on the system</summary>
# NAME
mountlist - returns a list of mounts on the system

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**mountlist**(): [{*path*: string, *type*: string, *source*: string, *options*: table}]

# DESCRIPTION
Returns a list of mounts on the system.

# PARAMETERS
This syscall does not take any arguments.

# RETURN VALUE
A list of tables containing the mount path, the filesystem type, the source path, and any options stored in the mount.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**mount**(2)
