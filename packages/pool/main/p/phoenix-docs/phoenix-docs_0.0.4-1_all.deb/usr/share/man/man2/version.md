<summary>returns the Phoenix version or build number</summary>
# NAME
version - returns the Phoenix version or build number

# SYNOPSIS
**version**(*buildnum*: boolean?): string

# DESCRIPTION
Returns the Phoenix version or build number.

# PARAMETERS
1. `buildnum`: `true` to return the minor build string/information, `false` to return the version number

# RETURN VALUE
The version number of the current Phoenix kernel.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**cchost**(2)
