<summary>queries or modifies the current PIP config</summary>
# NAME
ipconfig - queries or modifies the current PIP config

# LIBRARY
Standard system library, network module (*libsystem*, `system.network`)

# SYNOPSIS
**ipconfig**(*device*: string, *info*: table?): table?

# DESCRIPTION
Returns a table with information about the current PIP configuration for the specified modem, and optionally sets new options (requires root).

If no configuration is present, then both the IP and netmask must be specified if `info` is set.

# PARAMETERS
1. `device`: The path to the modem to operate on
2. `info`: If provided, a table of configuration options to set on the device, in the same format as the returned table

# RETURN VALUE
A table of PIP configuration entries. These are the currently used members:
* `ip: string`: The IP address of the modem. No IP is indicated with an empty string. (When setting, this may also be a 32-bit number representing the IP in big-endian format.)
* `netmask: number`: The subnet mask expressed as a number of bits, as in CIDR notation. No subnet mask is indicated with a value of `0`. (When setting, this may also be an IP-formatted address string.)
* `up: boolean`: Whether the link is currently up. If a link is down, no Phoenix networking protocols will be serviced on this device. (This allows user applications to manually manage the protocols instead, if required.)

If the device does not have any IP configuration, returns `nil`.

# ERRORS
This syscall may throw an error if:
* The device is not present.
* The device is not a valid modem.
* A non-root user attempted to set configurations.

# HISTORY
Introduced in Phoenix 0.0.1.
