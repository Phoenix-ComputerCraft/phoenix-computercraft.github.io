<summary>returns the amount of time the computer has been running</summary>
# NAME
uptime - returns the amount of time the computer has been running

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**uptime**(): number

# DESCRIPTION
Returns the amount of time the computer has been running.

# PARAMETERS
This syscall does not take any arguments.

# RETURN VALUE
The amount of time the computer has been running in seconds.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.
