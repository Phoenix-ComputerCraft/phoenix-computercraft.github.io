<summary>returns a list of file names present in a directory</summary>
# NAME
list - returns a list of file names present in a directory

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**list**(*path*: string): string[]

# DESCRIPTION
Returns a list of file names present in a directory.

# PARAMETERS
1. `path`: The path to the directory to list.

# RETURN VALUE
A list of file names. This may or may not be sorted.

# ERRORS
This syscall may throw an error if:
* The path does not exist.
* The path is not directory.
* The current user does not have permission to access the directory.

# HISTORY
Introduced in Phoenix 0.0.1.
