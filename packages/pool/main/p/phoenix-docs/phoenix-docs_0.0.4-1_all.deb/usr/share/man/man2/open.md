<summary>opens a file for reading or writing</summary>
# NAME
open - opens a file for reading or writing

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**open**(*path*: string, *mode*: string): file

# DESCRIPTION
Opens a file for reading or writing.

# PARAMETERS
1. `path`: The path to the file to open. This may be a relative path to the current working directory, or an absolute path relative to the root.
2. `mode`: The mode to open the file in. This may be `r`, `w`, or `a`, with an additional `b` at the end to open in binary mode.

# RETURN VALUE
A file handle object.

# ERRORS
This syscall may throw an error if:
* The mode argument is invalid.
* The file was opened in read mode and it does not exist.
* The parent directory of the file does not exist.
* The file is a directory.
* The current user does not have permission to access the file.
* If creating a new file and the current user does not have permission to write the parent directory.

# HISTORY
Introduced in Phoenix 0.0.1.
