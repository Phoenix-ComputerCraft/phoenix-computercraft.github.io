<summary>sends a signal to another process</summary>
# NAME
kill - sends a signal to another process

# LIBRARY
Standard system library, IPC module (*libsystem*, `system.ipc`)

# SYNOPSIS
**kill**(*pid*: number, *signal*: number)

# DESCRIPTION
Sends a signal to another process. The signal may be any numerical value, though the system will only respond to certain values.

# PARAMETERS
1. `pid`: The ID of the process to send to
2. `signal`: The signal ID to send

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The target process ID does not exist.
* The current user does not have permission to send a signal to the target.
  * The target process must be under the same user as the current one.
  * If the current process is running as root, it may send a signal to any process.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**signal**(2)
