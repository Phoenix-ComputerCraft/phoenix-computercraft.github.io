<summary>combines a set of path components into a valid path</summary>
# NAME
combine - combines a set of path components into a valid path

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**combine**(*components...*: string): string

# DESCRIPTION
Combines a set of path components into a valid path.

# PARAMETERS
1. `components...`: The components in the path

# RETURN VALUE
The final path composed of the passed components.

# ERRORS
This syscall does not throw errors.

# HISTORY
Introduced in Phoenix 0.0.1.
