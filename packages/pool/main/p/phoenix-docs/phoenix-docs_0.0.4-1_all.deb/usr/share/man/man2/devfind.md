<summary>finds devices with a specific type</summary>
# NAME
devfind - finds devices with a specific type

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**devfind**(*type*: string): string...

# DESCRIPTION
Returns all paths to devices that have the specified type implemented.

# PARAMETERS
1. `name`: The device type to search for

# RETURN VALUE
The path to each node in the device tree that has the specified type.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**devlookup**(2)
