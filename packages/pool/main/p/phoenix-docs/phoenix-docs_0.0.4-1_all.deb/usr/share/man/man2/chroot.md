<summary>changes the root directory</summary>
# NAME
chroot - changes the root directory

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**chroot**(*path*: string)

# DESCRIPTION
Changes the root directory of the current and future child processes. This syscall requires root.

# PARAMETERS
1. `path`: The path to the new root directory.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The current user is not root.
* The new root directory does not exist.

# HISTORY
Introduced in Phoenix 0.0.3.
