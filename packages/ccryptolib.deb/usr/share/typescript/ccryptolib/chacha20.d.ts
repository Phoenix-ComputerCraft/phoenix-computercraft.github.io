/** @noSelfInFile **/
/** @noResolution **/
declare module "ccryptolib.chacha20" {
    export function crypt(key: string, nonce: string, message: string, rounds?: number, offset?: number): string;
}