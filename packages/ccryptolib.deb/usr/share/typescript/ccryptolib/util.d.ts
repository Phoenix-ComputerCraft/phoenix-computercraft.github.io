/** @noSelfInFile **/
/** @noResolution **/
declare module "ccryptolib.util" {
    export function toHex(str: string): string;
    export function fromHex(hex: string): string | null;
    export function compare(a: string, b: string): boolean;
}