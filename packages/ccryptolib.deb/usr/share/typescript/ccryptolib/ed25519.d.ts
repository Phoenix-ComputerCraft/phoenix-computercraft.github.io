/** @noSelfInFile **/
/** @noResolution **/
declare module "ccryptolib.ed25519" {
    export function publicKey(sk: string): string;
    export function sign(sk: string, pk: string, msg: string): string;
    export function verify(pk: string, msg: string, sig: string): boolean;
}