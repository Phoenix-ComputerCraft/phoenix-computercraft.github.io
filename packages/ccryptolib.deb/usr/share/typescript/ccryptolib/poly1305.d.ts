/** @noSelfInFile **/
/** @noResolution **/
declare module "ccryptolib.poly1305" {
    export function mac(key: string, message: string): string;
}