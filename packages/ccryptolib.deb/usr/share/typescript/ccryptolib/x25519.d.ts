/** @noSelfInFile **/
/** @noResolution **/
declare module "ccryptolib.x25519" {
    export function publicKey(sk: string): string;
    export function exchange(sk: string, pk: string): string;
    export function exchangeEd(sk: string, pk: string): string;
}