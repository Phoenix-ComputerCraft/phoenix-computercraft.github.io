/** @noSelfInFile **/
/** @noResolution **/
declare module "ccryptolib.aead" {
    export function encrypt(key: string, nonce: string, message: string, aad: string, rounds?: number): LuaMultiReturn<[string, string]>;
    export function decrypt(key: string, nonce: string, tag: string, ciphertext: string, aad: string, rounds?: string): string | null;
}