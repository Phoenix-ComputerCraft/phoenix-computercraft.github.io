/** @noSelfInFile **/
/** @noResolution **/
declare module "ccryptolib.blake3" {
    export function digest(message: string, len?: number): string;
    export function digestKeyed(key: string, message: string, len?: number): string;
    export function deriveKey(context: string): (material: string, len?: number) => string;
}