/** @noSelfInFile **/
/** @noResolution **/
declare module "ccryptolib.sha256" {
    export function digest(data: string): string;
    export function pbkdf2(password: string, salt: string, iter: number, progress?: (iter: number) => void): string;
}