/** @noSelfInFile **/
/** @noResolution **/
declare module "ccryptolib.random" {
    export function init(seed: string): void;
    export function mix(data: string): void;
    export function random(len: number): string;
}