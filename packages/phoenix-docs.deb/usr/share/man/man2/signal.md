<summary>registers a handler function to be called for a signal</summary>
# NAME
signal - registers a handler function to be called for a signal

# LIBRARY
Standard system library, IPC module (*libsystem*, `system.ipc`)

# SYNOPSIS
**signal**(*signal*: number, *handler*: function(signal: number))

# DESCRIPTION
Registers a handler function to be called for a signal.

# PARAMETERS
1. `signal`: The signal ID to register for.
2. `handler`: The handler function to call, which takes the signal ID as its only argument.

# RETURN VALUES
This syscall does not return anything.

# ERRORS
This syscall does not throw errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**kill**(2)
