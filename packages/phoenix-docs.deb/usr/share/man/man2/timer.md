<summary>sets a timer</summary>
# NAME
timer - sets a timer

# LIBRARY
Standard system library, utility module (*libsystem*, `system.util`)

# SYNOPSIS
**timer**(*timeout*: number): number

# DESCRIPTION
Sets a timer that will send a `timer` event after the specified number of seconds.

# PARAMETERS
1. `timeout`: The amount of time to set the timer for.

# RETURN VALUE
The ID of the new timer created.

# ERRORS
This syscall does not throw errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**alarm**(2), **cancel**(2)
