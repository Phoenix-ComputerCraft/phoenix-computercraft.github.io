<summary>creates a new FIFO pipe file</summary>
# NAME
mkfifo - creates a new FIFO pipe file

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**mkfifo**(*path*: string)

# DESCRIPTION
Creates a new FIFO (first in first out) pipe file at a path, creating any parent directories if they don't exist.

# PARAMETERS
1. `path`: The path to the FIFO to create.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The current user does not have permission to write the parent directory of the first directory created.
* The path already exists.

# HISTORY
Introduced in Phoenix 0.0.3.
