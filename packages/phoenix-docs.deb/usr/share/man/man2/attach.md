<summary>attaches a peripheral of the specified type to the computer</summary>
# NAME
attach - attaches a peripheral of the specified type to the computer

# SYNOPSIS
**attach**(*side*: string|number, *type*: string, *args...*: any): boolean, string?

# DESCRIPTION
If using an emulator, attaches a peripheral of the specified type to the computer. This syscall requires root.

# PARAMETERS
1. `side`: The side to attach to, or an ID to attach as
2. `type`: The type of peripheral to attach. The peripherals use standard CC/CraftOS-PC naming.
3. `args...`: Any arguments to pass to the peripheral constructor

# RETURN VALUE
1. Whether the attachment succeeded
2. If it failed, an optional error message (this may be `nil`!)

# ERRORS
This syscall may throw an error if:
* The user is not root.

# HISTORY
Introduced in Phoenix 0.0.2.

# SEE ALSO
**detach**(2)
