<summary>detaches a peripheral from a side</summary>
# NAME
detach - detaches a peripheral from a side

# SYNOPSIS
**detach**(*side*: string|number): boolean, string?

# DESCRIPTION
If using an emulator, detaches a peripheral from a side. This syscall requires root.

# PARAMETERS
1. `side`: The side or ID to detach

# RETURN VALUE
1. Whether the detachment succeeded
2. If it failed, an optional error message (this may be `nil`!)

# ERRORS
This syscall may throw an error if:
* The user is not root.

# HISTORY
Introduced in Phoenix 0.0.2.

# SEE ALSO
**attach**(2)
