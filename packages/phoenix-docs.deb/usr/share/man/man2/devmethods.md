<summary>returns a list of methods that can be called on this device</summary>
# NAME
devmethods - returns a list of methods that can be called on this device

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**devmethods**(*device*: string): string[]

# DESCRIPTION
Returns a list of methods that can be called on this device.

# PARAMETERS
1. `device`: The device path or UUID to look up

# RETURN VALUE
A list of valid methods that can be called.

# ERRORS
This syscall may throw an error if:
* The specified device does not exist.

# HISTORY
Introduced in Phoenix 0.0.1.
