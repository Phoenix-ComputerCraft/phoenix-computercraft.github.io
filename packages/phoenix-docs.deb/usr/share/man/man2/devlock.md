<summary>locks the specified device to this process</summary>
# NAME
devlock - locks the specified device to this process

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**devlock**(*device*: string, *wait*: boolean = true): boolean

# DESCRIPTION
Locks the specified device to this process. This prevents any calls to the device from other processes, and will suppress events from being sent to other processes. If the current process already owns the lock, this syscall returns `true` immediately. (It does not act like a recursive mutex in this case - only one unlock is required no matter how many times it's locked.)

# PARAMETERS
1. `device`: The device path or UUID to operate on
2. `wait`: `true` to wait for the lock to be released before returning; `false` to return immediately if the lock is already owned by another process

# RETURN VALUE
`true` if the current process now owns the lock; `false` otherwise.

# ERRORS
This syscall may throw an error if:
* The specified device does not exist.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**devunlock**(2)
