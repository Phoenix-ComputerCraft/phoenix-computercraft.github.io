<summary>returns a table with information about a file or directory</summary>
# NAME
stat - returns a table with information about a file or directory

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**stat**(*path*: string): StatInfo | **nil**, string

# DESCRIPTION
Returns a table with information about a file or directory. If the file does not exist, this returns `nil` and an error message.

# PARAMETERS
1. `path`: The path to the file or directory to inspect.

# RETURN VALUE
A table with the following contents:
* `size: number`: The total size of the file in bytes
* `type: string`: The type of file, which can be `"file"`, `"directory"`, `"link"`, `"fifo"`, or `"special"`
* `created: number`: The time the file was created, in milliseconds since the UNIX epoch
* `modified: number`: The time the file was last modified, in milliseconds since the UNIX epoch
* `owner: string`: The owner of the file
* `mountpoint: string`: The path to the mountpoint the file is on
* `link: string?`: If the file is a link, the path it links to
* `capacity: number`: The total number of bytes the mount can store
* `freeSpace: number`: The total number of bytes available on the mount
* `permissions: table`: The permissions for each user/group
  * `<string>: table`: The permissions for each user/group who has manual permissions
    * `read: boolean`: Whether the user can read the file
    * `write: boolean`: Whether the user can write to the file
    * `execute: boolean`: Whether the user can execute the file
* `worldPermissions: table`: The permissions for all other users
  * `read: boolean`: Whether everyone else can read the file
  * `write: boolean`: Whether everyone else can write to the file
  * `execute: boolean`: Whether everyone else can execute the file
* `setuser: boolean`: Whether executing the file will set the user to the owner
* `special: table?`: A table that can contain mount-specific data.

# ERRORS
This syscall does not throw errors.

# HISTORY
Introduced in Phoenix 0.0.1.
