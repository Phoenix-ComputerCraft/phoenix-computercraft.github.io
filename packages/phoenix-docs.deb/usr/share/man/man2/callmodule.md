<summary>calls a function on a kernel module</summary>
# NAME
callmodule - calls a function on a kernel module

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**callmodule**(*name*: string, *func*: string, *args...*: any): any...

# DESCRIPTION
Calls a function on a kernel module, if the module exposes an API.

# PARAMETERS
1. `name`: The name of the module to call on
2. `func`: The name of the function to call
3. `args...`: Any arguments to pass to the function

# RETURN VALUE
Any values returned from the function call.

# ERRORS
This syscall may throw an error if:
* The module requested is not loaded.
* The module does not have an exported API.
* The module does not have the requested function.
* The function throws an error.

# HISTORY
Introduced in Phoenix 0.0.1.
