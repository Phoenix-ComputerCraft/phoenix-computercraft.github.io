<summary>starts listening for connections on the specified URI</summary>
# NAME
listen - starts listening for connections on the specified URI

# LIBRARY
Standard system library, network module (*libsystem*, `system.network`)

# SYNOPSIS
**listen**(*uri*: string)

# DESCRIPTION
Starts listening for connections on the specified URI, using the protocol, IP, and port indicated in the URI. For PSP connections, the IP is used to determine the device to listen on - if this is `0.0.0.0`, then all connections are accepted.

When a request is received, a `network_request` event is sent with the URI of the listener, the IP of the other computer (if available), and a handle to the connection. Listening will continue until `unlisten` is called with the same URI. (Note: PSP can only handle one connection at once per port.)

The following URI schemes are built-in:
* `http`: Internet HTTP requests (CraftOS-PC only)
* `ws`: Internet WebSocket connections (CraftOS-PC only)
* `psp`: Phoenix Socket Protocol connections

Other schemes may be implemented in kernel modules.

# PARAMETERS
1. `uri`: The URI to listen on. The path portion is ignored.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The URI specified is malformed.
* The scheme in the URI is not supported.
* The computer does not own the IP in the URI.
* The computer is already using the IP/port specified.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**unlisten**(2)
