<summary>sets an alarm</summary>
# NAME
alarm - sets an alarm

# LIBRARY
Standard system library, utility module (*libsystem*, `system.util`)

# SYNOPSIS
**alarm**(*timeout*: number): number

# DESCRIPTION
Sets an alarm that will send an `alarm` event at the specified time.

# PARAMETERS
1. `timeout`: The time to set the alarm to.

# RETURN VALUE
The ID of the new alarm created.

# ERRORS
This syscall does not throw errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**cancel**(2), **timer**(2)
