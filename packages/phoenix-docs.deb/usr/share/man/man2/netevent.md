<summary>returns or toggles the current state of network event reporting</summary>
# NAME
netevent - returns or toggles the current state of network event reporting

# LIBRARY
Standard system library, network module (*libsystem*, `system.network`)

# SYNOPSIS
**netevent**(*state*: boolean?): boolean

# DESCRIPTION
Returns the current state of network event reporting in the current process, and toggles it if desired. This allows listening to events such as control messages, PSP messages, send failures, etc.

# PARAMETERS
1. `state`: If specified, whether to send general network events to the current process

# RETURN VALUE
The current state of network event reporting.

# ERRORS
This syscall may throw an error if:
* The current user is not root.

# HISTORY
Introduced in Phoenix 0.0.1.
