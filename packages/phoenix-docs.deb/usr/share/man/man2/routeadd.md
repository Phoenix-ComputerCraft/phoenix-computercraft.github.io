<summary>adds a new route to the specified route table</summary>
# NAME
routeadd - adds a new route to the specified route table

# LIBRARY
Standard system library, network module (*libsystem*, `system.network`)

# SYNOPSIS
**routeadd**(*options*: table)

# DESCRIPTION
Adds a new route to the specified route table. If the table does not exist, it will be created.

# PARAMETERS
1. `options`: A table with options for the route entry, with the following fields:
  * `source: string`: The bottom end of the source IP range.
  * `sourceNetmask: number`: The source subnet mask. For a single IP, this is 32. For all IPs (`default`), this is 0.
  * `action: string`: The action to take on the message. Valid values:
    * `"unicast"`: Send all messages to the specified destination.
    * `"broadcast"`: Broadcast the message to all destinations on the device.
    * `"local"`: Send the message to a known destination on a local network.
    * `"unreachable"`: Send a Destination Unreachable message back to the sender.
    * `"prohibit"`: Send a Prohibit message back to the sender.
    * `"blackhole"`: Ignore the message altogether.
  * `device: string?`: The device path to send the message to.
  * `destination: string?`: The destination IP to forward to.
  * `table: number?`: A number specifying the table index to insert into (integer starting at 1; defaults to 1).

The actions `"local"`, `"unicast"` and `"broadcast"` require `device`; `"unicast"` also requires `destination`.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* A non-root user attempted to add routes.
* A route already exists with the same IP and netmask.
* The device (if specified) is not present.
* The device (if specified) is not a valid modem.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**routedel**(2)
