<summary>unloads a kernel module from memory</summary>
# NAME
unloadmodule - unloads a kernel module from memory

# SYNOPSIS
**unloadmodule**(*path*: string)

# DESCRIPTION
Unloads a kernel module from memory. This syscall requires root.

# PARAMETERS
1. `name`: The name of the module to unload

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The user is not root.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**loadmodule**(2)
