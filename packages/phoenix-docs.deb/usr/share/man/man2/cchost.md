<summary>returns the value of the _HOST variable</summary>
# NAME
cchost - returns the value of the _HOST variable

# SYNOPSIS
**cchost**(): string

# DESCRIPTION
Returns the value of the `_HOST` variable.

# PARAMETERS
This syscall does not take any arguments.

# RETURN VALUE
The value of `_HOST`, which is in the format `ComputerCraft [0-9%.]+ %b()`.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**version**(2)
