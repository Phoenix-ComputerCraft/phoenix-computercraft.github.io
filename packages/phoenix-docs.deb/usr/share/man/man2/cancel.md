<summary>cancels a previously set timer or alarm</summary>
# NAME
cancel - cancels a previously set timer or alarm

# LIBRARY
Standard system library, utility module (*libsystem*, `system.util`)

# SYNOPSIS
**cancel**(*tm*: number)

# DESCRIPTION
Cancels a previously set timer or alarm.

# PARAMETERS
1. `tm`: The ID of the timer or alarm to cancel.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall does not throw errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**alarm**(2), **timer**(2)
