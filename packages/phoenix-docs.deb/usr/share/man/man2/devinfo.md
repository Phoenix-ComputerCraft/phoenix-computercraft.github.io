<summary>returns a table with information describing a device node</summary>
# NAME
devinfo - returns a table with information describing a device node

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**devinfo**(*device*: string): HWInfo?

# DESCRIPTION
Returns a table with information describing a device node.

# PARAMETERS
1. `device`: The device path or UUID to look up

# RETURN VALUE
A table with the following information:
```ts
type HWInfo = {
    id: string,                // Device hardware ID
    uuid: string,              // Assigned UUID
    alias: string?,            // User-specified alias
    parent: string,            // Path to parent device
    displayName: string,       // Display name for users
    types: {[string]: string}, // Types of devices implemented: type = driver name
    metadata: Object           // Extra static metadata provided by drivers
}
```
If the device does not exist, this returns `nil`.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**devmethods**(2), **devproperties**(2)
