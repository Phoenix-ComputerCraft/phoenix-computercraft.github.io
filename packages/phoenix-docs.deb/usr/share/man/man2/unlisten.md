<summary>stops listening on a URI previously passed to listen</summary>
# NAME
unlisten - stops listening on a URI previously passed to listen

# LIBRARY
Standard system library, network module (*libsystem*, `system.network`)

# SYNOPSIS
**unlisten**(*uri*: string)

# DESCRIPTION
Stops listening on a URI previously passed to `listen`. This does not close any handles that are in use.

# PARAMETERS
1. `uri`: The URI to listen on. The path portion is ignored.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The computer is not listening on the specified URI.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**listen**(2)
