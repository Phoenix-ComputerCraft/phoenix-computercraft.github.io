<summary>sets the computer ID mapping for the specified IP</summary>
# NAME
arpset - sets the computer ID mapping for the specified IP

# LIBRARY
Standard system library, network module (*libsystem*, `system.network`)

# SYNOPSIS
**arpset**(*device*: string, *ip*: string, *id*: number?)

# DESCRIPTION
Sets the computer ID mapping for the specified IP on the requested device.

# PARAMETERS
1. `device`: The path to the modem to add for.
2. `ip`: The IP address of the target computer.
3. `id`: The computer ID of the target computer, or `nil` to remove the entry.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The current user is not root.
* The device is not present.
* The device is not a valid modem.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**arplist**(2)
