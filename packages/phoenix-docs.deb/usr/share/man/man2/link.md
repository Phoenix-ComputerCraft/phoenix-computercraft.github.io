<summary>creates a new symbolic link</summary>
# NAME
link - creates a new symbolic link

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**link**(*path*: string, *location*: string)

# DESCRIPTION
Creates a new symbolic link at a path, creating any parent directories if they don't exist.

# PARAMETERS
1. `path`: The path to the link to create.
2. `location`: The location the link should point to. This may be on another filesystem, as the link is symbolic.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The current user does not have permission to write the parent directory of the first directory created.
* The path already exists.

# HISTORY
Introduced in Phoenix 0.0.3.
