<summary>changes the owner of a file or directory</summary>
# NAME
chown - changes the owner of a file or directory

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**chown**(*path*: string, *user*: string)

# DESCRIPTION
Changes the owner of a file or directory, clearing the `setuser` bit if it's set.

# PARAMETERS
1. `path`: The path to the file to modify.
2. `user`: The user who will own the file.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The file does not exist.
* The current user is not the owner of the file or root.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**chmod**(2)
