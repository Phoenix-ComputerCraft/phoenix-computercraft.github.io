<summary>returns the arguments passed to the kernel</summary>
# NAME
kernargs - Returns the arguments passed to the kernel

# SYNOPSIS
**kernargs**(): table

# DESCRIPTION
Returns the arguments passed to the kernel in a key-value table.

# PARAMETERS
This syscall does not take any arguments.

# RETURN VALUE
A key-value table of all arguments passed to the kernel.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.4.
