<summary>acquires a resource from a semaphore object</summary>
# NAME
acquiresemaphore - acquires a resource from a semaphore object

# LIBRARY
Standard system library, synchronization module (*libsystem*, `system.sync`)

# SYNOPSIS
**acquiresemaphore**(*sem*: semaphore)

# DESCRIPTION
Acquires a resource from a semaphore object, waiting if none are available.

# PARAMETERS
1. `sem`: The semaphore to acquire.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**timeacquiresemaphore**(2), **releasesemaphore**(2)
