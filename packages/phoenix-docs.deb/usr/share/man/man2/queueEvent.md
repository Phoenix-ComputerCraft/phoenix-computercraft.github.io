<summary>queues an arbitrary event to be sent back to the current process</summary>
# NAME
queueEvent - queues an arbitrary event to be sent back to the current process

# LIBRARY
Standard system library, IPC module (*libsystem*, `system.ipc`)

# SYNOPSIS
**queueEvent**(*name*: string, *params*: table)

# DESCRIPTION
Queues an arbitrary event to be sent back to the current process.

# PARAMETERS
1. `name`: The name of the event to send.
2. `params`: The parameter list to send in the event.

# RETURN VALUES
This syscall does not return anything.

# ERRORS
This syscall does not throw errors.

# HISTORY
Introduced in Phoenix 0.0.1.
