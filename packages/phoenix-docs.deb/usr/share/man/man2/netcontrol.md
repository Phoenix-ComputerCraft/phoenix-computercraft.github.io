<summary>sends a control message to the specified IP address</summary>
# NAME
netcontrol - sends a control message to the specified IP address

# LIBRARY
Standard system library, network module (*libsystem*, `system.network`)

# SYNOPSIS
**netcontrol**(*ip*: string, *type*: string, *err*: string?)

# DESCRIPTION
Sends a control message to the specified IP address.

# PARAMETERS
1. `ip`: The IP address to send to
2. `type`: The message type to send. See **network**(5) for more information.
3. `err`: An optional error message to send if necessary.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The current user is not root.

# HISTORY
Introduced in Phoenix 0.0.1.
