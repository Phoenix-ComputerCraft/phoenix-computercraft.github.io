<summary>calls the specified method on the device</summary>
# NAME
devcall - calls the specified method on the device

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**devcall**(*device*: string, *method*: string, *args...*: any): any...

# DESCRIPTION
Calls the specified method on the device with arguments.

# PARAMETERS
1. `device`: The device path or UUID to operate on
2. `method`: The name of the method to call
3. `args...`: Any arguments to pass to the method

# RETURN VALUE
All values returned from the method.

# ERRORS
This syscall may throw an error if:
* The specified device does not exist.
* Another process has locked this device.
* The specified method does not exist on the device.
* The method threw an error while executing.

# HISTORY
Introduced in Phoenix 0.0.1.
