<summary>returns a list of currently loaded kernel module names</summary>
# NAME
listmodules - returns a list of currently loaded kernel module names

# SYNOPSIS
**listmodules**(): string[]

# DESCRIPTION
Returns a list of currently loaded kernel module names.

# PARAMETERS
This syscall does not take any arguments.

# RETURN VALUE
A list of currently loaded kernel module names.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.
