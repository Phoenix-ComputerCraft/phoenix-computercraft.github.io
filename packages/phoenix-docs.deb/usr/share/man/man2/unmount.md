<summary>unmounts the mount at the specified path</summary>
# NAME
unmount - unmounts the mount at the specified path

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**unmount**(*path*: string)

# DESCRIPTION
Unmounts the mount at the specified path.

# PARAMETERS
1. `path`: The path to the mount.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The path does not exist.
* The path specified is not a mount.
* The user does not have permission to write to the path.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**mount**(2), **mountlist**(2)
