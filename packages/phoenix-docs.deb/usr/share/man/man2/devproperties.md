<summary>returns a list of properties on the device</summary>
# NAME
devproperties - returns a list of properties on the device

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**devproperties**(*device*: string): string[]

# DESCRIPTION
Returns a list of properties on the device.

Properties are intended for use by wrapper APIs (such as `libsystem.hardware`), and specify an alternate name for a corresponding `get<Property>` method. To retrieve the property, capitalize the first character of the property name, prepend `get` to the name, and call that method on the device with no arguments. To set the property, first check for a `set<Property>` method in the same format as `get`, then call that method with one argument (the new value). If no `set` method is available, then that property is read-only.

# PARAMETERS
1. `device`: The device path or UUID to look up

# RETURN VALUE
A list of properties that are available. This table may be empty.

# ERRORS
This syscall may throw an error if:
* The specified device does not exist.

# HISTORY
Introduced in Phoenix 0.0.1.
