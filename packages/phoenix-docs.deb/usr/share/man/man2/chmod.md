<summary>changes the permissions of a file or directory</summary>
# NAME
chmod - changes the permissions of a file or directory

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**chmod**(*path*: string, *user*: string?, *mode*: number|string|table)

# DESCRIPTION
Changes the permissions (mode) of a file or directory for the specified user. If any setuser bit is specified, this will be applied for all users.

# PARAMETERS
1. `path`: The path to the file to modify.
2. `user`: The user to set the permissions for. If this is `nil`, sets the permissions for all users.
3. `mode`: A value representing the permissions. This may be:
  * A UNIX-style octal mode (e.g. `5`) - setuid bit is bit 4 (010)
  * A UNIX-style mode modification string, without the user specifier (e.g. `"+rx"`) (this does not work with `"-wx"` - use `"-xw"` instead)
  * A 3-character string with "r", "w", and "x" or "s" (or "-") (e.g. `"r-s"`)
  * A table with `read: boolean?`, `write: boolean?`, `execute: boolean?`, and `setuser: boolean?` fields (if a field is `nil`, it uses the previous value)

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The file does not exist.
* The current user is not the owner of the file or root.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**chown**(2)
