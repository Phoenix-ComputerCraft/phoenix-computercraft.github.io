<summary>unlocks the specified device</summary>
# NAME
devunlock - unlocks the specified device

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**devunlock**(*device*: string)

# DESCRIPTION
Unlocks the specified device, allowing access to the device in other processes. This syscall does nothing if the device is not locked.

# PARAMETERS
1. `device`: The device path or UUID to operate on

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The specified device does not exist.
* Another process has locked this device.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**devlock**(2)
