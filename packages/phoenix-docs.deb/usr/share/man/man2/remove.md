<summary>deletes a file at a path</summary>
# NAME
remove - deletes a file at a path

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**remove**(*path*: string)

# DESCRIPTION
Deletes a file at a path. If the file is a directory, this also removes all files and directories contained within it. If the file does not exist, this does nothing and returns successfully.

# PARAMETERS
1. `path`: The path to the file to delete.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The current user does not have permission to write the file.
* The current user does not have permission to write child subfiles and subdirectories.
* The current user does not have permission to write the parent directory.

# HISTORY
Introduced in Phoenix 0.0.1.
