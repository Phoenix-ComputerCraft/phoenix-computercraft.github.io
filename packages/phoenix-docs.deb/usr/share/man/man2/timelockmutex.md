<summary>locks the specified mutex, waiting until the mutex is unlocked or timeout</summary>
# NAME
timelockmutex - locks the specified mutex, waiting until the mutex is unlocked or timeout

# LIBRARY
Standard system library, synchronization module (*libsystem*, `system.sync`)

# SYNOPSIS
**timelockmutex**(*mtx*: mutex, *timeout*: number): boolean

# DESCRIPTION
Locks the specified mutex, waiting for the resource to be freed before claiming it. If the mutex isn't unlocked after the specified timeout, the syscall returns without locking.

# PARAMETERS
1. `mtx`: The mutex to lock.
2. `timeout`: The amount of time to wait in seconds.

# RETURN VALUE
Whether the mutex could be locked.

# ERRORS
This syscall may throw an error if:
* The mutex is already claimed by the current thread and is not recursive.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**lockmutex**(2), **unlockmutex**(2)
