<summary>sets or removes an alias for a device</summary>
# NAME
devalias - sets or removes an alias for a device

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**devalias**(*device*: string, *alias*: string?)

# DESCRIPTION
Sets or removes an alias for a device.

# PARAMETERS
1. `device`: The device path or UUID to modify
2. `alias`: The new alias to set (`nil` to remove)

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The specified device does not exist.

# HISTORY
Introduced in Phoenix 0.0.1.
