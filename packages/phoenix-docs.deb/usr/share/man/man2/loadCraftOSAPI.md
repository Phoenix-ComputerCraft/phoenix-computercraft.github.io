<summary>loads a CraftOS API or module from the ROM</summary>
# NAME
loadCraftOSAPI - loads a CraftOS API or module from the ROM

# SYNOPSIS
**loadCraftOSAPI**(*apiName*: string): table

# DESCRIPTION
Loads a CraftOS API or module from the ROM. This can be used to get access to certain functions without having to mount the entire ROM.

This uses the current process's environment as the parent environment. This means the API will use the process's globals. If the API you need requires certain globals (like `colors`), load these in as globals first.

# PARAMETERS
1. `apiName`: The name of the API or module to load. If this starts with `cc.`, it loads a module from `rom/modules/main`. Otherwise, it loads an API from `rom/apis`.

# RETURN VALUE
A table with the loaded API or module.

# ERRORS
This syscall may throw an error if:
* The API name is malformed.
* The API does not exist.
* An error occurred while loading the API.

# HISTORY
Introduced in Phoenix 0.0.1.
