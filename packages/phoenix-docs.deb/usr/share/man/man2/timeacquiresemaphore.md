<summary>acquires a resource from a semaphore object, waiting until available or timeout</summary>
# NAME
timeacquiresemaphore - acquires a resource from a semaphore object, waiting until available or timeout

# LIBRARY
Standard system library, synchronization module (*libsystem*, `system.sync`)

# SYNOPSIS
**timeacquiresemaphore**(*sem*: semaphore, *timeout*: number): boolean

# DESCRIPTION
Acquires a resource from a semaphore object, waiting if none are available, until the specified timeout passes.

# PARAMETERS
1. `sem`: The semaphore to acquire.
2. `timeout`: The amount of time to wait in seconds.

# RETURN VALUE
Whether a resource was successfully acquired.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**acquiresemaphore**(2), **releasesemaphore**(2)
