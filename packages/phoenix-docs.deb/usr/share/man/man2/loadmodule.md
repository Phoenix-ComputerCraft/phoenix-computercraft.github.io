<summary>attempts to load a kernel module into memory</summary>
# NAME
loadmodule - attempts to load a kernel module into memory

# SYNOPSIS
**loadmodule**(*path*: string)

# DESCRIPTION
Attempts to load a kernel module into memory. This syscall requires root.

# PARAMETERS
1. `path`: The path to the module to load.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The user is not root.
* The path refers to a directory.
* The module is either not owned by root or world-writable.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**unloadmodule**(2)
