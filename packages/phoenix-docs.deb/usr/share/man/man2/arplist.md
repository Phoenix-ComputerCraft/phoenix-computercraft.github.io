<summary>returns the list of known IP to computer ID mappings</summary>
# NAME
arplist - returns the list of known IP to computer ID mappings

# LIBRARY
Standard system library, network module (*libsystem*, `system.network`)

# SYNOPSIS
**arplist**(*device*: string): {[string] = number}

# DESCRIPTION
Returns the list of known IP to computer ID mappings for the specified device.

# PARAMETERS
1. `device`: The path to the modem to query for.

# RETURN VALUE
A key-value table of mappings from IP addresses to computer IDs.

# ERRORS
This syscall may throw an error if:
* The device is not present.
* The device is not a valid modem.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**arpset**(2)
