<summary>renames a file or directory from one path to another</summary>
# NAME
rename - renames a file or directory from one path to another

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**rename**(*from*: string, *to*: string)

# DESCRIPTION
Renames (moves) a file or directory from one path to another. The source and destination must be on the same filesystem.

# PARAMETERS
1. `from`: The file to move.
2. `to`: The new destination path for the file.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The original file does not exist.
* The new file already exists.
* The current user does not have permission to read the original file.
* The current user does not have permission to write the new file.
* The current user does not have permission to write the parent directory of the new file.

# HISTORY
Introduced in Phoenix 0.0.1.
