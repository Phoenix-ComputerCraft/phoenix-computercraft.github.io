<summary>releases a resource from a semaphore</summary>
# NAME
releasesemaphore - releases a resource from a semaphore

# LIBRARY
Standard system library, synchronization module (*libsystem*, `system.sync`)

# SYNOPSIS
**releasesemaphore**(*sem*: semaphore)

# DESCRIPTION
Releases a resource from a semaphore. This is a guaranteed atomic alternative to `sem.count = sem.count + 1`, and should be preferred.

# PARAMETERS
1. `sem`: The semaphore to release.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**acquiresemaphore**(2)
