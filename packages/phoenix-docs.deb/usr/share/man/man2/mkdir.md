<summary>creates a new directory</summary>
# NAME
mkdir - creates a new directory

# LIBRARY
Standard system library, filesystem module (*libsystem*, `system.filesystem`)

# SYNOPSIS
**mkdir**(*path*: string)

# DESCRIPTION
Creates a new directory at a path, creating any parent directories if they don't exist. If the directory already exists, this function does nothing and exits successfully.

# PARAMETERS
1. `path`: The path of the directory to create.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The current user does not have permission to write the parent directory of the first directory created.
* A path component already exists and is a file.

# HISTORY
Introduced in Phoenix 0.0.1.
