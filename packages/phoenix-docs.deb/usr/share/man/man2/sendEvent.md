<summary>queues a remote event to be sent to another process</summary>
# NAME
sendEvent - queues a remote event to be sent to another process

# LIBRARY
Standard system library, IPC module (*libsystem*, `system.ipc`)

# SYNOPSIS
**sendEvent**(*pid*: number, *name*: string, *params*: any)

# DESCRIPTION
Queues a remote event to be sent to another process. This creates an event called `remote_event` with the name and parameters passed as parameters. It does *not* allow sending arbitrary events to a process.

# PARAMETERS
1. `pid`: The ID of the process to send to.
2. `name`: The name of the remote event to send.
3. `params`: The data to send with the event.

# RETURN VALUES
This syscall does not return anything.

# ERRORS
This syscall does not throw errors.

# HISTORY
Introduced in Phoenix 0.0.1.
