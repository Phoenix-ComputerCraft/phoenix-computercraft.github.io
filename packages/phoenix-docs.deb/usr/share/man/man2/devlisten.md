<summary>enables listening for events from this device</summary>
# NAME
devlisten - enables listening for events from this device

# LIBRARY
Standard system library, hardware module (*libsystem*, `system.hardware`)

# SYNOPSIS
**devlisten**(*device*: string, *state*: boolean = true)

# DESCRIPTION
Enables (or disables) listening for events from this device.

# PARAMETERS
1. `device`: The device path or UUID to operate on
2. `state`: `true` to allow events to be passed to this process; `false` to stop events from being sent

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The specified device does not exist.

# HISTORY
Introduced in Phoenix 0.0.1.
