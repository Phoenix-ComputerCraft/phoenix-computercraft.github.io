<summary>unlocks the specified mutex</summary>
# NAME
unlockmutex - unlocks the specified mutex

# LIBRARY
Standard system library, synchronization module (*libsystem*, `system.sync`)

# SYNOPSIS
**unlockmutex**(*mtx*: mutex)

# DESCRIPTION
Unlocks the specified mutex.

# PARAMETERS
1. `mtx`: The mutex to unlock.

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* The mutex is already unlocked.
* The mutex is currently locked by a different thread.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**lockmutex**(2)
