<summary>returns whether the specified URI is valid</summary>
# NAME
checkuri - returns whether the specified URI is valid

# LIBRARY
Standard system library, network module (*libsystem*, `system.network`)

# SYNOPSIS
**checkuri**(*uri*: string): boolean

# DESCRIPTION
Returns whether the specified URI is valid and the scheme is supported.

# PARAMETERS
1. `uri`: The URI to check

# RETURN VALUE
Whether the URI is valid. This will always return `false` for an unsupported URI scheme. For HTTP and WebSocket URLs, this will check that the URL can be connected to as well.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.
