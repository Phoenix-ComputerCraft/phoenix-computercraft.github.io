<summary>removes the specified route from the specified table</summary>
# NAME
routedel - removes the specified route from the specified table

# LIBRARY
Standard system library, network module (*libsystem*, `system.network`)

# SYNOPSIS
**routedel**(*source*: string, *mask*: number, *num*: number?)

# DESCRIPTION
Removes the specified route from the specified table.

# PARAMETERS
1. `source`: The source IP address to remove in CIDR notation (e.g. `192.168.0.0/16`)
2. `mask`: The netmask prefix length of the IP to remove
3. `num`: The table number to modify as an integer starting at 1 (default 1)

# RETURN VALUE
This syscall does not return anything.

# ERRORS
This syscall may throw an error if:
* A non-root user attempted to remove routes.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**routeadd**(2)
