<summary>returns a list of route entries in the specified route table</summary>
# NAME
routelist - returns a list of route entries in the specified route table

# LIBRARY
Standard system library, network module (*libsystem*, `system.network`)

# SYNOPSIS
**routelist**(*num*: number?): table?

# DESCRIPTION
Returns a list of route entries in the specified route table.

# PARAMETERS
1. `num`: The table number to check as an integer starting at 0 (default 1)

# RETURN VALUE
A list of route entries with the following fields:
* `source: string`: The bottom end of the source IP range.
* `sourceNetmask: number`: The source subnet mask. For a single IP, this is 32. For all IPs (`default`), this is 0.
* `action: string`: The action to take on the message. Valid values:
  * `"unicast"`: Send all messages to the specified destination.
  * `"broadcast"`: Broadcast the message to all destinations on the device.
  * `"local"`: Send the message to a known destination on a local network.
  * `"unreachable"`: Send a Destination Unreachable message back to the sender.
  * `"prohibit"`: Send a Prohibit message back to the sender.
  * `"blackhole"`: Ignore the message altogether.
* `device: string?`: The device path to send the message to.
* `destination: string?`: The destination IP to forward to.

If the specified table does not exist, this will return `nil`.

# ERRORS
This syscall does not throw any errors.

# HISTORY
Introduced in Phoenix 0.0.1.

# SEE ALSO
**routeadd**(2), **routedel**(2)
