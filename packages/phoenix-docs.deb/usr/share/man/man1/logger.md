<summary>view, post to, create, and delete logs</summary>
# NAME
logger - view, post to, create, and delete logs

# SYNOPSIS
**logger log** [**-n** *log name*] [**-c** *category*] [**-l** **debug**|**info**|**notice**|**warning**|**error**|**critical**] [**-m** *module*] *message* ...
**logger create** [**-F** *path*] [**-s**] *log name*
**logger delete** [**-p**] *log name*
**logger view** *log name*
**logger follow** [**-f** *filter*] *log name*

# DESCRIPTION
**logger** provides a simple command-line interface to the system logger module. It allows viewing logs (including streaming), posting messages to a log, and creating and deleting logs.

# PARAMETERS
For the **log** subcommand:

**-c** *category*  
    Sets the category for the message.

**-l** **debug**|**info**|**notice**|**warning**|**error**|**critical**  
    Sets the level of the log messgae.

**-m** *module*  
    Sets the name of the module for the message.

**-n** *log name*  
    Sets the name of the log to write to.

For the **create** subcommand:

**-F** *path*  
    Sets the file to write logs to.

**-s**  
    Specifies that the log should be streamable.

For the **delete** subcommand:

**-p**  
    Purges all logs on disk.

For the **follow** subcommand:

**-f** *filter*  
    Specifies a filter expression to apply to the listener.
    
    A filter consists of a series of clauses separated by semicolons. Each clause consists of a name, operator, and one or more values separated by bars (`|`). String values may be surrounded with double quotes to allow semicolons, bars, and leading spaces. If multiple values are specified, any value matching will cause the clause to resolve to true. All clauses must be true for the filter to match.
    
    Available operators: `==`, `!=`/`~=`, `=%` (match), `!%`/`~%` (not match), `<`, `<=`, `>=`, `>` (numbers only).
    
    Example: `level == 3 | 4 | 5; category != filesystem; process > 0; message =% "Unexpected error"`

# HISTORY
Introduced in baseutils 0.2.

# SEE ALSO
**syslog**(2), **system.log**(3)
