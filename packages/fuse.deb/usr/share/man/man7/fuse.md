<summary>filesystem in userspace kernel module</summary>
# NAME
fuse - filesystem in userspace kernel module

# DESCRIPTION
**fuse** is a kernel module that implements an interface for filesystems written
in userspace. This allows user programs to create and mount filesystem types
without needing to load a kernel module. Filesystem operations are executed in a
user-mode process, with the results being sent back to the process that requested
the operation.

# USAGE
To mount a **fuse**-based filesystem, simply use the **mount**(1) command with
the filesystem type **fuse**, and pass the filesystem to mount in the **fs**
option. For example, an FTP filesystem could be mounted with the following command:

```sh
mount -t fuse -o fs=ftp,pasv ftp://user:password@10.0.1.1 /mnt/ftpshare
```

This will mount the `ftp` filesystem (from `/lib/fuse/ftp.lua`) to `/mnt/ftpshare`,
using the mount source `ftp://user:password@10.0.1.1` and passing the `pasv`
option to the filesystem.

Filesystem modules are located in `/lib/fuse` by default. Filesystems located in
other locations may be loaded by passing the path as the `fs` option.

# WRITING FILESYSTEMS
A **fuse** filesystem is simply a Lua library which returns a table with the
required filesystem methods. The library is run with two parameters: the path to
the filesystem to mount, and a key-value table with the mount options. It is run
in a thread under the process that called **mount**(2) (usually **mount**(1)).

Each method in the filesystem is called with at least two arguments: the table
returned (as in `:` methods), and a process table filled from **getpinfo**(2).
Most methods also have at least one path argument as a string. There is no need
to do argument type checking: this is done in the kernel before calling the
filesystem methods.

The following methods are expected to be exported by the filesystem:

```ts
interface Filesystem {
    open(self: table, process: ProcessInfo, path: string, mode: string): table | string | ((data: string, reset: boolean): void);
    list(self: table, process: ProcessInfo, path: string): string[];
    stat(self: table, process: ProcessInfo, path: string, nolink?: boolean): Stat?;
    remove(self: table, process: ProcessInfo, path: string): void;
    rename(self: table, process: ProcessInfo, path: string, to: string): void;
    mkdir(self: table, process: ProcessInfo, path: string): void;
    link(self: table, process: ProcessInfo, path: string, location: string): void;
    mkfifo(self: table, process: ProcessInfo, path: string): void;
    chmod(self: table, process: ProcessInfo, path: string, user: string | nil, mode: string | number | table): void;
    chown(self: table, process: ProcessInfo, path: string, owner: string): void;
    unmount?(self: table, process: ProcessInfo): void;
    init?(self: table, process: ProcessInfo): void;
}
```

All functions are optional, but calls on unimplemented functions will throw an
error to the caller. A minimal filesystem should implement at least `open`,
`list`, and `stat`. The `unmount` method is called when the filesystem is about
to be unmounted, and can be used to clean up resources before unmounting. If it
is not present, no error is emitted, and the filesystem is removed as usual. The
`init` method is called right after the filesystem is mounted, and can be used
to initialize certain things that have to run on the client process.

Most methods function the same as their respective syscalls. However, the `open`
method has extra functionality: if it returns a string, then a read file handle
will be synthesized automatically (with a second boolean return value indicating
whether it should be binary). Likewise, if it returns a function, it'll return
a write file handle which will call the function to flush data to the file. This
can be used to simplify basic file open operations, reducing code duplication in
the process.

Each mounted filesystem is given its own process to run as, which is forked from
the initial mount process, and is disconnected from TTYs. Methods are called in
new threads under that process. When the filesystem is unmounted, the main
thread exits, which will cause the process to exit once the last remaining
filesystem method returns.

# EXAMPLES
Here is an example of a minimal filesystem:

```lua
local fs = {}

function fs:open(process, path, mode)
    if path == "" then return nil, "Is a directory"
    elseif path == "zero" then
        if mode:find "[wa]" then
            return {
                close = function() end,
                seek = function() end,
                write = function() end,
                writeLine = function() end,
                flush = function() end
            }
        end
        return {
            close = function() end,
            seek = function() end,
            read = function(n)
                if not n then return 0
                else return ("\0"):rep(n) end
            end,
            readLine = function() return "" end,
            readAll = function() return "" end
        }
    elseif path == "random" then
        if mode:find "[wa]" then
            return {
                close = function() end,
                seek = function() end,
                write = function() end,
                writeLine = function() end,
                flush = function() end
            }
        end
        return {
            close = function() end,
            seek = function() end,
            read = function(n)
                if not n then return math.random(0, 255)
                else
                    local s = ""
                    for i = 1, n do s = s .. string.char(math.random(0, 255)) end
                    return s
                end
            end,
            readLine = function() return "" end,
            readAll = function() return "" end
        }
    else return nil, "No such file" end
end

function fs:list(process, path)
    if path == "" then
        return {"zero", "random"}
    else
        error("No such directory")
    end
end

function fs:stat(process, path)
    if path == "zero" then
        return {
            size = 0,
            type = "file",
            created = 0,
            modified = 0,
            owner = "root",
            permissions = {},
            worldPermissions = {read = true, write = false, execute = false},
            setuser = false,
            capacity = 0,
            freeSpace = 0,
            special = {}
        }
    elseif path == "random" then
        return {
            size = 0,
            type = "file",
            created = 0,
            modified = 0,
            owner = "root",
            permissions = {},
            worldPermissions = {read = true, write = false, execute = false},
            setuser = false,
            capacity = 0,
            freeSpace = 0,
            special = {}
        }
    elseif path == "" then
        return {
            size = 0,
            type = "directory",
            created = 0,
            modified = 0,
            owner = "root",
            permissions = {},
            worldPermissions = {read = true, write = false, execute = true},
            setuser = false,
            capacity = 0,
            freeSpace = 0,
            special = {}
        }
    else return nil end
end

return fs
```

# SEE ALSO
**mount**(1)

# AUTHORS
**fuse** was written by JackMacWindows, based on the concepts of FUSE/libfuse
for *nix.
