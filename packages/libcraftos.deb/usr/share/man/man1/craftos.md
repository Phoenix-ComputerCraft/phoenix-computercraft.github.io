<summary>run CraftOS programs under Phoenix</summary>
# NAME
    craftos - run CraftOS programs under Phoenix

# SYNOPSIS
    **craftos** *program path* [*arguments ...*]

# DESCRIPTION
**craftos** allows running programs written for CraftOS on top of Phoenix. It
uses *libcraftos* to implement a compatibility layer between CraftOS APIs and
Phoenix system calls. It loads all of the CraftOS APIs into the program's global
table, and then executes the program with the specified arguments.

**craftos** functions as if the program was called from the CraftOS shell, or
using `shell.run`. It should be compatible with many programs, but some that
require specific details of CraftOS's inner workings may not be compatible.

# HISTORY
Introduced in libcraftos 0.1.

# SEE ALSO
**shell**(1)
