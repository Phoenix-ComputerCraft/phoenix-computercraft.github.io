<summary>CraftOS shell wrapper for Phoenix</summary>
# NAME
    shell - CraftOS shell wrapper for Phoenix

# SYNOPSIS
    **shell**

# DESCRIPTION
**shell** executes the CraftOS shell program using libcraftos. It requires the
ROM to be mounted at `/rom` - if run as root, it will automatically mount the
ROM as needed.

The filesystem is the same as the Phoenix filesystem, so all Phoenix files will
still be present in the shell. Compatibility caveats with libcraftos still apply,
but the `shell`, `package`, and `require` APIs will be replaced with the
original CraftOS versions, so issues relating to those will no longer apply.

Phoenix programs will still be executable in the CraftOS shell. However, the
programs will execute in the same process context as the shell. This means that
calls that affect global process state, such as **exit**(2) or **stdin**(2),
will also affect the shell, as well as other programs run in the shell (e.g.
calling **exit**(2) will quit the entire shell).

# HISTORY
Introduced in libcraftos 0.2.

# SEE ALSO
**craftos**(1)
