menuentry"CraftOS"{description"Boot into CraftOS.",craftos}
