local rootDirectory = ""
defaultentry = "Phoenix"
timeout = 10
backgroundcolor = colors.black
selectcolor = colors.orange
titlecolor = colors.lightGray

menuentry "Phoenix" {
    description "Boot Phoenix normally.";
    kernel (rootDirectory .. "/boot/kernel.lua");
    args ("init=/sbin/init root=" .. rootDirectory);
}

menuentry "CraftOS" {
    description "Boot into CraftOS.";
    craftos;
}
