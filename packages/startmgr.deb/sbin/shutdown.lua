local a=require"startmgr"local b=require"system.process"local c=require"system.util"local d=assert(c.argparse({P=false,poweroff="@P",H="@P",halt="@P",h="@P",r=false,reboot="@r",c=false,show=false,help=false},...))if d.help then print[[
Usage: shutdown [OPTIONS] [TIME]
Options:
  --help          Show this help
  -H, --halt      Equivalent to -P
  -P, --poweroff  Power off the machine
  -r, --reboot    Reboot the machine
  -h              Equivalent to -P
  -c              Cancel a pending shutdown
  --show          Show pending shutdown
]]end;local e={31,28,31,30,31,30,31,31,30,31,30,31}local function f(g)return g%4==0 and(g%100~=0 or g%400==0)end;if d.c then return a.remove("shutdown-timer","root")elseif d.show then local h=a.status("shutdown-timer","root")if h then else print("No scheduled shutdown.")end else local i=d[1]or"+1"if i=="+0"or i=="now"then if d.r and not d.P then assert(a.reboot())else assert(a.shutdown())end else local j;if i:match"^%+%d+$"then j=tonumber(i:match"^%+(%d+)$")*60 elseif i:match"^%d+:%d+$"then local k,l=i:match"^(%d+):(%d+)$"k,l=tonumber(k),tonumber(l)if k<0 or k>23 or l<0 or l>59 then error("shutdown: Invalid argument")end;local m=os.date("!*t")if k<m.hour or k==m.hour and l<m.min then m.day=m.day+1;m.wday=(m.wday+1)%7;m.yday=(m.yday+1)%(f(m.year)and 366 or 365)if m.day>e[m.month]or m.month==2 and f(m.year)and m.day>29 then m.day=1;m.month=m.month+1;if m.month>12 then m.month=1;m.year=m.year+1 end end end;m.hour,m.min,m.sec=k,l,0;j=os.time(m)-os.time()else error("shutdown: Invalid argument")end;assert(a.add([[
name = "shutdown-timer"
unit.description = "Shutdown Timer"
function trigger()
    startmgr.]]..(d.r and not d.P and"reboot"or"shutdown")..[[()
end
timer.loadTime = ]]..j,"root"))end end
