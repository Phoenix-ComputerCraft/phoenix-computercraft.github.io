<summary>add drives to an existing span</summary>
# NAME
    spanadd - add drives to an existing span

# SYNOPSIS
    **spanadd** *mount point* *drives ...*

# DESCRIPTION
**spanadd** adds one or more disk drives to an existing span filesystem. This
allows effectively resizing the span.

The first argument points to the span to resize. The span must be mounted to be
able to add drives.

Each remaining argument is the device name of the drive to add. This can be a
device ID, UUID, or path, as would be used with hardware APIs. **The disk in the drives will be erased.**

The filesystem must be remounted for the changes to take effect.

# HISTORY
Introduced in spanfs 0.1.

# SEE ALSO
**mkspanfs**(8)
