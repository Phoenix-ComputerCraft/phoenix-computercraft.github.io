<summary>shows information about a span</summary>
# NAME
    spaninfo - shows information about a span

# SYNOPSIS
    **spaninfo** *mount path*

# DESCRIPTION
**spaninfo** shows various information about a mounted span, including UUID, name,
capacity, free space, and space info on individual disks.

# HISTORY
Introduced in spanfs 0.1.
