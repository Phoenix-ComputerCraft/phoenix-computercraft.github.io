<summary>Create and format new spanfs disks</summary>
# NAME
mkspanfs - Create and format new spanfs disks

# SYNOPSIS
**mkspanfs** *volume name* *index drive* *data drive* ...

# DESCRIPTION
**mkspanfs** creates a new *spanfs* filesystem across the drives specified,
using the volume name given as the first argument to name the volume. The command
will first verify that all drives provided are valid, and prompts the user to
confirm that these drives are correct. Once confirmed, all disks are erased and
formatted with a new *spanfs* filesystem with the specified name and a random
UUID. After creation, the disk usage stats are reported.

# EXAMPLE
Create a new volume named *Span Volume* on four disks, using `drive_0` to store
the index.

`mkspanfs "Span Volume" drive_0 drive_1 drive_2 drive_3`

# SEE ALSO
**spanfs**(7)