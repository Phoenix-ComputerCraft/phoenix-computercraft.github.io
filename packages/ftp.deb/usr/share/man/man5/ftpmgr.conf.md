<summary>configuration file for ftpmgr</summary>

# NAME
    **ftpmgr.conf** - configuration file for ftpmgr

# SYNOPSIS
    /etc/ftpmgr.conf

# DESCRIPTION
The /etc/ftpmgr.conf file configures settings for the **ftpmgr(8)** FTP server.

The file uses a code-like syntax, with comments using `#`. Options are set using *key* **=** *value* **;** syntax, and users are defined using **user "** *name* **" {** *options* **}**. Strings may be delimited with **"** or **'**. `#` characters in strings are not recommended, as they may be mistaken for comments while parsing.

# GLOBAL OPTIONS
* **ip =** *string*: The IP address to serve on. "0.0.0.0" indicates any IP/interface.
* **port =** *number*: The port to serve the command stream on. FTP standard is 21.
* **passivePortRange = {** *number* **,** *number* **}**: The range of ports to reserve for passive connections.
* **allUsers =** *boolean*: Whether to allow all users on the system to log in. These users will use their system username and password for login, and have access to the full system root with their permissions. This requires **usermgr(8)** to be installed.

# USER OPTIONS
There are three methods of authentication available:
* No authentication: No password is required for the user. This is used when `useSystemLogin` is false, and no password or hash is set.
* Password authentication: A password for the user is supplied in the config file. This is used when `password` or `passwordHash` is set for a user.
* System authentication: The user's password is stored in the system database (i.e. **passwd(5)**), and authentication is done through **usermgr(8)**, which must be installed. This is used when `useSystemLogin` is true (default) and no `password` is set.

A user named `anonymous` is used when no username or password is entered. It is disabled by default for security, but can be configured to provide, for example, public read-only access to a certain folder on the system.

The following options may be configured in each user directive:
* **systemUser =** *string*: The Phoenix username to run the server as. Defaults to the name of the FTP user.
* **password =** *string*: The password for the user in plaintext.
* **passwordHash =** *string*: The hex SHA-256 hash of the password + hash.
* **useSystemLogin =** *boolean*: Whether to use system credentials for the user (requires **usermgr(8)**). Defaults to true. Overridden by `password` and `passwordHash`.
* **allowWrite =** *boolean*: Whether to allow writing files, irrespective of the system user's permissions. Defaults to true.
* **root =** *string*: The root of the filesystem to expose to the share. Defaults to `/`.

# SEE ALSO
**ftpmgr(8)**
