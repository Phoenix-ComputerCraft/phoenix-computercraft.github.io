local a=require"system.filesystem"local b=require"system.process"local c=require"system.util"c.syscall.mklog("install",false,"/var/log/install.log")a.mkdir("/tmp/_pkg")a.mount("tmpfs","","/tmp/_pkg",{})for d,e in ipairs(a.list("/tmp/pkg"))do a.move("/tmp/pkg/"..e,"/tmp/_pkg/"..e)end;a.remove("/tmp/pkg")a.remove("/boot/kernel.lua")local f,g=c.syscall.openterm()if not f then c.syscall.syslog({name="install",level=4},"An error occurred while starting the installer:",g,"The system will restart in 5 seconds.")c.sleep(5)c.syscall.devcall("/","reboot")end;f.setPaletteColor(1,0xD06018)f.setPaletteColor(0,0xD8D8D8)local h,i=f.getSize()local function j(k)f.setCursorPos(3,i)f.setBackgroundColor(0)f.setTextColor(15)f.clearLine()f.write(k)end;f.setBackgroundColor(1)f.setTextColor(0)f.clear()f.setCursorBlink(false)f.setCursorPos(2,2)f.write("Phoenix Setup")f.setCursorPos(1,3)f.write(("\x8C"):rep(15))f.setCursorPos(3,5)f.write("Please wait while Phoenix installs the")f.setCursorPos(3,6)f.write("requested components.")f.setCursorPos(3,7)f.write("\x9C"..("\x8C"):rep(h-6))f.setBackgroundColor(0)f.setTextColor(1)f.write("\x93")for l=8,i-2 do f.setCursorPos(f.getCursorPos()-1,l)f.write("\x95")end;f.setBackgroundColor(1)f.setTextColor(0)for l=8,i-2 do f.setCursorPos(3,l)f.write("\x95")end;f.setCursorPos(3,i-1)f.write("\x8D"..("\x8C"):rep(h-6).."\x8E")local m=c.syscall.mktty(h-6,i-9)local n=dofile("install_config.lua")local o=true;local p=b.fork(function()c.syscall.stdout(m)while true do local q,r=coroutine.yield()if q=="remote_event"then if r.type=="write"then c.syscall.syslog({name="install"},r.data.data)io.stdout:write(r.data.data)elseif r.type=="exit"then break end end end end,"tty helper")b.newthread(function()while o do for s=1,m.size.height do f.setCursorPos(4,s+7)f.blit(table.unpack(m[s]))end;c.sleep(0.2)end end)local function t(...)local u=b.fork(function(...)c.syscall.stdout({write=function(v)c.syscall.sendEvent(p,"write",{data=v})end})b.exec(...)end,"",...)while true do local q,r=coroutine.yield()if q=="process_complete"and r.id==u then if r.error or r.traceback then o=false;c.syscall.sendEvent(p,"exit",{})f.setBackgroundColor(1)f.setTextColor(0)f.clear()f.setCursorPos(2,2)f.write("Phoenix Setup")f.setCursorPos(1,3)f.write(("\x8C"):rep(15))f.setCursorPos(3,5)f.write("An error occurred while installing Phoenix.")f.setCursorPos(3,6)f.write("Please check /var/log in the root for more")f.setCursorPos(3,7)f.write("information.")f.setCursorPos(3,9)f.write("Press ENTER to restart into CraftOS.")j("ENTER=Reboot")repeat local q,r=coroutine.yield()until q=="key"and r.keycode==10;return c.syscall.devcall("/","reboot")end;break end end end;if n.spanfs then j("Mounting root span...")a.mkdir("/mnt")a.mount("spanfs",n.spanfs,"/mnt",{})for d,e in ipairs(a.list("/"))do if e~="mnt"and e~="boot"and e~="tmp"then a.copy("/"..e,"/mnt/"..e)end end;a.mkdir("/mnt/tmp/_pkg")a.unmount("/mnt")a.unmount("/")a.mount("spanfs",n.spanfs,"/",{})a.mkdir("/boot")a.mount("craftos",a.combine(n.rootdir,"boot"),"/boot",{})a.mkdir("/mnt")a.mount("craftos",n.rootdir,"/mnt",{})os.remove("/mnt/lib")os.remove("/mnt/mnt")os.remove("/mnt/tmp")os.remove("/mnt/usr")a.unmount("/mnt")else a.remove("/lib/modules/spanfs.lua")end;for d,w in ipairs(n.components)do j("Installing: "..w)t("/usr/bin/dpkg.lua","-i","/tmp/_pkg/"..w..".deb")a.remove("/tmp/_pkg/"..w..".deb")if w=="libsystem"then a.remove("/lib/system")end end;j("Finalizing system...")local u=b.start("/usr/libexec/usermgr")c.syscall.sendEvent(p,"write",{data="Creating user... (PID "..u..")\n"})repeat c.sleep(0.1)until c.syscall.lookup("usermgr")b.run("/usr/bin/useradd",n.username,"-p",n.password,"-m")if n.spanfs then c.syscall.sendEvent(p,"write",{data="Creating initrd...\n"})local x=io.open("/etc/initrd/initrd.conf","r")if x then local v=""for y in x:lines("*L")do if y:match"^modules"then v=v..'modules = {"spanfs"}\n'else v=v..y end end;x:close()x=io.open("/etc/initrd/initrd.conf","w")if x then x:write(v)x:close()end end;x=io.open("/etc/fstab","a")if x then x:write(a.combine(n.rootdir,"boot").." /boot craftos defaults,auto 0 0\n")x:close()end;t("/usr/bin/update-initrd.lua")c.syscall.sendEvent(p,"write",{data="Setting up pxboot config...\n"})x=io.open("/boot/config.lua","w")if x then x:write("local rootDirectory, uuid = '"..n.rootdir.."', '"..n.spanfs..[['
defaultentry = "Phoenix"
timeout = 10
backgroundcolor = colors.black
selectcolor = colors.orange
titlecolor = colors.lightGray

menuentry "Phoenix" {
    description "Boot Phoenix normally.";
    kernel (rootDirectory .. "/boot/kernel.lua");
    args ("init=/sbin/init initrd=" .. rootDirectory .. "/boot/initrd.img root=" .. uuid .. " rootfstype=spanfs");
}

menuentry "Phoenix (single)" {
    description "Boot Phoenix in single user mode.";
    kernel (rootDirectory .. "/boot/kernel.lua");
    args ("init=/bin/cash initrd=" .. rootDirectory .. "/boot/initrd.img root=" .. uuid .. " rootfstype=spanfs");
}

menuentry "CraftOS" {
    description "Boot into CraftOS.";
    craftos;
}

include "config.lua.d/*"
]])x:close()end else c.syscall.sendEvent(p,"write",{data="Setting up pxboot config...\n"})local x=io.open("/boot/config.lua","w")if x then x:write("local rootDirectory = '"..n.rootdir..[['
defaultentry = "Phoenix"
timeout = 10
backgroundcolor = colors.black
selectcolor = colors.orange
titlecolor = colors.lightGray

menuentry "Phoenix" {
    description "Boot Phoenix normally.";
    kernel (rootDirectory .. "/boot/kernel.lua");
    args ("init=/sbin/init root=" .. rootDirectory);
}

menuentry "Phoenix (single)" {
    description "Boot Phoenix in single user mode.";
    kernel (rootDirectory .. "/boot/kernel.lua");
    args ("init=/bin/cash root=" .. rootDirectory);
}

menuentry "CraftOS" {
    description "Boot into CraftOS.";
    craftos;
}

include "config.lua.d/*"
]])x:close()end end;c.syscall.sendEvent(p,"write",{data="Cleaning up...\n"})if n.spanfs then a.mount("craftos",n.rootdir,"/mnt",{})os.remove("/mnt/install_config.lua")os.remove("/mnt/install_stage2.lua")os.remove("/mnt/var")a.unmount("/mnt")end;os.remove("/install_config.lua")os.remove("/install_stage2.lua")os.remove("/boot/unbios.lua")os.remove("/var/log/default.log")os.remove("/var/log/install.log")a.unmount("/tmp/_pkg")a.remove("/tmp/_pkg")o=false;c.syscall.sendEvent(p,"exit",{})c.syscall.kill(u,15)f.setBackgroundColor(1)f.setTextColor(0)f.clear()f.setCursorPos(2,2)f.write("Phoenix Setup")f.setCursorPos(1,3)f.write(("\x8C"):rep(15))f.setCursorPos(3,5)f.write("The Phoenix installation is complete, and the")f.setCursorPos(3,6)f.write("system is ready for use. To start using Phoenix")f.setCursorPos(3,7)f.write("the computer has to restart.")f.setCursorPos(3,9)f.write("Press ENTER to restart into Phoenix.")j("ENTER=Reboot")repeat local q,r=coroutine.yield()until q=="key"and r.keycode==10;return c.syscall.devcall("/","reboot")
