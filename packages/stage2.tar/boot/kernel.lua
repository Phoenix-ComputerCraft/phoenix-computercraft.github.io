-- Phoenix Kernel v0.0.1
--
-- Copyright (c) 2021-2022 JackMacWindows. All rights reserved.
-- This is a PRE-RELEASE BUILD! Redistribution of this file is not permitted.
-- See the Phoenix EULA (https://github.com/Phoenix-ComputerCraft/kernel/blob/master/LICENSE.md) for more information.

--- Version number of Phoenix.
PHOENIX_VERSION = "0.0.1"
--- Build string of Phoenix.
PHOENIX_BUILD = "PRERELEASE NONFREE Thu Aug 25 17:31:50 2022"

--- Stores the start time of the kernel.
systemStartTime = os.epoch "utc"

--- Stores all kernel arguments passed on the command line.
args = {
    init = "/bin/cash.lua",
    root = "/root",
    rootfstype = "craftos",
    preemptive = true,
    quantum = 2000000,
    splitkernpath = "/boot/kernel.lua.d",
    loglevel = 1,
    console = "tty1",
    traceback = true
}

--- Contains every syscall defined in the kernel.
syscalls = {}
--- Stores all currently running processes.
processes = {
    [0] = {
        name = "kernel",
        id = 0,
        user = "root",
        dir = "/",
        dependents = {}
    }
}
--- Stores a quick reference to the kernel process object.
KERNEL = processes[0]
--- Stores all currently loaded kernel modules.
modules = {}
--- Stores a list of hooks to call on certain CraftOS events. Each entry has the
-- event name as a key, and a list of functions to call as the value. The
-- functions are called with a single table parameter with the event parameters.
eventHooks = {}

-- Unique keys for certain internal uses.
kSyscallYield = {}

--- Process API
process = {}
--- Filesystem API
filesystem = {}
--- Terminal API
terminal = {}
--- User API
user = {}
--- System logger API
syslog = {}
--- Hardware API
hardware = {}

--#region 00-init.lua

-- Expect is a very useful module, so it's loaded for the kernel to use even though it's a CraftOS module.
do
    local file = fs.open("/rom/modules/main/cc/expect.lua", "r")
    expect = (loadstring or load)(file.readAll(), "@/rom/modules/main/cc/expect.lua")()
    file.close()
    setmetatable(expect, {__call = function(self, ...) return self.expect(...) end})
    if not expect.range then function expect.range(num, min, max)
        expect(1, num, "number")
        expect(2, min, "number", "nil")
        expect(3, max, "number", "nil")
        if max < min then error("bad argument #3 (min must be less than or equal to max)", 2) end
        if num ~= num or num < (min or -math.huge) or num > (max or math.huge) then error(("number outside of range (expected %s to be within %s and %s)"):format(num, min or -math.huge, max or math.huge), 3) end
        return num
    end end
end

-- textutils.[un]serialize is also very useful, so we load that in (but not anything else)
do
    local file = fs.open("/rom/apis/textutils.lua", "r")
    local env = setmetatable({dofile = function() return expect end}, {__index = _G}) -- We stub `dofile` here since textutils loads in expect via `dofile`
    local fn
    if loadstring and setfenv then
        fn = loadstring(file.readAll(), "@/rom/apis/textutils.lua")
        setfenv(fn, env)
    else
        fn = load(file.readAll(), "@/rom/apis/textutils.lua", "t", env)
    end
    file.close()
    fn()
    serialize, unserialize = env.serialize, env.unserialize
end

-- We need the keys API from CraftOS to be able to meaningfully decipher key constants.
do
    local file = fs.open("/rom/apis/keys.lua", "r")
    local env = setmetatable({dofile = function() return expect end}, {__index = _G})
    if _VERSION < "Lua 5.2" then env._ENV = env end
    local fn
    if loadstring and setfenv then
        fn = loadstring(file.readAll(), "@/rom/apis/keys.lua")
        setfenv(fn, env)
    else
        fn = load(file.readAll(), "@/rom/apis/keys.lua", "t", env)
    end
    file.close()
    fn()
    keys = {}
    for k,v in pairs(env) do keys[k] = v end
end

-- load is the de facto loader - loadstring will no longer be available. Since load for strings isn't available on old versions of Lua/Cobalt, we shim it if necessary.
if not pcall(load, "return", "=test", "t", {}) then
    local old_load, old_loadstring, expect = load, loadstring, expect
    function load(chunk, name, mode, env)
        expect(1, chunk, "string", "function")
        expect(2, name, "string", "nil")
        expect(3, mode, "string", "nil")
        expect(4, env, "table", "nil")
        if type(chunk) == "string" then
            if chunk:sub(1, 4) == "\27Lua" then
                if mode == nil or mode:find "b" then
                    local fn, err = old_loadstring(chunk, name)
                    if fn and env then setfenv(fn, env) end
                    return fn, err
                else return nil, "attempt to load a binary chunk (mode is '" .. (mode or "bt") .. "')" end
            else
                if mode == nil or mode:find "t" then
                    local fn, err = old_loadstring(chunk, name)
                    if fn and env then setfenv(fn, env) end
                    return fn, err
                else return nil, "attempt to load a text chunk (mode is '" .. (mode or "bt") .. "')" end
            end
        else
            local fn, err = old_load(chunk, name)
            if fn then setfenv(fn, env) end
            return fn, err
        end
    end
end
loadstring = nil -- Make sure loadstring is always gone

-- Remove bit and apply bit32, as this is a Lua 5.2 environment.
if bit then
    if not bit32 then
        local bit = bit
        bit32 = {
           bnot = bit.bnot,
           lshift = bit.blshift,
           rshift = bit.blogic_rshift,
           arshift = bit.brshift
        }
        function bit32.band(x, y, ...)
            expect(1, x, "number")
            expect(2, y, "number", "nil")
            if not y then return x end
            return bit32.band(bit.band(x, y), ...)
        end
        function bit32.bor(x, y, ...)
            expect(1, x, "number")
            expect(2, y, "number", "nil")
            if not y then return x end
            return bit32.bor(bit.bor(x, y), ...)
        end
        function bit32.bxor(x, y, ...)
            expect(1, x, "number")
            expect(2, y, "number", "nil")
            if not y then return x end
            return bit32.bxor(bit.bxor(x, y), ...)
        end
        function bit32.btest(...)
            return bit32.band(...) ~= 0
        end
        function bit32.extract(n, field, width)
            expect(1, n, "number")
            expect(2, field, "number")
            expect(3, width, "number", "nil");
            (expect.range or function() end)(field, 0, 31);
            (expect.range or function() end)(field + width - 1, 0, 31)
            width = width or 1
            local res = 0
            for i = field + width - 1, field, -1 do
                res = res * 2 + (bit.band(n, 2^i) / 2^i)
            end
            return res
        end
        function bit32.replace(n, v, field, width)
            expect(1, n, "number")
            expect(2, v, "number")
            expect(3, field, "number")
            expect(4, width, "number", "nil");
            (expect.range or function() end)(field, 0, 31);
            (expect.range or function() end)(field + width - 1, 0, 31)
            width = width or 1
            local mask = 2^width - 1
            return bit.bor(bit.band(n, bit.bnot(bit.blshift(mask, field))), bit.blshift(bit.band(v, mask), field))
        end
        function bit32.lrotate(x, disp)
            return bit.bor(bit.blshift(x, disp), bit.blogic_rshift(x, 32-disp))
        end
        function bit32.rrotate(x, disp)
            return bit.bor(bit.blogic_rshift(x, disp), bit.blshift(x, 32-disp))
        end
    end
    bit = nil
end

-- Implement miscellaneous Lua 5.2 functionality if on 5.1
if _VERSION == "Lua 5.1" then
    if not table.pack then table.pack = function(...)
        local t = {...}
        t.n = select("#", ...)
        return t
    end end
    if not table.unpack then table.unpack, unpack = unpack, nil end

    local old_xpcall = xpcall
    xpcall = function(f, errh, ...)
        if select("#", ...) > 0 then
            local args = table.pack(...)
            return old_xpcall(function() return f(table.unpack(args, 1, args.n)) end, errh)
        else return old_xpcall(f, errh) end
    end
end


-- Fix fs.combine on older versions to allow variable arguments
if tonumber(_HOST:match "ComputerCraft 1.(%d+)") < 95 then
    -- The verbosity here fixes some issues with the sumneko Lua LSP.
    ---@param base string
    ---@param extra string
    ---@return string
    local oldc = fs.combine
    ---@param p string
    ---@param ... string
    ---@return string
    function fs.combine(p, ...)
        if (...) ~= nil then
            return oldc(p, fs.combine(...))
        else
            return p
        end
    end
end

-- Add string.pack if it's not present
if not string.pack then
    local ByteOrder = {BIG_ENDIAN = 1, LITTLE_ENDIAN = 2}
    local isint = {b = 1, B = 1, h = 1, H = 1, l = 1, L = 1, j = 1, J = 1, T = 1}
    local packoptsize_tbl = {b = 1, B = 1, x = 1, h = 2, H = 2, f = 4, j = 4, J = 4, l = 8, L = 8, T = 8, d = 8, n = 8}

    local function round(n) if n % 1 >= 0.5 then return math.ceil(n) else return math.floor(n) end end

    local function floatToRawIntBits(f)
        if f == 0 then return 0
        elseif f == -0 then return 0x80000000
        elseif f == math.huge then return 0x7F800000
        elseif f == -math.huge then return 0xFF800000 end
        local m, e = math.frexp(f)
        if e > 127 or e < -126 then error("number out of range", 3) end
        e, m = e + 126, round((math.abs(m) - 0.5) * 0x1000000)
        if m > 0x7FFFFF then e = e + 1 end
        return bit32.bor(f < 0 and 0x80000000 or 0, bit32.lshift(bit32.band(e, 0xFF), 23), bit32.band(m, 0x7FFFFF))
    end

    local function doubleToRawLongBits(f)
        if f == 0 then return 0, 0
        elseif f == -0 then return 0x80000000, 0
        elseif f == math.huge then return 0x7FF00000, 0
        elseif f == -math.huge then return 0xFFF00000, 0 end
        local m, e = math.frexp(f)
        if e > 1023 or e < -1022 then error("number out of range", 3) end
        e, m = e + 1022, round((math.abs(m) - 0.5) * 0x20000000000000)
        if m > 0xFFFFFFFFFFFFF then e = e + 1 end
        return bit32.bor(f < 0 and 0x80000000 or 0, bit32.lshift(bit32.band(e, 0x7FF), 20), bit32.band(m / 0x100000000, 0xFFFFF)), bit32.band(m, 0xFFFFFFFF)
    end

    local function intBitsToFloat(l)
        if l == 0 then return 0
        elseif l == 0x80000000 then return -0
        elseif l == 0x7F800000 then return math.huge
        elseif l == 0xFF800000 then return -math.huge end
        local m, e = bit32.band(l, 0x7FFFFF), bit32.band(bit32.rshift(l, 23), 0xFF)
        e, m = e - 126, m / 0x1000000 + 0.5
        local n = math.ldexp(m, e)
        return bit32.btest(l, 0x80000000) and -n or n
    end

    local function longBitsToDouble(lh, ll)
        if lh == 0 and ll == 0 then return 0
        elseif lh == 0x80000000 and ll == 0 then return -0
        elseif lh == 0x7FF00000 and ll == 0 then return math.huge
        elseif lh == 0xFFF00000 and ll == 0 then return -math.huge end
        local m, e = bit32.band(lh, 0xFFFFF) * 0x100000000 + bit32.band(ll, 0xFFFFFFFF), bit32.band(bit32.rshift(lh, 20), 0x7FF)
        e, m = e - 1022, m / 0x20000000000000 + 0.5
        local n = math.ldexp(m, e)
        return bit32.btest(lh, 0x80000000) and -n or n
    end

    local function packint(num, size, output, offset, alignment, endianness, signed)
        local total_size = 0
        if offset % math.min(size, alignment) ~= 0 and alignment > 1 then
            local i = 0
            while offset % math.min(size, alignment) ~= 0 and i < alignment do
                output[offset] = 0
                offset = offset + 1
                total_size = total_size + 1
                i = i + 1
            end
        end
        if endianness == ByteOrder.BIG_ENDIAN then
            local added_padding = 0
            if size > 8 then for i = 0, size - 9 do
                output[offset + i] = (signed and num >= 2^(size * 8 - 1) ~= 0) and 0xFF or 0
                added_padding = added_padding + 1
                total_size = total_size + 1
            end end
            for i = added_padding, size - 1 do
                output[offset + i] = bit32.band(bit32.rshift(num, ((size - i - 1) * 8)), 0xFF)
                total_size = total_size + 1
            end
        else
            for i = 0, math.min(size, 8) - 1 do
                output[offset + i] = num / 2^(i * 8) % 256
                total_size = total_size + 1
            end
            for i = 8, size - 1 do
                output[offset + i] = (signed and num >= 2^(size * 8 - 1) ~= 0) and 0xFF or 0
                total_size = total_size + 1
            end
        end
        return total_size
    end

    local function unpackint(str, offset, size, endianness, alignment, signed)
        local result, rsize = 0, 0
        if offset % math.min(size, alignment) ~= 0 and alignment > 1 then
            for i = 0, alignment - 1 do
                if offset % math.min(size, alignment) == 0 then break end
                offset = offset + 1
                rsize = rsize + 1
            end
        end
        for i = 0, size - 1 do
            result = result + str:byte(offset + i) * 2^((endianness == ByteOrder.BIG_ENDIAN and size - i - 1 or i) * 8)
            rsize = rsize + 1
        end
        if (signed and result >= 2^(size * 8 - 1)) then result = result - 2^(size * 8) end
        return result, rsize
    end

    local function packoptsize(opt, alignment)
        local retval = packoptsize_tbl[opt] or 0
        if (alignment > 1 and retval % alignment ~= 0) then retval = retval + (alignment - (retval % alignment)) end
        return retval
    end

    --[[
    * string.pack (fmt, v1, v2, ...)
    *
    * Returns a binary string containing the values v1, v2, etc.
    * serialized in binary form (packed) according to the format string fmt.
    ]]
    function string.pack(...)
        local fmt = expect(1, ..., "string")
        local endianness = ByteOrder.LITTLE_ENDIAN
        local alignment = 1
        local pos = 1
        local argnum = 2
        local output = {}
        local i = 1
        while i <= #fmt do
            local c = fmt:sub(i, i)
            i = i + 1
            if c == '=' or c == '<' then
                endianness = ByteOrder.LITTLE_ENDIAN
            elseif c == '>' then
                endianness = ByteOrder.BIG_ENDIAN
            elseif c == '!' then
                local size = -1
                while (i <= #fmt and fmt:sub(i, i):match("%d")) do
                    if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                    size = (math.max(size, 0) * 10) + tonumber(fmt:sub(i, i))
                    i = i + 1
                end
                if (size > 16 or size == 0) then error(string.format("integral size (%d) out of limits [1,16]", size), 2)
                elseif (size == -1) then alignment = 4
                else alignment = size end
            elseif isint[c] then
                local num = expect(argnum, select(argnum, ...), "number")
                argnum = argnum + 1
                if (num >= math.pow(2, (packoptsize(c, 0) * 8 - (c:match("%l") and 1 or 0))) or
                    num < (c:match("%l") and -math.pow(2, (packoptsize(c, 0) * 8 - 1)) or 0)) then
                    error(string.format("bad argument #%d to 'pack' (integer overflow)", argnum - 1), 2)
                end
                pos = pos + packint(num, packoptsize(c, 0), output, pos, alignment, endianness, false)
            elseif c:lower() == 'i' then
                local signed = c == 'i'
                local size = -1
                while i <= #fmt and fmt:sub(i, i):match("%d") do
                    if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                    size = (math.max(size, 0) * 10) + tonumber(fmt:sub(i, i))
                    i = i + 1
                end
                if (size > 16 or size == 0) then
                    error(string.format("integral size (%d) out of limits [1,16]", size), 2)
                elseif (alignment > 1 and (size ~= 1 and size ~= 2 and size ~= 4 and size ~= 8 and size ~= 16)) then
                    error("bad argument #1 to 'pack' (format asks for alignment not power of 2)", 2)
                elseif (size == -1) then size = 4 end
                local num = expect(argnum, select(argnum, ...), "number")
                argnum = argnum + 1
                if (num >= math.pow(2, (size * 8 - (c:match("%l") and 1 or 0))) or
                    num < (c:match("%l") and -math.pow(2, (size * 8 - 1)) or 0)) then
                    error(string.format("bad argument #%d to 'pack' (integer overflow)", argnum - 1), 2)
                end
                pos = pos + packint(num, size, output, pos, alignment, endianness, signed)
            elseif c == 'f' then
                local f = expect(argnum, select(argnum, ...), "number")
                argnum = argnum + 1
                local l = floatToRawIntBits(f)
                if (pos % math.min(4, alignment) ~= 0 and alignment > 1) then 
                    for j = 0, alignment - 1 do
                        if pos % math.min(4, alignment) == 0 then break end
                        output[pos] = 0
                        pos = pos + 1
                    end
                end
                for j = 0, 3 do output[pos + (endianness == ByteOrder.BIG_ENDIAN and 3 - j or j)] = bit32.band(bit32.rshift(l, (j * 8)), 0xFF) end
                pos = pos + 4
            elseif c == 'd' or c == 'n' then
                local f = expect(argnum, select(argnum, ...), "number")
                argnum = argnum + 1
                local lh, ll = doubleToRawLongBits(f)
                if (pos % math.min(8, alignment) ~= 0 and alignment > 1) then 
                    for j = 0, alignment - 1 do
                        if pos % math.min(8, alignment) == 0 then break end
                        output[pos] = 0
                        pos = pos + 1
                    end
                end
                for j = 0, 3 do output[pos + (endianness == ByteOrder.BIG_ENDIAN and 7 - j or j)] = bit32.band(bit32.rshift(ll, (j * 8)), 0xFF) end
                for j = 4, 7 do output[pos + (endianness == ByteOrder.BIG_ENDIAN and 7 - j or j)] = bit32.band(bit32.rshift(lh, ((j - 4) * 8)), 0xFF) end
                pos = pos + 8
            elseif c == 'c' then
                local size = 0
                if (i > #fmt or not fmt:sub(i, i):match("%d")) then
                    error("missing size for format option 'c'", 2)
                end
                while (i <= #fmt and fmt:sub(i, i):match("%d")) do
                    if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                    size = (size * 10) + tonumber(fmt:sub(i, i))
                    i = i + 1
                end
                if (pos + size < pos or pos + size > 0xFFFFFFFF) then error("bad argument #1 to 'pack' (format result too large)", 2) end
                local str = expect(argnum, select(argnum, ...), "string")
                argnum = argnum + 1
                if (#str > size) then error(string.format("bad argument #%d to 'pack' (string longer than given size)", argnum - 1), 2) end
                if size > 0 then
                    for j = 0, size - 1 do output[pos+j] = str:byte(j + 1) or 0 end
                    pos = pos + size
                end
            elseif c == 'z' then
                local str = expect(argnum, select(argnum, ...), "string")
                argnum = argnum + 1
                for b in str:gmatch "." do if (b == '\0') then error(string.format("bad argument #%d to 'pack' (string contains zeros)", argnum - 1), 2) end end
                for j = 0, #str - 1 do output[pos+j] = str:byte(j + 1) end
                output[pos + #str] = 0
                pos = pos + #str + 1
            elseif c == 's' then
                local size = 0
                while (i <= #fmt and fmt:sub(i, i):match("%d")) do
                    if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                    size = (size * 10) + tonumber(fmt:sub(i, i))
                    i = i + 1
                end
                if (size > 16) then
                    error(string.format("integral size (%d) out of limits [1,16]", size), 2)
                elseif (size == 0) then size = 4 end
                local str = expect(argnum, select(argnum, ...), "string")
                argnum = argnum + 1
                if (#str >= math.pow(2, (size * 8))) then
                    error(string.format("bad argument #%d to 'pack' (string length does not fit in given size)", argnum - 1), 2)
                end
                packint(#str, size, output, pos, 1, endianness, false)
                for j = size, #str + size - 1 do output[pos+j] = str:byte(j - size + 1) or 0 end
                pos = pos + #str + size
            elseif c == 'x' then
                output[pos] = 0
                pos = pos + 1
            elseif c == 'X' then
                if (i >= #fmt) then error("invalid next option for option 'X'", 2) end
                local size = 0
                local c = fmt:sub(i, i)
                i = i + 1
                if c:lower() == 'i' then
                    while i <= #fmt and fmt:sub(i, i):match("%d") do
                        if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                        size = (size * 10) + tonumber(fmt:sub(i, i))
                        i = i + 1
                    end
                    if (size > 16 or size == 0) then
                        error(string.format("integral size (%d) out of limits [1,16]", size), 2)
                    end
                else size = packoptsize(c, 0) end
                if (size < 1) then error("invalid next option for option 'X'", 2) end
                if (pos % math.min(size, alignment) ~= 0 and alignment > 1) then
                    for j = 1, alignment do
                        if pos % math.min(size, alignment) == 0 then break end
                        output[pos] = 0
                        pos = pos + 1
                    end
                end
            elseif c ~= ' ' then error(string.format("invalid format option '%s'", c), 2) end
        end
        return string.char(table.unpack(output))
    end

    --[[
    * string.packsize (fmt)
    *
    * Returns the size of a string resulting from string.pack with the given format.
    * The format string cannot have the variable-length options 's' or 'z'.
    ]]
    function string.packsize(fmt)
        local pos = 0
        local alignment = 1
        local i = 1
        while i <= #fmt do
            local c = fmt:sub(i, i)
            i = i + 1
            if c == '!' then
                local size = 0
                while i <= #fmt and fmt:sub(i, i):match("%d") do
                    if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                    size = (size * 10) + tonumber(fmt:sub(i, i))
                    i = i + 1
                end
                if (size > 16) then error(string.format("integral size (%d) out of limits [1,16]", size), 2)
                elseif (size == 0) then alignment = 4
                else alignment = size end
            elseif isint[c] then
                local size = packoptsize(c, 0)
                if (pos % math.min(size, alignment) ~= 0 and alignment > 1) then
                    for j = 1, alignment do
                        if pos % math.min(size, alignment) == 0 then break end
                        pos = pos + 1
                    end
                end
                pos = pos + size
            elseif c:lower() == 'i' then
                local size = 0
                while i <= #fmt and fmt:sub(i, i):match("%d") do
                    if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                    size = (size * 10) + tonumber(fmt:sub(i, i))
                    i = i + 1
                end
                if (size > 16) then
                    error(string.format("integral size (%d) out of limits [1,16]", size))
                elseif (alignment > 1 and (size ~= 1 and size ~= 2 and size ~= 4 and size ~= 8 and size ~= 16)) then
                    error("bad argument #1 to 'pack' (format asks for alignment not power of 2)", 2)
                elseif (size == 0) then size = 4 end
                if (pos % math.min(size, alignment) ~= 0 and alignment > 1) then
                    for j = 1, alignment do
                        if pos % math.min(size, alignment) == 0 then break end
                        pos = pos + 1
                    end
                end
                pos = pos + size
            elseif c == 'f' then
                if (pos % math.min(4, alignment) ~= 0 and alignment > 1) then
                    for j = 1, alignment do
                        if pos % math.min(4, alignment) == 0 then break end
                        pos = pos + 1
                    end
                end
                pos = pos + 4
            elseif c == 'd' or c == 'n' then
                if (pos % math.min(8, alignment) ~= 0 and alignment > 1) then
                    for j = 1, alignment do
                        if pos % math.min(8, alignment) == 0 then break end
                        pos = pos + 1
                    end
                end
                pos = pos + 8
            elseif c == 'c' then
                local size = 0
                if (i > #fmt or not fmt:sub(i, i):match("%d")) then
                    error("missing size for format option 'c'", 2)
                end
                while i <= #fmt and fmt:sub(i, i):match("%d") do
                    if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                    size = (size * 10) + tonumber(fmt:sub(i, i))
                    i = i + 1
                end
                if (pos + size < pos or pos + size > 0x7FFFFFFF) then error("bad argument #1 to 'packsize' (format result too large)", 2) end
                pos = pos + size
            elseif c == 'x' then
                pos = pos + 1
            elseif c == 'X' then
                if (i >= #fmt) then error("invalid next option for option 'X'", 2) end
                local size = 0
                local c = fmt:sub(i, i)
                i = i + 1
                if c:lower() == 'i' then
                    while i <= #fmt and fmt:sub(i, i):match("%d") do
                        if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                        size = (size * 10) + tonumber(fmt:sub(i, i))
                        i = i + 1
                    end
                    if (size > 16 or size == 0) then
                        error(string.format("integral size (%d) out of limits [1,16]", size), 2)
                    end
                else size = packoptsize(c, 0) end
                if (size < 1) then error("invalid next option for option 'X'", 2) end
                if (pos % math.min(size, alignment) ~= 0 and alignment > 1) then
                    for j = 1, alignment do
                        if pos % math.min(size, alignment) == 0 then break end
                        pos = pos + 1
                    end
                end
            elseif c == 's' or c == 'z' then error("bad argument #1 to 'packsize' (variable-length format)", 2)
            elseif c ~= ' ' and c ~= '<' and c ~= '>' and c ~= '=' then error(string.format("invalid format option '%s'", c), 2) end
        end
        return pos
    end

    --[[
    * string.unpack (fmt, s [, pos])
    *
    * Returns the values packed in string s (see string.pack) according to the format string fmt.
    * An optional pos marks where to start reading in s (default is 1).
    * After the read values, this function also returns the index of the first unread byte in s.
    ]]
    function string.unpack(fmt, str, pos)
        expect(1, fmt, "string")
        expect(2, str, "string")
        expect(3, pos, "number", "nil")
        if pos then
            if (pos < 0) then pos = #str + pos
            elseif (pos == 0) then error("bad argument #3 to 'unpack' (initial position out of string)", 2) end
            if (pos > #str or pos < 0) then error("bad argument #3 to 'unpack' (initial position out of string)", 2) end
        else pos = 1 end
        local endianness = ByteOrder.LITTLE_ENDIAN
        local alignment = 1
        local retval = {}
        local i = 1
        while i <= #fmt do
            local c = fmt:sub(i, i)
            i = i + 1
            if c == '<' or c == '=' then
                endianness = ByteOrder.LITTLE_ENDIAN
            elseif c == '>' then
                endianness = ByteOrder.BIG_ENDIAN
            elseif c == '!' then
                local size = 0
                while i <= #fmt and fmt:sub(i, i):match("%d") do
                    if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                    size = (size * 10) + tonumber(fmt:sub(i, i))
                    i = i + 1
                end
                if (size > 16) then
                    error(string.format("integral size (%d) out of limits [1,16]", size))
                elseif (size == 0) then alignment = 4
                else alignment = size end
            elseif isint[c] then
                if (pos + packoptsize(c, 0) > #str + 1) then error("data string too short", 2) end
                local res, ressz = unpackint(str, pos, packoptsize(c, 0), endianness, alignment, c:match("%l") ~= nil)
                retval[#retval+1] = res
                pos = pos + ressz
            elseif c:lower() == 'i' then
                local signed = c == 'i'
                local size = 0
                while (i <= #fmt and fmt:sub(i, i):match("%d")) do
                    if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                    size = (size * 10) + tonumber(fmt:sub(i, i))
                    i = i + 1
                end
                if (size > 16) then
                    error(string.format("integral size (%d) out of limits [1,16]", size), 2)
                elseif (size > 8) then
                    error(string.format("%d-byte integer does not fit into Lua Integer", size), 2)
                elseif (size == 0) then size = 4 end
                if (pos + size > #str + 1) then error("data string too short", 2) end
                local res, ressz = unpackint(str, pos, size, endianness, alignment, signed)
                retval[#retval+1] = res
                pos = pos + ressz
            elseif c == 'f' then
                if (pos % math.min(4, alignment) ~= 0 and alignment > 1) then
                    for j = 1, alignment do
                        if pos % math.min(4, alignment) == 0 then break end
                        pos = pos + 1
                    end
                end
                if (pos + 4 > #str + 1) then error("data string too short", 2) end
                local res = unpackint(str, pos, 4, endianness, alignment, false)
                retval[#retval+1] = intBitsToFloat(res)
                pos = pos + 4
            elseif c == 'd' or c == 'n' then
                if (pos % math.min(8, alignment) ~= 0 and alignment > 1) then
                    for j = 1, alignment do
                        if pos % math.min(8, alignment) == 0 then break end
                        pos = pos + 1
                    end
                end
                if (pos + 8 > #str + 1) then error("data string too short", 2) end
                local lh, ll = 0, 0
                for j = 0, 3 do lh = bit32.bor(lh, bit32.lshift((str:byte(pos + j)), ((endianness == ByteOrder.BIG_ENDIAN and 3 - j or j) * 8))) end
                for j = 0, 3 do ll = bit32.bor(ll, bit32.lshift((str:byte(pos + j + 4)), ((endianness == ByteOrder.BIG_ENDIAN and 3 - j or j) * 8))) end
                if endianness == ByteOrder.LITTLE_ENDIAN then lh, ll = ll, lh end
                retval[#retval+1] = longBitsToDouble(lh, ll)
                pos = pos + 8
            elseif c == 'c' then
                local size = 0
                if (i > #fmt or not fmt:sub(i, i):match("%d")) then
                    error("missing size for format option 'c'", 2)
                end
                while i <= #fmt and fmt:sub(i, i):match("%d") do
                    if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)") end
                    size = (size * 10) + tonumber(fmt:sub(i, i))
                    i = i + 1
                end
                if (pos + size > #str + 1) then error("data string too short", 2) end
                retval[#retval+1] = str:sub(pos, pos + size - 1)
                pos = pos + size
            elseif c == 'z' then
                local size = 0
                while (str:byte(pos + size) ~= 0) do
                    size = size + 1
                    if (pos + size > #str) then error("unfinished string for format 'z'", 2) end
                end
                retval[#retval+1] = str:sub(pos, pos + size - 1)
                pos = pos + size + 1
            elseif c == 's' then
                local size = 0
                while i <= #fmt and fmt:sub(i, i):match("%d") do
                    if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                    size = (size * 10) + tonumber(fmt:sub(i, i))
                    i = i + 1
                end
                if (size > 16) then
                    error(string.format("integral size (%d) out of limits [1,16]", size), 2)
                elseif (size == 0) then size = 4 end
                if (pos + size > #str + 1) then error("data string too short", 2) end
                local num, numsz = unpackint(str, pos, size, endianness, alignment, false)
                pos = pos + numsz
                if (pos + num > #str + 1) then error("data string too short", 2) end
                retval[#retval+1] = str:sub(pos, pos + num - 1)
                pos = pos + num
            elseif c == 'x' then
                pos = pos + 1
            elseif c == 'X' then
                if (i >= #fmt) then error("invalid next option for option 'X'", 2) end
                local size = 0
                local c = fmt:sub(i, i)
                i = i + 1
                if c:lower() == 'i' then
                    while i <= #fmt and fmt:sub(i, i):match("%d") do
                        if (size >= 0xFFFFFFFF / 10) then error("bad argument #1 to 'pack' (invalid format)", 2) end
                        size = (size * 10) + tonumber(fmt:sub(i, i))
                        i = i + 1
                    end
                    if (size > 16 or size == 0) then
                        error(string.format("integral size (%d) out of limits [1,16]", size), 2)
                    elseif (size == -1) then size = 4 end
                else size = packoptsize(c, 0) end
                if (size < 1) then error("invalid next option for option 'X'", 2) end
                if (pos % math.min(size, alignment) ~= 0 and alignment > 1) then
                    for j = 1, alignment do
                        if pos % math.min(size, alignment) == 0 then break end
                        pos = pos + 1
                    end
                end
            elseif c ~= ' ' then error(string.format("invalid format option '%s'", c), 2) end
        end
        retval[#retval+1] = pos
        return table.unpack(retval)
    end
end

-- This adds the coroutine library to coroutine types, and allows calling coroutines to resume
-- ex: while coro:status() == "suspended" do coro("hello") end
-- This should be a thing in base Lua, but since not we'll make it available system-wide!
-- Programs can rely on this behavior existing (even though it may be unavailable if debug is disabled, but CC:T 1.96 removes the ability to disable it anyway)
-- Note: Unfortunately, CraftOS-PC v2.6.2 and earlier have a bug preventing this from working
if debug then
    local coro = setmetatable({}, {__index = coroutine, __newindex = function() end, __metatable = false})
    debug.setmetatable(coroutine.running(), {__index = coro, __call = coroutine.resume})
end

-- Early version of panic function, before log initialization finishes (this is redefined later to use syslog)
function panic(message)
    term.setBackgroundColor(32768)
    term.setTextColor(16384)
    term.setCursorBlink(false)
    local x, y = term.getCursorPos()
    x = 1
    local w, h = term.getSize()
    message = "panic: " .. (message or "unknown")
    for word in message:gmatch "%S+" do
        if x + #word >= w then
            x, y = 1, y + 1
            if y > h then
                term.scroll(1)
                y = y - 1
            end
        end
        term.setCursorPos(x, y)
        if x == 1 then term.clearLine() end
        term.write(word .. " ")
        x = x + #word + 1
    end
    x, y = 1, y + 1
    if y > h then
        term.scroll(1)
        y = y - 1
    end
    if debug then
        local traceback = debug.traceback(nil, 2)
        for line in traceback:gmatch "[^\n]+" do
            term.setCursorPos(1, y)
            term.write(line)
            y = y + 1
            if y > h then
                term.scroll(1)
                y = y - 1
            end
        end
    end
    term.setCursorPos(1, y)
    term.setTextColor(2)
    term.write("panic: We are hanging here...")
    while true do coroutine.yield() end
end

--- Small function to execute a syscall and error if it fails.
-- @tparam string call The syscall to execute
-- @tparam any ... The arguments to pass to the syscall
-- @treturn any... The values returned from the syscall
function do_syscall(call, ...)
    local res = table.pack(coroutine.yield("syscall", call, ...))
    if res[1] then return table.unpack(res, 2, res.n)
    else error(res[2], 3) end
end

--- Copies a value. If the value is a table, copies all of its contents too.
-- @tparam any tab The value to copy
-- @treturn any The new copied value
function deepcopy(tab)
    if type(tab) == "table" then
        local retval = setmetatable({}, deepcopy(getmetatable(tab)))
        for k,v in pairs(tab) do retval[deepcopy(k)] = deepcopy(v) end
        return retval
    else return tab end
end

--- Splits a string by a separator.
-- @tparam string str The string to split
-- @tparam[opt="%s"] string sep The separator pattern to split by
-- @treturn {string} A list of items in the string
function split(str, sep)
    local t = {}
    for match in str:gmatch("[^" .. (sep or "%s") .. "]+") do t[#t+1] = match end
    return t
end

local procTime = pcall(os.epoch, "nano") and function() return os.epoch "nano" / 1000000 end or function() return os.epoch "utc" end

local empty_packed_table = {n = 0}
--- Resumes a thread's coroutine, handling different yield types.
-- @tparam Process process The process that owns the thread
-- @tparam Thread thread The thread to resume
-- @tparam table ev An event to pass to the thread, if present
-- @tparam boolean dead Whether a thread in the current run cycle has died
-- @tparam boolean allWaiting Whether all previous threads were waiting for an event
-- @treturn boolean Whether this thread or a previous thread has died
-- @treturn boolean Whether all threads (including this one) are waiting for an event
function executeThread(process, thread, ev, dead, allWaiting)
    local args
    if thread.status == "starting" then args = thread.args
    elseif thread.status == "syscall" then args = thread.syscall_return
    elseif thread.status == "preempt" then args = empty_packed_table
    elseif thread.status == "suspended" then args = {ev[1], deepcopy(ev[2])} end
    if thread.status ~= "dead" and (not thread.filter or thread.filter(process, thread, ev)) then
        local old_dead = dead
        dead = false
        thread.filter = nil
        local params
        if thread.yielding then
            --syslog.debug("Resuming yielded syscall")
            params = {n = thread.syscall_return.n, true, "syscall", thread.yielding, table.unpack(thread.syscall_return, 4, thread.syscall_return.n)}
            thread.yielding = nil
        else
            --syslog.debug("Resuming thread", tid)
            local start = procTime()
            params = table.pack(coroutine.resume(thread.coro, table.unpack(args, 1, args.n)))
            --syslog.debug("Yield", params.n, table.unpack(params, 1, params.n))
            process.cputime = process.cputime + (procTime() - start) / 1000
        end
        if params[2] == "syscall" then
            --syslog.debug("Calling syscall", params[3])
            thread.status = "syscall"
            local oldAllWaiting = allWaiting
            allWaiting = false
            if params[3] and syscalls[params[3]] then
                local start = procTime()
                thread.syscall_return = table.pack(xpcall(syscalls[params[3]], debug.traceback, process, thread, table.unpack(params, 4, params.n)))
                process.systime = process.systime + (procTime() - start) / 1000
                if not thread.syscall_return[1] and type(thread.syscall_return[2]) == "string" then
                    syslog.log({level = "debug", category = "Syscall Failure", process = 0}, thread.syscall_return[2])
                    thread.syscall_return[2] = thread.syscall_return[2]:gsub("kernel:%d+: ", "")
                end
                if thread.syscall_return[2] == kSyscallYield then
                    thread.yielding = thread.syscall_return[3]
                    allWaiting = oldAllWaiting
                end
            else thread.syscall_return = {false, "No such syscall", n = 2} end
        elseif params[2] == "preempt" then
            thread.status = "preempt"
            allWaiting = false
        elseif coroutine.status(thread.coro) == "dead" then
            thread.status = "dead"
            if params[1] then process.lastReturnValue = {pid = process.id, thread = thread.id, value = params[2], n = params.n - 1, table.unpack(params, 2, params.n)}
            else process.lastReturnValue = {pid = process.id, thread = thread.id, error = params[2], traceback = debug.traceback(thread.coro)} end
            if not params[1] then
                thread.did_error = true
                syslog.log({level = _G.args.traceback and "error" or "debug", process = process.id, thread = thread.id, category = "Application Error", traceback = true}, debug.traceback(thread.coro, params[2]))
                if params[2] and process.stderr and process.stderr.isTTY then terminal.write(process.stderr, params[2] .. "\n") end
            end
            process.threads[thread.id] = nil
            dead = old_dead
        else
            --syslog.debug("Standard yield", params.n, table.unpack(params, 1, params.n))
            --syslog.debug(debug.traceback(thread.coro))
            thread.status = "suspended"
            allWaiting = allWaiting and #process.eventQueue == 0
        end
    end
    return dead, allWaiting
end

--- Executes a function in user mode from kernel code.
-- @tparam Process process The process to execute as
-- @tparam function func The function to execute
-- @tparam any ... Any parameters to pass to the function
-- @treturn boolean Whether the function returned successfully
-- @treturn any The value that the function returned.
function userModeCallback(process, func, ...)
    local thread = {
        id = -1,
        name = "<user mode callback>",
        coro = coroutine.create(func),
        status = "starting",
        args = table.pack(...),
        filter = nil,
    }
    pcall(setfenv, func, process.env)
    local dead = false
    while not dead do
        dead = executeThread(process, thread, empty_packed_table, true, false)
        if thread.status == "suspended" then return false, "attempt to yield from a user mode callback" end
    end
    return not thread.did_error, thread.return_value
end

for _,v in ipairs({...}) do
    local key, value = v:match("^([^=]+)=(.+)$")
    if key and value then
        if type(args[key]) == "boolean" then args[key] = value:lower() == "true" or value == "1"
        elseif type(args[key]) == "number" then args[key] = tonumber(value)
        else args[key] = value end
    elseif key == "silent" then args.loglevel = 5
    end
end

if jit and args.preemptive then panic("Phoenix does not support preemption when running under LuaJIT. Please set preemptive to false in the kernel arguments.") end
if not debug and args.preemptive then panic("Phoenix does not support preemption without the debug API. Please set preemptive to false in the kernel arguments.") end
if args.preemptive then PHOENIX_BUILD = PHOENIX_BUILD .. " PREEMPT" end
if not getfenv then
    if not debug then panic("Phoenix requires the debug API when running under Lua 5.2 and later.") end
    -- getfenv/setfenv replacements from https://leafo.net/guides/setfenv-in-lua52-and-above.html
    function getfenv(fn)
        local i = 1
        while true do
            local name, val = debug.getupvalue(fn, i)
            if name == "_ENV" then return val
            elseif not name then break end
            i = i + 1
        end
    end
    function setfenv(fn, env)
        local i = 1
        while true do
            local name = debug.getupvalue(fn, i)
            if name == "_ENV" then
                debug.upvaluejoin(fn, i, function() return env end, 1)
                break
            elseif not name then break end
            i = i + 1
        end
        return fn
    end
end

do
    -- dbprotect.lua - Protect your functions from the debug library
    -- By JackMacWindows
    -- Licensed under CC0, though I'd appreciate it if this notice was left in place.

    -- Simply run this file in some fashion, then call `debug.protect` to protect a function.
    -- It takes the function as the first argument, as well as a list of functions
    -- that are still allowed to access the function's properties.
    -- Once protected, access to the function's environment, locals, and upvalues is
    -- blocked from all Lua functions. A function *can not* be unprotected without
    -- restarting the Lua state.
    -- The debug library itself is protected too, so it's not possible to remove the
    -- protection layer after being installed.
    -- It's also not possible to add functions to the whitelist after protecting, so
    -- make sure everything that needs to access the function's properties are added.

    local protectedObjects
    local n_getfenv, n_setfenv, d_getfenv, getlocal, getupvalue, d_setfenv, setlocal, setupvalue, upvaluejoin =
        getfenv, setfenv, debug.getfenv, debug.getlocal, debug.getupvalue, debug.setfenv, debug.setlocal, debug.setupvalue, debug.upvaluejoin

    local error, getinfo, running, select, setmetatable, type, tonumber = error, debug.getinfo, coroutine.running, select, setmetatable, type, tonumber

    local superprotected

    local function keys(t, v, ...)
        if v then t[v] = true end
        if select("#", ...) > 0 then return keys(t, ...)
        else return t end
    end

    local function superprotect(v, ...)
        if select("#", ...) > 0 then return superprotected[v or ""] or v, superprotect(...)
        else return superprotected[v or ""] or v end
    end

    function debug.getinfo(thread, func, what)
        if type(thread) ~= "thread" then what, func, thread = func, thread, running() end
        local retval
        if tonumber(func) then retval = getinfo(thread, func+1, what)
        else retval = getinfo(thread, func, what) end
        if retval and retval.func then retval.func = superprotected[retval.func] or retval.func end
        return retval
    end

    function debug.getlocal(thread, level, loc)
        if loc == nil then loc, level, thread = level, thread, running() end
        local k, v
        if type(level) == "function" then
            local caller = getinfo(2, "f")
            if protectedObjects[level] and not (caller and protectedObjects[level][caller.func]) then return nil end
            k, v = superprotect(getlocal(level, loc))
        elseif tonumber(level) then
            local info = getinfo(thread, level + 1, "f")
            local caller = getinfo(2, "f")
            if info and protectedObjects[info.func] and not (caller and protectedObjects[info.func][caller.func]) then return nil end
            k, v = superprotect(getlocal(thread, level + 1, loc))
        else k, v = superprotect(getlocal(thread, level, loc)) end
        return k, v
    end

    function debug.getupvalue(func, up)
        if type(func) == "function" then
            local caller = getinfo(2, "f")
            if protectedObjects[func] and not (caller and protectedObjects[func][caller.func]) then return nil end
        end
        local k, v = superprotect(getupvalue(func, up))
        return k, v
    end

    function debug.setlocal(thread, level, loc, value)
        if loc == nil then loc, level, thread = level, thread, running() end
        if tonumber(level) then
            local info = getinfo(thread, level + 1, "f")
            local caller = getinfo(2, "f")
            if info and protectedObjects[info.func] and not (caller and protectedObjects[info.func][caller.func]) then error("attempt to set local of protected function", 2) end
            setlocal(thread, level + 1, loc, value)
        else setlocal(thread, level, loc, value) end
    end

    function debug.setupvalue(func, up, value)
        if type(func) == "function" then
            local caller = getinfo(2, "f")
            if protectedObjects[func] and not (caller and protectedObjects[func][caller.func]) then error("attempt to set upvalue of protected function", 2) end
        end
        setupvalue(func, up, value)
    end

    function _G.getfenv(f)
        local v
        if f == nil then v = n_getfenv(2)
        elseif tonumber(f) and tonumber(f) > 0 then
            local info = getinfo(f + 1, "f")
            local caller = getinfo(2, "f")
            if info and protectedObjects[info.func] and not (caller and protectedObjects[info.func][caller.func]) then return nil end
            v = n_getfenv(f+1)
        elseif type(f) == "function" then
            local caller = getinfo(2, "f")
            if protectedObjects[f] and not (caller and protectedObjects[f][caller.func]) then return nil end
            v = n_getfenv(f)
        else v = n_getfenv(f) end
        return v
    end

    function _G.setfenv(f, tab)
        if tonumber(f) then
            local info = getinfo(f + 1, "f")
            local caller = getinfo(2, "f")
            if info and protectedObjects[info.func] and not (caller and protectedObjects[info.func][caller.func]) then error("attempt to set environment of protected function", 2) end
            n_setfenv(f+1, tab)
        elseif type(f) == "function" then
            local caller = getinfo(2, "f")
            if protectedObjects[f] and not (caller and protectedObjects[f][caller.func]) then error("attempt to set environment of protected function", 2) end
        end
        n_setfenv(f, tab)
    end

    if d_getfenv then
        function debug.getfenv(o)
            if type(o) == "function" then
                local caller = getinfo(2, "f")
                if protectedObjects[o] and not (caller and protectedObjects[o][caller.func]) then return nil end
            end
            local v = d_getfenv(o)
            return v
        end

        function debug.setfenv(o, tab)
            if type(o) == "function" then
                local caller = getinfo(2, "f")
                if protectedObjects[o] and not (caller and protectedObjects[o][caller.func]) then error("attempt to set environment of protected function", 2) end
            end
            d_setfenv(o, tab)
        end
    end

    if upvaluejoin then
        function debug.upvaluejoin(f1, n1, f2, n2)
            if type(f1) == "function" and type(f2) == "function" then
                local caller = getinfo(2, "f")
                if protectedObjects[f1] and not (caller and protectedObjects[f1][caller.func]) then error("attempt to get upvalue of protected function", 2) end
                if protectedObjects[f2] and not (caller and protectedObjects[f2][caller.func]) then error("attempt to set upvalue of protected function", 2) end
            end
            upvaluejoin(f1, n1, f2, n2)
        end
    end

    function debug.protect(func)
        if type(func) ~= "function" then error("bad argument #1 (expected function, got " .. type(func) .. ")", 2) end
        if protectedObjects[func] then error("attempt to protect a protected function", 2) end
        protectedObjects[func] = keys(setmetatable({}, {__mode = "k"}))
    end

    superprotected = {
        [n_getfenv] = _G.getfenv,
        [n_setfenv] = _G.setfenv,
        [d_getfenv] = debug.getfenv,
        [d_setfenv] = debug.setfenv,
        [getlocal] = debug.getlocal,
        [setlocal] = debug.setlocal,
        [getupvalue] = debug.getupvalue,
        [setupvalue] = debug.setupvalue,
        [upvaluejoin] = debug.upvaluejoin,
        [getinfo] = debug.getinfo,
        [superprotect] = function() end,
    }

    protectedObjects = keys(setmetatable({}, {__mode = "k"}),
        getfenv,
        setfenv,
        debug.getfenv,
        debug.setfenv,
        debug.getlocal,
        debug.setlocal,
        debug.getupvalue,
        debug.setupvalue,
        debug.upvaluejoin,
        debug.getinfo,
        superprotect,
        debug.protect
    )
    for k,v in pairs(protectedObjects) do protectedObjects[k] = {} end
end

--#endregion

--#region 05-filesystem.lua

--[[
    CraftOS mount metadata is stored in the following format: {
        meta = {
            type = "directory",
            owner = "root",
            permissions = {
                root = {read = true, write = true, execute = true}
            },
            worldPermissions = {read = true, write = false, execute = true}
        },
        contents = {
            home = {
                meta = {
                    type = "directory",
                    owner = "user",
                    permissions = {
                        user = {read = true, write = true, execute = true},
                        admins = {read = true, write = false, execute = true}
                    },
                    worldPermissions = {read = false, write = false, execute = false}
                },
                contents = {
                    ["info.txt"] = {
                        meta = {
                            type = "link",
                            owner = "user",
                            permissions = {
                                user = {read = true, write = true, execute = false}
                            },
                            worldPermissions = {read = false, write = false, execute = false}
                        },
                        link = "../info.txt"
                    }
                }
            },
            ["info.txt"] = {
                meta = {
                    type = "file",
                    owner = "root",
                    permissions = {
                        root = {read = true, write = true, execute = false}
                    },
                    worldPermissions = {read = true, write = false, execute = false}
                }
            }
        }
    }
]]

-- TODO: Add disk space metrics
-- TODO: Add links, FIFOs, special file support

--- Stores the current mounts as a key-value table of paths to filesystem objects.
mounts = {}

--- This table contains all filesystem types. Use this to insert more filesystem
-- types into the system.
--
-- A filesystem type has to implement one method for each function in the
-- filesystem API, with the exception of mounting-related functions and `combine`,
-- as well as a `new` method that is called with the process, the source device,
-- and the options table (if present). Paths passed to these methods (outside
-- `new`) take a relative path to the mountpoint, NOT the absolute path.
filesystems = {
    craftos = {
        meta = {
            meta = {
                type = "directory",
                owner = "root",
                permissions = {
                    root = {read = true, write = true, execute = true}
                },
                worldPermissions = {read = true, write = false, execute = true},
                setuser = false
            },
            contents = {}
        }
    },
    tmpfs = {},
    drivefs = {}
}

-- craftos fs implementation

do
    local file = fs.open("/meta.ltn", "r")
    if file then
        filesystems.craftos.meta = unserialize(file.readAll()) or filesystems.craftos.meta
        file.close()
    end
end

function filesystems.craftos:getmeta(user, path)
    local stack = {}
    local t = self.meta
    for _,p in ipairs(split(path, "/\\")) do
        if p == ".." then
            t = table.remove(stack)
            if not t then return nil end
        elseif not p:match "^%.*$" then
            if not t then return nil
            elseif t.meta.type ~= "directory" then error("Not a directory", 2)
            elseif t.meta.permissions[user] then if not t.meta.permissions[user].execute then error("Permission denied", 2) end
            elseif not t.meta.worldPermissions.execute then error("Permission denied", 2) end
            stack[#stack+1] = t
            t = t.contents[p]
            -- TODO: handle link traversal
            --if t and t.meta.type == "link" then t = ? end
        end
    end
    return t and t.meta
end

function filesystems.craftos:setmeta(user, path, meta)
    local stack = {}
    local t = self.meta
    local name
    for _,p in ipairs(split(path, "/\\")) do
        if p == ".." then
            t = table.remove(stack)
            if not t then error("Not a directory", 2) end
        elseif not p:match "^%.*$" then
            if t.meta.type ~= "directory" then error("Not a directory", 2)
            elseif t.meta.permissions[user] then if not t.meta.permissions[user].execute then error("Permission denied", 2) end
            elseif not t.meta.worldPermissions.execute then error("Permission denied", 2) end
            if not t.contents[p] then t.contents[p] = { -- Initialize with default directory meta if not present
                meta = {                                -- This means the directory was created on-disk but the metadata was never set
                    type = "directory",                 -- We'll set it properly at the end (or something)
                    owner = t.meta.owner or "root",     -- TODO: maybe set this to the parent's permissions? (Would maybe make more sense)
                    permissions = {
                        root = {read = true, write = true, execute = true}
                    },
                    worldPermissions = {read = true, write = false, execute = true},
                    setuser = false
                },
                contents = {}
            } end
            stack[#stack+1] = t
            t = t.contents[p]
            name = p
            -- TODO: handle link traversal
            --if t and t.meta.type == "link" then t = ? end
        end
    end
    if meta ~= nil then
        t.meta = {
            type = meta.type,
            owner = meta.owner,
            permissions = deepcopy(meta.permissions),
            worldPermissions = deepcopy(meta.worldPermissions),
            setuser = meta.setuser
        }
        if meta.type ~= "directory" then t.contents = nil end
    else stack[#stack].contents[name] = nil end
    local file = fs.open("/meta.ltn", "w")
    file.write(serialize(self.meta, {compact = true}))
    file.close()
end

function filesystems.craftos:new(process, path, options)
    expect.field(options, "ro", "boolean", "nil")
    -- CraftOS mounts will always require root
    if process.user ~= "root" then error("Could not mount " .. path .. ": Permission denied", 3)
    elseif not fs.isDir(path) then error("Could not mount " .. path .. ": No such directory", 3) end
    return setmetatable({
        path = path,
        readOnly = options.ro
    }, {__index = self})
end

function filesystems.craftos:open(process, path, mode)
    local ok, stat = pcall(self.stat, self, process, path)
    if not ok then return nil, stat
    elseif not stat then
        if mode:sub(1, 1) == "w" or mode:sub(1, 1) == "a" then
            if self.readOnly then return nil, "Read-only filesystem" end
            local pok, pstat = pcall(self.stat, self, process, fs.getDir(path))
            if not pok or not pstat then
                local mok, err = pcall(self.mkdir, self, process, fs.getDir(path))
                if not mok then return nil, err:gsub("kernel:%d: ", "") end
                pstat = self:stat(process, fs.getDir(path))
                if not pstat then return nil, "Could not stat " .. fs.getDir(path) end
            end
            if process.user ~= "root" then
                local perms = pstat.permissions[process.user] or pstat.worldPermissions
                if not perms.write then return nil, "Permission denied" end
            end
            local meta = {
                type = "file",
                owner = process.user,
                permissions = deepcopy(pstat.permissions),
                worldPermissions = deepcopy(pstat.worldPermissions),
                setuser = false
            }
            -- We do a swap here so it doesn't break if pstat.owner == process.user
            local t = meta.permissions[pstat.owner]
            meta.permissions[pstat.owner] = nil
            meta.permissions[process.user] = t
            self:setmeta(process.user, fs.combine(self.path, path), meta)
            local file, err = fs.open(fs.combine(self.path, path), mode)
            if not file then return file, err end
            return setmetatable(file, {__name = "file"})
        else return nil, "File not found" end
    elseif stat.type == "directory" then return nil, "Is a directory" end
    local perms = stat.permissions[process.user] or stat.worldPermissions
    --syslog.debug(path, mode, perms.read, perms.write, perms.execute)
    if (mode:sub(1, 1) == "r" and not perms.read) or ((mode:sub(1, 1) == "w" or mode:sub(1, 1) == "a") and not perms.write) then return nil, "Permission denied" end
    return setmetatable(fs.open(fs.combine(self.path, path), mode), {__name = "file"})
end

function filesystems.craftos:list(process, path)
    local stat = self:stat(process, path)
    if not stat or stat.type ~= "directory" then error(path .. ": Not a directory", 2) end
    if process.user ~= "root" then
        local perms = stat.permissions[process.user] or stat.worldPermissions
        if not perms.read then error(path .. ": Permission denied", 2) end
    end
    return fs.list(fs.combine(self.path, path))
end

-- TODO: Block access when a parent directory isn't readable
function filesystems.craftos:stat(process, path)
    local p = fs.combine(self.path, path)
    if p:find(self.path:gsub("^/", ""):gsub("/$", ""), 1, false) ~= 1 then return nil end
    local ok, attr = pcall(fs.attributes, p)
    if not ok or not attr then return nil end
    attr.type = attr.isDir and "directory" or "file"
    attr.special = {}
    attr.isDir = nil
    if not attr.modified then attr.modified = attr.modification end
    attr.modification = nil
    if attr.isReadOnly then
        -- If the file is read-only, it's from the ROM so permissions can't be set
        -- No owner
        attr.permissions = {}
        attr.worldPermissions = {read = true, write = false, execute = true}
        return attr
    end
    attr.isReadOnly = nil
    attr.capacity = fs.getCapacity(p)
    attr.freeSpace = fs.getFreeSpace(p)
    local meta = self:getmeta(process.user, fs.combine(self.path, path))
    -- The path may exist on the filesystem but have no metadata.
    if meta then
        attr.owner = meta.owner
        attr.permissions = deepcopy(meta.permissions)
        attr.worldPermissions = deepcopy(meta.worldPermissions)
        attr.type = meta.type or attr.type
        attr.setuser = meta.setuser
    else
        attr.owner = "root" -- all files are root-owned by default
        attr.permissions = {
            root = {read = true, write = true, execute = true}
        }
        attr.worldPermissions = {read = true, write = false, execute = true}
        attr.setuser = false
    end
    return attr
end

function filesystems.craftos:remove(process, path)
    if self.readOnly then error(path .. ": Read-only filesystem", 2) end
    local stat = self:stat(process, path)
    if not stat then return end
    local function checkWriteRecursive(p)
        local s = self:stat(process, p)
        local perms = s.permissions[process.user] or s.worldPermissions
        if process.user ~= "root" and not perms.write then error(p .. ": Permission denied", 3) end
        if s.type == "directory" then
            if process.user ~= "root" and not perms.read then error(p .. ": Permission denied", 3) end
            for _, v in ipairs(fs.list(fs.combine(self.path, p))) do checkWriteRecursive(fs.combine(p, v)) end
        end
    end
    checkWriteRecursive(path)
    fs.delete(fs.combine(self.path, path))
    self:setmeta(process.user, fs.combine(self.path, path), nil)
end

function filesystems.craftos:rename(process, from, to)
    if self.readOnly then error("Read-only filesystem", 2) end
    local fromstat = self:stat(process, from)
    local tostat = self:stat(process, to)
    if not fromstat then error(from .. ": No such file or directory", 2)
    elseif tostat then error(to .. ": " .. tostat.type:gsub("%w", string.upper, 1) .. " already exists", 2) end
    tostat = self:stat(process, fs.getDir(to))
    if not tostat then
        self:mkdir(process, fs.getDir(to))
        tostat = self:stat(process, fs.getDir(to))
    end
    if process.user ~= "root" then
        local perms = tostat.permissions[process.user] or tostat.worldPermissions
        if not perms.write then error(to .. ": Permission denied", 2) end
    end
    fs.move(fs.combine(self.path, from), fs.combine(self.path, to))
    self:setmeta(process.user, fs.combine(self.path, to), self:getmeta(process.user, fs.combine(self.path, from)))
    self:setmeta(process.user, fs.combine(self.path, from), nil)
end

function filesystems.craftos:mkdir(process, path)
    if self.readOnly then error(path .. ": Read-only filesystem", 2) end
    local stat = self:stat(process, path)
    if stat then
        if stat.type == "directory" then return
        else error(path .. ": File already exists", 2) end
    end
    local parts = split(path, "/\\")
    local i = #parts - 1
    repeat
        stat = self:stat(process, table.concat(parts, "/", 1, i))
        if stat then
            if stat.type == "directory" then break
            else error(path .. ": File already exists", 2) end
        end
        i=i-1
    until stat or i <= 0
    if path:match "^/" then stat = assert(self:stat(process, "/"))
    else stat = assert(self:stat(process, process.dir)) end
    if process.user ~= "root" then
        local perms = stat.permissions[process.user] or stat.worldPermissions
        if not perms.write then error(path .. ": Permission denied", 2) end
    end
    local meta = {
        type = "directory",
        owner = process.user,
        permissions = deepcopy(stat.permissions),
        worldPermissions = deepcopy(stat.worldPermissions)
    }
    local t = meta.permissions[stat.owner]
    meta.permissions[stat.owner] = nil
    meta.permissions[process.user] = t
    i=i+1
    while i <= #parts do
        self:setmeta(process.user, fs.combine(self.path, table.concat(parts, 1, i)), deepcopy(meta))
        i=i+1
    end
    fs.makeDir(fs.combine(self.path, path))
end

function filesystems.craftos:chmod(process, path, user, mode)
    if self.readOnly then error(path .. ": Read-only filesystem", 2) end
    local stat = self:stat(process, path)
    if not stat then error(path .. ": No such file or directory", 2) end
    if not stat.owner or (process.user ~= "root" and process.user ~= stat.owner) then error(path .. ": Permission denied", 2) end
    local perms
    if user == nil then perms = stat.worldPermissions
    else
        perms = stat.permissions[user]
        if not perms then
            perms = deepcopy(stat.worldPermissions)
            stat.permissions[user] = perms
        end
    end
    if type(mode) == "string" then
        if mode:match "^[%+%-=][rwxs]+$" then
            local m = mode:sub(1, 1)
            local t = {}
            for c in mode:gmatch("[rwxs]") do
                if c == "r" then t.read = true
                elseif c == "w" then t.write = true
                elseif c == "s" then t.setuser = true
                else t.execute = true end
            end
            if m == "+" then
                if t.read then perms.read = true end
                if t.write then perms.write = true end
                if t.execute then perms.execute = true end
                if t.setuser then stat.setuser = true end
            elseif m == "-" then
                if t.read then perms.read = false end
                if t.write then perms.write = false end
                if t.execute then perms.execute = false end
                if t.setuser then stat.setuser = false end
            else
                perms.read = t.read or false
                perms.write = t.write or false
                perms.execute = t.execute or false
                stat.setuser = t.setuser or false
            end
        else
            perms.read = mode:sub(1, 1) ~= "-"
            perms.write = mode:sub(2, 2) ~= "-"
            perms.execute = mode:sub(3, 3) ~= "-"
            stat.setuser = mode:sub(3, 3) == "s"
        end
    elseif type(mode) == "number" then
        stat.setuser = bit32.btest(mode, 8)
        perms.read = bit32.btest(mode, 4)
        perms.write = bit32.btest(mode, 2)
        perms.execute = bit32.btest(mode, 1)
    else
        if mode.read ~= nil then perms.read = mode.read end
        if mode.write ~= nil then perms.write = mode.write end
        if mode.execute ~= nil then perms.execute = mode.execute end
        if mode.setuser ~= nil then stat.setuser = mode.setuser end
    end
    self:setmeta(process.user, fs.combine(self.path, path), deepcopy(stat))
end

function filesystems.craftos:chown(process, path, owner)
    if self.readOnly then error(path .. ": Read-only filesystem", 2) end
    local stat = self:stat(process, path)
    if not stat then error(path .. ": No such file or directory", 2) end
    if not stat.owner or (process.user ~= "root" and process.user ~= stat.owner) then error(path .. ": Permission denied", 2) end
    stat.owner = owner
    stat.setuser = false
    self:setmeta(process.user, fs.combine(self.path, path), deepcopy(stat))
end

function filesystems.craftos:info()
    return "craftos", self.path, {ro = self.readOnly}
end

-- tmpfs implementation
-- tmpfs stores data in the same format as craftos meta, but with the addition of storing file data in .data

function filesystems.tmpfs:getpath(user, path)
    local t = self
    for _,p in ipairs(split(path, "/\\")) do
        if not t then return nil
        elseif t.type ~= "directory" then error("Not a directory", 2)
        elseif t.permissions[user] then if not t.permissions[user].execute then error("Permission denied", 2) end
        elseif not t.worldPermissions.execute then error("Permission denied", 2) end
        t = t.contents[p]
        -- TODO: handle link traversal
        --if t and t.meta.type == "link" then t = ? end
    end
    return t
end

function filesystems.tmpfs:setpath(user, path, data)
    local t = self
    local e = split(path, "/\\")
    local last = e[#e]
    e[#e] = nil
    for _,p in ipairs(e) do
        if t.type ~= "directory" then error("Not a directory", 2)
        elseif t.permissions[user] then if not t.permissions[user].execute then error("Permission denied", 2) end
        elseif not t.worldPermissions.execute then error("Permission denied", 2) end
        if not t.contents[p] then t.contents[p] = { -- Initialize with default directory meta if not present
            type = "directory",
            owner = t.owner,
            permissions = deepcopy(t.permissions),
            worldPermissions = deepcopy(t.worldPermissions),
            setuser = false,
            created = os.epoch "utc",
            modified = os.epoch "utc",
            contents = {}
        } end
        t = t.contents[p]
        -- TODO: handle link traversal
        --if t and t.meta.type == "link" then t = ? end
    end
    if t.type ~= "directory" then error("Not a directory", 2)
    elseif user ~= "root" then
        if t.permissions[user] then if not t.permissions[user].execute then error("Permission denied", 2) end
        elseif not t.worldPermissions.execute then error("Permission denied", 2) end
    end
    t.contents[last] = data
end

function filesystems.tmpfs:new(process, src, options)
    return setmetatable({
        type = "directory",
        owner = process.user,
        permissions = {
            [process.user] = {read = true, write = true, execute = true}
        },
        worldPermissions = {read = true, write = false, execute = true},
        setuser = false,
        created = os.epoch "utc",
        modified = os.epoch "utc",
        contents = {}
    }, {__index = self})
end

function filesystems.tmpfs:_open_internal(process, path, mode)
    local pos = 1
    local closed = false
    local function setenv(t)
        for _, v in pairs(t) do setfenv(v, process.env) debug.protect(v) end
        return setmetatable(t, {__name = "file"})
    end
    local epoch = os.epoch
    if mode == "r" then
        local data = self:getpath(process.user, path).data
        return setenv {
            readLine = function(newline)
                if closed then error("attempt to use a closed file", 2) end
                if pos > #data then return nil end
                local d
                d, pos = data:match("([^\n]*" .. (newline and "\n?)" or ")\n?") .. "()", pos)
                return d
            end,
            readAll = function()
                if closed then error("attempt to use a closed file", 2) end
                if pos > #data then return nil end
                local d = data:sub(pos)
                pos = #d + 1
                return d
            end,
            read = function(n)
                if closed then error("attempt to use a closed file", 2) end
                if n ~= nil and type(n) ~= "number" then error("bad argument #1 (expected number, got " .. type(n) .. ")", 2) end
                n = n or 1
                if pos > #data then return nil end
                local d = data:sub(pos, pos + n - 1)
                pos = pos + n
                return d
            end,
            close = function()
                if closed then error("attempt to use a closed file", 2) end
                closed = true
            end
        }
    elseif mode == "w" or mode == "a" then
        local data = self:getpath(process.user, path)
        if mode == "w" then data.data, data.modified = "", epoch "utc" else pos = #data.data end
        local buf = data.data
        return setenv {
            write = function(d)
                if closed then error("attempt to use a closed file", 2) end
                buf = buf .. tostring(d)
            end,
            writeLine = function(d)
                if closed then error("attempt to use a closed file", 2) end
                buf = buf .. tostring(d) .. "\n"
            end,
            flush = function()
                if closed then error("attempt to use a closed file", 2) end
                data.data, data.modified = buf, epoch "utc"
            end,
            close = function()
                if closed then error("attempt to use a closed file", 2) end
                data.data, data.modified = buf, epoch "utc"
                closed = true
            end
        }
    elseif mode == "rb" then
        local data = self:getpath(process.user, path).data
        return setenv {
            readLine = function(newline)
                if closed then error("attempt to use a closed file", 2) end
                if pos > #data then return nil end
                local d
                d, pos = data:match("([^\n]*" .. (newline and "\n?)" or ")\n?") .. "()", pos)
                return d
            end,
            readAll = function()
                if closed then error("attempt to use a closed file", 2) end
                if pos > #data then return nil end
                local d = data:sub(pos)
                pos = #d + 1
                return d
            end,
            read = function(n)
                if closed then error("attempt to use a closed file", 2) end
                if n ~= nil and type(n) ~= "number" then error("bad argument #1 (expected number, got " .. type(n) .. ")", 2) end
                if pos > #data then return nil end
                if n then
                    local d = data:sub(pos, pos + n - 1)
                    pos = pos + n
                    return d
                else
                    local d = data:byte(pos)
                    pos = pos + 1
                    return d
                end
            end,
            seek = function(whence, offset)
                if whence ~= nil and type(whence) ~= "string" then error("bad argument #1 (expected string, got " .. type(whence) .. ")", 2) end
                if offset ~= nil and type(offset) ~= "number" then error("bad argument #2 (expected number, got " .. type(offset) .. ")", 2) end
                whence = whence or "cur"
                offset = offset or 0
                if closed then error("attempt to use closed file", 2) end
                if whence == "set" then pos = offset + 1
                elseif whence == "cur" then pos = pos + offset
                elseif whence == "end" then pos = math.max(#data - offset, 1)
                else error("Invalid whence", 2) end
                return pos - 1
            end,
            close = function()
                if closed then error("attempt to use a closed file", 2) end
                closed = true
            end
        }
    elseif mode == "wb" or mode == "ab" then
        local data = self:getpath(process.user, path)
        if mode == "wb" then data.data, data.modified = "", epoch "utc" else pos = #data.data end
        local buf = data.data
        return setenv {
            write = function(d)
                if closed then error("attempt to use a closed file", 2) end
                if type(d) == "number" then buf, pos = buf:sub(1, pos - 1) .. string.char(d) .. buf:sub(pos + 1), pos + 1
                elseif type(d) == "string" then buf, pos = buf:sub(1, pos - 1) .. d .. buf:sub(pos + #d), pos + #d
                else error("bad argument #1 (expected string or number, got " .. type(d) .. ")", 2) end
            end,
            writeLine = function(d)
                if closed then error("attempt to use a closed file", 2) end
                if type(d) == "number" then buf, pos = buf:sub(1, pos - 1) .. string.char(d) .. "\n" .. buf:sub(pos + 2), pos + 2
                elseif type(d) == "string" then buf, pos = buf:sub(1, pos - 1) .. d .. "\n" .. buf:sub(pos + #d + 1), pos + #d + 1
                else error("bad argument #1 (expected string or number, got " .. type(d) .. ")", 2) end
            end,
            seek = function(whence, offset)
                if whence ~= nil and type(whence) ~= "string" then error("bad argument #1 (expected string, got " .. type(whence) .. ")", 2) end
                if offset ~= nil and type(offset) ~= "number" then error("bad argument #2 (expected number, got " .. type(offset) .. ")", 2) end
                whence = whence or "cur"
                offset = offset or 0
                if closed then error("attempt to use closed file", 2) end
                if whence == "set" then pos = offset + 1
                elseif whence == "cur" then pos = pos + offset
                elseif whence == "end" then pos = math.max(#buf - offset, 1)
                else error("Invalid whence", 2) end
                return pos - 1
            end,
            flush = function()
                if closed then error("attempt to use a closed file", 2) end
                data.data, data.modified = buf, epoch "utc"
            end,
            close = function()
                if closed then error("attempt to use a closed file", 2) end
                data.data, data.modified = buf, epoch "utc"
                closed = true
            end
        }
    else return nil, "Invalid mode" end
end

function filesystems.tmpfs:open(process, path, mode)
    local ok, stat = pcall(self.stat, self, process, path)
    if not ok then return nil, stat
    elseif not stat then
        if mode:sub(1, 1) == "w" or mode:sub(1, 1) == "a" then
            local pok, pstat = pcall(self.stat, self, process, fs.getDir(path))
            if not pok then
                local mok, err = pcall(self.mkdir, self, process, fs.getDir(path))
                if not mok then return nil, err:gsub("kernel:%d: ", "") end
                pstat = self:stat(process, fs.getDir(path))
            end
            if process.user ~= "root" then
                local perms = pstat.permissions[process.user] or pstat.worldPermissions
                if not perms.write then return nil, "Permission denied" end
            end
            local meta = {
                type = "file",
                owner = process.user,
                permissions = deepcopy(pstat.permissions),
                worldPermissions = deepcopy(pstat.worldPermissions),
                setuser = false,
                created = os.epoch "utc",
                modified = os.epoch "utc",
                data = ""
            }
            -- We do a swap here so it doesn't break if pstat.owner == process.user
            local t = meta.permissions[pstat.owner]
            meta.permissions[pstat.owner] = nil
            meta.permissions[process.user] = t
            self:setpath(process.user, path, meta)
            return self:_open_internal(process, path, mode)
        else return nil, "File not found" end
    elseif stat.type == "directory" then return nil, "Is a directory" end
    if process.user ~= "root" then
        local perms = stat.permissions[process.user] or stat.worldPermissions
        --syslog.debug(path, mode, perms.read, perms.write, perms.execute)
        if (mode:sub(1, 1) == "r" and not perms.read) or ((mode:sub(1, 1) == "w" or mode:sub(1, 1) == "a") and not perms.write) then return nil, "Permission denied" end
    end
    return self:_open_internal(process, path, mode)
end

function filesystems.tmpfs:list(process, path)
    local data = self:getpath(process.user, path)
    if not data or data.type ~= "directory" then error(path .. ": Not a directory", 2) end
    if process.user ~= "root" then
        local perms = data.permissions[process.user] or data.worldPermissions
        if not perms.read then error(path .. ": Permission denied", 2) end
    end
    local retval = {}
    for k in pairs(data.contents) do retval[#retval+1] = k end
    table.sort(retval)
    return retval
end

function filesystems.tmpfs:stat(process, path)
    local data = self:getpath(process.user, path)
    if not data then return nil end
    return {
        size = data.type == "file" and #data.data or (data.type == "directory" and #data.contents or 0),
        type = data.type,
        created = data.created,
        modified = data.modified,
        owner = data.owner,
        permissions = deepcopy(data.permissions),
        worldPermissions = deepcopy(data.worldPermissions),
        setuser = data.setuser,
        capacity = math.huge,
        freeSpace = math.huge,
        special = {}
    }
end

function filesystems.tmpfs:remove(process, path)
    local parent = self:getpath(process.user, fs.getDir(path))
    local name = fs.getName(path)
    if not parent or parent.type ~= "directory" or not parent.contents[name] then return end
    if process.user ~= "root" and not (parent.permissions[process.user] or parent.worldPermissions).write then error(path .. ": Permission denied", 2) end
    local data = parent.contents[name]
    if process.user ~= "root" and not (data.permissions[process.user] or data.worldPermissions).write then error(path .. ": Permission denied", 2) end
    local function checkWriteRecursive(s)
        local perms = s.permissions[process.user] or s.worldPermissions
        if process.user ~= "root" and not perms.write then error(path .. ": Permission denied", 3) end
        if s.type == "directory" then
            if process.user ~= "root" and not perms.read then error(path .. ": Permission denied", 3) end
            for _, v in pairs(s.contents) do checkWriteRecursive(v) end
        end
    end
    checkWriteRecursive(data)
    parent.contents[name] = nil
    parent.modified = os.epoch "utc"
end

function filesystems.tmpfs:rename(process, from, to)
    local fparent = self:getpath(process.user, fs.getDir(from))
    local fname = fs.getName(from)
    if not fparent or fparent.type ~= "directory" or not fparent.contents[fname] then error(from .. ": No such file or directory", 2) end
    if process.user ~= "root" and not (fparent.permissions[process.user] or fparent.worldPermissions).write then error(from .. ": Permission denied", 2) end
    local fdata = fparent.contents[fname]
    if process.user ~= "root" and not (fdata.permissions[process.user] or fdata.worldPermissions).write then error(from .. ": Permission denied", 2) end
    local tparent = self:getpath(process.user, fs.getDir(to))
    local tname = fs.getName(to)
    if not tparent or tparent.type ~= "directory" then error(to .. ": No such file or directory", 2) end
    if process.user ~= "root" and not (tparent.permissions[process.user] or tparent.worldPermissions).write then error(to .. ": Permission denied", 2) end
    local tdata = tparent.contents[tname]
    if tdata then error(to .. ": File already exists", 2) end
    tparent.contents[tname], fparent.contents[fname] = fdata, nil
    local time = os.epoch "utc"
    fparent.modified, tparent.modified = time, time
end

function filesystems.tmpfs:mkdir(process, path)
    local t = self
    for _,p in ipairs(split(path, "/\\")) do
        local perms = t.permissions[process.user] or t.worldPermissions
        if t.type ~= "directory" then error(path .. ": File exists", 2)
        elseif process.user ~= "root" and not perms.execute then error(path .. ": Permission denied", 2) end
        if not t.contents[p] then
            if process.user ~= "root" and not perms.write then error(path .. ": Permission denied", 2) end
            t.contents[p] = { -- Initialize with default directory meta if not present
                type = "directory",
                owner = t.owner,
                permissions = deepcopy(t.permissions),
                worldPermissions = deepcopy(t.worldPermissions),
                created = os.epoch "utc",
                modified = os.epoch "utc",
                contents = {}
            }
            t.modified = os.epoch "utc"
        end
        t = t.contents[p]
        -- TODO: handle link traversal
        --if t and t.meta.type == "link" then t = ? end
    end
end

function filesystems.tmpfs:chmod(process, path, user, mode)
    local stat = self:getpath(process.user, path)
    if not stat then error(path .. ": No such file or directory", 2) end
    if not stat.owner or (process.user ~= "root" and process.user ~= stat.owner) then error(path .. ": Permission denied", 2) end
    local perms
    if user == nil then perms = stat.worldPermissions
    else
        perms = stat.permissions[user]
        if not perms then
            perms = deepcopy(stat.worldPermissions)
            stat.permissions[user] = perms
        end
    end
    if type(mode) == "string" then
        if mode:match "^[%+%-=][rwxs]+$" then
            local m = mode:sub(1, 1)
            local t = {}
            for c in mode:gmatch("[rwxs]") do
                if c == "r" then t.read = true
                elseif c == "w" then t.write = true
                elseif c == "s" then t.setuser = true
                else t.execute = true end
            end
            if m == "+" then
                if t.read then perms.read = true end
                if t.write then perms.write = true end
                if t.execute then perms.execute = true end
                if t.setuser then stat.setuser = true end
            elseif m == "-" then
                if t.read then perms.read = false end
                if t.write then perms.write = false end
                if t.execute then perms.execute = false end
                if t.setuser then stat.setuser = false end
            else
                perms.read = t.read or false
                perms.write = t.write or false
                perms.execute = t.execute or false
                stat.setuser = t.setuser or false
            end
        else
            perms.read = mode:sub(1, 1) ~= "-"
            perms.write = mode:sub(2, 2) ~= "-"
            perms.execute = mode:sub(3, 3) ~= "-"
            stat.setuser = mode:sub(3, 3) == "s"
        end
    elseif type(mode) == "number" then
        stat.setuser = bit32.btest(mode, 8)
        perms.read = bit32.btest(mode, 4)
        perms.write = bit32.btest(mode, 2)
        perms.execute = bit32.btest(mode, 1)
    else
        if mode.read ~= nil then perms.read = mode.read end
        if mode.write ~= nil then perms.write = mode.write end
        if mode.execute ~= nil then perms.execute = mode.execute end
        if mode.setuser ~= nil then stat.setuser = mode.setuser end
    end
    --self:setpath(process.user, fs.combine(self.path, path), deepcopy(stat)) -- may not be needed?
end

function filesystems.tmpfs:chown(process, path, owner)
    local stat = self:getpath(process.user, path)
    if not stat then error(path .. ": No such file or directory", 2) end
    if not stat.owner or (process.user ~= "root" and process.user ~= stat.owner) then error(path .. ": Permission denied", 2) end
    stat.owner = owner
    stat.setuser = false
    --self:setpath(process.user, fs.combine(self.path, path), deepcopy(stat))
end

function filesystems.tmpfs:info()
    return "tmpfs", "memory", {}
end

-- drivefs implementation
-- drivefs just inherits from craftos, but automatically locates drive mounts from hardware devices.

setmetatable(filesystems.drivefs, {__index = filesystems.craftos})

function filesystems.drivefs:new(process, src, options)
    local drive = hardware.get(src)
    if not drive then error("Could not find drive at " .. src) end
    local fs = filesystems.craftos:new(process, hardware.call(process, drive, "getMountPath"), options)
    fs.drive = drive.uuid
    return setmetatable(fs, {__index = self})
end

function filesystems.drivefs:info()
    return "drivefs", self.drive, {ro = self.readOnly}
end

-- Syscalls

local function getMount(process, path)
    local fullPath = split(fs.combine(path:sub(1, 1) == "/" and "" or process.dir, path), "/\\")
    if #fullPath == 0 then return mounts[""], path, "" end
    local maxPath
    for k in pairs(mounts) do
        local ok = true
        for i,c in ipairs(split(k, "/\\")) do if fullPath[i] ~= c then ok = false break end end
        if ok and (not maxPath or #k > #maxPath) then maxPath = k end
    end
    if not maxPath then panic("Could not find mount for path " .. path .. ". Where is root?") end
    local parts = split(maxPath, "/\\")
    local p = #fullPath >= #parts + 1 and fs.combine(table.unpack(fullPath, #parts + 1, #fullPath)) or ""
    --syslog.debug(path, #parts, #fullPath, p)
    return mounts[maxPath], p, maxPath
end

--- Opens a file for reading or writing.
-- @tparam Process process The process to operate as
-- @tparam string path The file path to open, which may be absolute or relative
-- to the process's working directory
-- @tparam string mode The mode to open the file as
-- @treturn[1] Handle The new file handle
-- @treturn[2] nil If an error occurred
-- @treturn[2] string An error message describing why the file couldn't be opened
function filesystem.open(process, path, mode)
    expect(0, process, "table")
    expect(1, path, "string")
    expect(2, mode, "string")
    if not mode:match "^[rwa]b?$" then error("Invalid mode", 0) end
    local mount, p = getMount(process, path)
    return mount:open(process, p, mode)
end

--- Returns a list of file names in the directory.
-- @tparam Process process The process to operate as
-- @tparam string path The file path to list, which may be absolute or relative
-- to the process's working directory
-- @treturn {string} A list of file names present in the directory
function filesystem.list(process, path)
    expect(0, process, "table")
    expect(1, path, "string")
    local mount, p = getMount(process, path)
    return mount:list(process, p)
end

--- Returns a table with information about the selected path.
-- @tparam Process process The process to operate as
-- @tparam string path The file path to stat, which may be absolute or relative
-- to the process's working directory
-- @treturn[1] table A table with information about the path (see the docs for
-- the `stat` syscall for more info)
-- @treturn[2] nil If an error occurred
-- @treturn[2] string An error message describing why the file couldn't be opened
function filesystem.stat(process, path)
    expect(0, process, "table")
    expect(1, path, "string")
    local mount, p, mp = getMount(process, path)
    local res, err = mount:stat(process, p)
    if res then res.mountpoint = "/" .. mp end
    return res, err
end

--- Removes a file or directory.
-- @tparam Process process The process to operate as
-- @tparam string path The file path to remove, which may be absolute or relative
-- to the process's working directory
function filesystem.remove(process, path)
    expect(0, process, "table")
    expect(1, path, "string")
    local mount, p = getMount(process, path)
    return mount:remove(process, p)
end

--- Renames (moves) a file or directory.
-- @tparam Process process The process to operate as
-- @tparam string path The file path to rename, which may be absolute or relative
-- to the process's working directory
-- @tparam The new path the file will be at, which may be in another directory
-- but must be on the same mountpoint
function filesystem.rename(process, from, to)
    expect(0, process, "table")
    expect(1, from, "string")
    expect(2, to, "string")
    local mountA, pA = getMount(process, from)
    local mountB, pB = getMount(process, to)
    if mountA ~= mountB then error("Attempt to rename file across two filesystems", 0) end
    return mountA:rename(process, pA, pB)
end

--- Creates a new directory and any parent directories.
-- @tparam Process process The process to operate as
-- @tparam string path The directory to create, which may be absolute or relative
-- to the process's working directory
function filesystem.mkdir(process, path)
    expect(0, process, "table")
    expect(1, path, "string")
    local mount, p = getMount(process, path)
    return mount:mkdir(process, p)
end

--- Changes the permissions (mode) of a file or directory for the specified user.
-- @tparam Process process The process to operate as
-- @tparam string path The file path to modify, which may be absolute or relative
-- to the process's working directory
-- @tparam string|nil user The user to change the permissions for, or `nil` for all users
-- @tparam number|string|{read = boolean?, write = boolean?, execute = boolean?} mode The
-- new permissions for the user (see the docs for the `chmod` syscall for more info)
function filesystem.chmod(process, path, user, mode)
    expect(0, process, "table")
    expect(1, path, "string")
    expect(2, user, "string", "nil")
    expect(3, mode, "number", "string", "table")
    if type(mode) == "string" and not mode:match "^[%+%-=][rwxs]+$" and not mode:match "^[r%-][w%-][xs%-]$" then
        error("bad argument #3 (invalid mode)", 2)
    elseif type(mode) == "table" then
        expect.field(mode, "read", "boolean", "nil")
        expect.field(mode, "write", "boolean", "nil")
        expect.field(mode, "execute", "boolean", "nil")
    end
    local mount, p = getMount(process, path)
    return mount:chmod(process, p, user, mode)
end

--- Changes the owner of a file or directory.
-- @tparam Process process The process to operate as
-- @tparam string path The file path to modify, which may be absolute or relative
-- to the process's working directory
-- @tparam string user The user that will own the file
function filesystem.chown(process, path, user)
    expect(0, process, "table")
    expect(1, path, "string")
    expect(2, user, "string")
    local mount, p = getMount(process, path)
    return mount:chown(process, p, user)
end

--- Mounts a disk device to a path using the specified filesystem and options.
-- @tparam Process process The process to operate as
-- @tparam string type The type of filesystem to mount
-- @tparam string src The source device to mount
-- @tparam string dest The destination mountpoint
-- @tparam[opt] table options Any options to pass to the mounter
function filesystem.mount(process, type, src, dest, options)
    expect(0, process, "table")
    expect(1, type, "string")
    expect(2, src, "string")
    expect(3, dest, "string")
    expect(4, options, "table", "nil")
    if not filesystems[type] then error("No such filesystem '" .. type .. "'", 2) end
    local stat = filesystem.stat(process, dest)
    if not stat then error("Could not mount to " .. dest .. ": No such directory", 2)
    elseif stat.type ~= "directory" then error("Could not mount to " .. dest .. ": Not a directory", 2)
    elseif not (stat.permissions[process.user] or stat.worldPermissions).write then error("Could not mount to " .. dest .. ": Permission denied", 2) end
    local mount = filesystems[type]:new(process, src, options or {})
    mounts[fs.combine(dest)] = mount
end

--- Unmounts a filesystem at a mountpoint.
-- @tparam Process process The process to operate as
-- @tparam string path The mountpoint to remove, which may be absolute or relative
-- to the process's working directory
function filesystem.unmount(process, path)
    expect(0, process, "table")
    expect(1, path, "string")
    if not mounts[fs.combine(path)] then error(path .. ": No such mount", 2) end
    local stat = mounts[fs.combine(path)]:stat(process, "")
    if not stat then error("Internal error in unmount: could not get stat for root! Please report this to the maintainer of the target filesystem.", 2)
    elseif not (stat.permissions[process.user] or stat.worldPermissions).write then error(path .. ": Permission denied", 2) end
    mounts[fs.combine(path)] = nil
end

function filesystem.mountlist(process)
    expect(0, process, "table")
    local retval = {}
    for k, v in pairs(mounts) do
        local type, path, options = v:info()
        retval[#retval+1] = {path = k, type = type, source = path, options = options}
    end
    return retval
end

--- Combines the specified path components into a single path.
-- @tparam string first The first path component
-- @tparam string ... Any additional path components to add
-- @treturn string The final combined path
function filesystem.combine(first, ...)
    local str = fs.combine(first, ...)
    if first:match "^/" then str = "/" .. str end
    return str
end

function syscalls.open(process, thread, ...) return filesystem.open(process, ...) end
function syscalls.list(process, thread, ...) return filesystem.list(process, ...) end
function syscalls.stat(process, thread, ...) return filesystem.stat(process, ...) end
function syscalls.remove(process, thread, ...) return filesystem.remove(process, ...) end
function syscalls.rename(process, thread, ...) return filesystem.rename(process, ...) end
function syscalls.mkdir(process, thread, ...) return filesystem.mkdir(process, ...) end
function syscalls.chmod(process, thread, ...) return filesystem.chmod(process, ...) end
function syscalls.chown(process, thread, ...) return filesystem.chown(process, ...) end
function syscalls.mount(process, thread, ...) return filesystem.mount(process, ...) end
function syscalls.unmount(process, thread, ...) return filesystem.unmount(process, ...) end
function syscalls.mountlist(process, thread, ...) return filesystem.mountlist(process, ...) end
function syscalls.combine(process, thread, ...) return filesystem.combine(...) end

-- This syscall provides CraftOS APIs (and modules) without having to mount the entire ROM.
-- It uses the process's environment, so if the API requires other CraftOS APIs, load them
-- as globals in the process's environment first.
function syscalls.loadCraftOSAPI(process, thread, apiName)
    expect(1, apiName, "string")
    local env
    env = setmetatable({
        dofile = function(path)
            local file, err = fs.open(path, "rb")
            if not file then error("Could not open module: " .. err, 0) end
            local fn, err = load(file.readAll(), "@" .. path, nil, env)
            file.close()
            if not fn then error("Could not load module: " .. err, 0) end
            return fn()
        end,
        require = function(name)
            return env.dofile("rom/modules/main/" .. name:gsub("%.", "/") .. ".lua")
        end
    }, {__index = process.env})
    if apiName:sub(1, 3) == "cc." then
        local path = fs.combine("rom/modules/main", apiName:gsub("%.", "/") .. ".lua")
        if not path:match "^/?rom/modules/main/" then error("Invalid module path", 0) end
        return env.dofile(path)
    else
        if not apiName:match "^[a-z]+$" then error("Invalid API name", 0) end
        local path = fs.combine("rom/apis", apiName .. ".lua")
        local file, err = fs.open(path, "rb")
        if not file then error("Could not open module: " .. err, 0) end
        local fn, err = load(file.readAll(), "@" .. path, nil, env)
        file.close()
        if not fn then error("Could not load module: " .. err, 0) end
        fn()
        local t = {}
        for k,v in pairs(env) do if k ~= "dofile" then t[k] = v end end
        return t
    end
end

mounts[""] = filesystems[args.rootfstype]:new(KERNEL, args.root, {})

--#endregion

--#region 10-lualib.lua

local do_syscall = do_syscall
local expect = expect

local function mult64on32(ah, al, bh, bl)
    local a = {bit32.extract(al, 0, 16), bit32.extract(al, 16, 16), bit32.extract(ah, 0, 16), bit32.extract(ah, 16, 16)}
    local b = {bit32.extract(bl, 0, 16), bit32.extract(bl, 16, 16), bit32.extract(bh, 0, 16), bit32.extract(bh, 16, 16)}
    local partial = {{0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}, {0, 0, 0, 0, 0}}
    for bi = 1, 4 do
        for ai = 1, 4 do
            local n = a[ai] * b[bi] + partial[bi][ai]
            partial[bi][ai+1], partial[bi][ai] = bit32.rshift(n, 16), bit32.band(n, 0xFFFF)
        end
    end
    local q = {0, 0, 0, 0, 0, 0, 0, 0}
    for col = 1, 8 do
        for row = 1, 4 do q[col] = q[col] + (partial[row][col-row+1] or 0) end
        q[col+1], q[col] = bit32.rshift(q[col], 16), bit32.band(q[col], 0xFFFF)
    end
    return q[3] + q[4] * 0x10000, q[1] + q[2] * 0x10000
end
local function add64with32(b, ah, al)
    return ah + math.floor((al + b) / 0x100000000), bit32.band(al + b, 0xFFFFFFFF)
end

function makeRandom()
    local random_state_h, random_state_l = 0, 0
    local function next(bits)
        random_state_h, random_state_l = add64with32(0xB, mult64on32(random_state_h, random_state_l, 0x5, 0xDEECE66D))
        random_state_h = bit32.band(random_state_h, 0xFFFF)
        return math.floor(random_state_h / 2^(16-bits)) + math.floor(random_state_l / 2^(48-bits))
    end
    local function random(min, max)
        expect(1, min, "number", "nil")
        expect(2, max, "number", "nil")
        if min then
            expect.range(min, 0, 0x7FFFFFFF)
            if not max then min, max = 0, min
            else expect.range(max, 0, 0x7FFFFFFF) end
            local bound = max - min + 1
            local rand
            if math.log(bound, 2) % 1 == 0 then rand = bit32.rshift((bound * next(31)), 31)
            else
                local bits
                repeat
                    bits = next(31)
                    rand = bits % bound
                until bits - rand + (bound-1) >= 0
            end
            return rand + min
        else return (next(26) * 0x8000000 + next(27)) / 0x20000000000000 end
    end
    local function randomseed(seed)
        expect(1, seed, "number")
        random_state_h, random_state_l = bit32.band(bit32.bxor(0x5, math.floor(seed / 0x100000000)), 0xFFFF), bit32.bxor(0xDEECE66D, math.floor(seed))
    end
    randomseed(os.epoch "utc" * tonumber(tostring(next):match("%x+") or "1", 16))
    return random, randomseed
end

do
    -- PUC Lua's default randomizer is crap, so we're installing a custom one in the kernel as well.
    -- This gives us better precision for randomization on those systems.
    -- (This has no visible effect on Cobalt-based CC, as it uses the same algorithm.)
    math.random, math.randomseed = makeRandom()
end

--- Creates a new global table with a Lua 5.2 standard library installed.
-- @tparam Process process The process to generate for
-- @treturn _G A new global table for the process
function createLuaLib(process)
    local G = {}
    for _,v in ipairs{"assert", "error", "getfenv", "getmetatable", "ipairs", "next",
        "pairs", "pcall", "rawequal", "rawget", "rawset", "select", "setfenv",
        "setmetatable", "tonumber", "tostring", "type", "_VERSION", "xpcall", "collectgarbage"} do G[v] = _G[v] end
    -- TODO: remove collectgarbage!!!

    -- TODO: update the below notice since we can just localize globals we need (!)

    -- We can't use any kernel-level globals like `expect` here, so argument checks will be manual.
    -- Normally using upvalues wouldn't be allowed either, but dbprotect blocks access so it should be alright.

    function G.dofile(path)
        if path ~= nil and type(path) ~= "string" then error("bad argument #1 (expected string, got " .. type(path) .. ")", 2) end
        local fn, err = loadfile(path or io.stdin:read("*a"), nil, _G)
        if not fn then error(err, 2) end
        return fn()
    end

    local load = load
    if _VERSION == "Lua 5.1" then
        function G.load(chunk, name, mode, env)
            -- Shadow environment table to add proper _ENV support
            -- TODO: Figure out if this could break anything
            env = env or process.env
            return load(chunk, name, mode, setmetatable({}, {
                __index = function(_, idx)
                    if idx == "_ENV" then return env
                    else return env[idx] end
                end,
                __newindex = function(_, idx, val)
                    if idx == "_ENV" then env = val
                    else env[idx] = val end
                end,
                __pairs = function()
                    return next, env
                end,
                __len = function()
                    return #env
                end
            }))
        end
    else G.load = function(chunk, name, mode, env) return load(chunk, name, mode, env or process.env) end end

    function G.loadfile(path, mode, env)
        if env == nil and type(mode) == "table" then env, mode = mode, nil end
        if type(path) ~= "string" then error("bad argument #1 (expected string, got " .. type(path) .. ")", 2) end
        if mode ~= nil and type(mode) ~= "string" then error("bad argument #2 (expected string, got " .. type(mode) .. ")", 2) end
        if env ~= nil and type(env) ~= "table" then error("bad argument #3 (expected table, got " .. type(env) .. ")", 2) end
        local file, err = do_syscall("open", path, "rb")
        if not file then error(err, 2) end
        local data = file.readAll()
        file.close()
        return load(data, "@" .. path, mode, env)
    end

    function G.print(...)
        local args = table.pack(...)
        args[args.n+1] = "\n"
        return do_syscall("write", table.unpack(args, 1, args.n + 1))
    end

    G.coroutine = deepcopy(coroutine)
    G.string = deepcopy(string)
    G.table = deepcopy(table)
    G.math = deepcopy(math)
    G.bit32 = deepcopy(bit32)

    -- The default math.random uses a global seed which cannot be shared between processes,
    -- so we need to implement our own randomizer.

    G.math.random, G.math.randomseed = makeRandom()

    -- Coroutines are also preempted, so we'll help out by automatically preempting the caller too.
    -- NOTE: Do not intentionally yield a coroutine with a single `preempt` value! This will trigger
    -- the preemption code here, making your coroutine not actually yield back to your program.
    local oldresume = G.coroutine.resume
    G.coroutine.resume = function(...)
        local retval = table.pack(oldresume(...))
        while retval.n == 2 and retval[1] == true and retval[2] == "preempt" do
            retval = table.pack(oldresume(coroutine.yield("preempt")))
        end
        return table.unpack(retval, 1, retval.n)
    end

    local stdin_buffer = ""
    local io_stdin = setmetatable({
        close = function() end,
        lines = function(self, ...)
            local args = table.pack(...)
            return function() return self:read(table.unpack(args, 1, args.n)) end
        end,
        read = function(self, fmt, ...)
            local s, e
            fmt = fmt or "*l"
            if type(fmt) == "number" then while #stdin_buffer < fmt do stdin_buffer = stdin_buffer .. do_syscall("read", fmt) end
            elseif type(fmt) == "string" then
                fmt = fmt:gsub("^%*", "")
                if fmt == "n" then
                    while not stdin_buffer:find("%d") do
                        local r = do_syscall("readline")
                        if r == nil then break end
                        stdin_buffer = stdin_buffer .. r
                    end
                elseif fmt == "a" then
                    while true do
                        local r = do_syscall("readline")
                        if r == nil then break end
                        stdin_buffer = stdin_buffer .. r
                    end
                elseif fmt == "l" or fmt == "L" then
                    local r = do_syscall("readline")
                    if r == nil then return nil end
                    stdin_buffer = stdin_buffer .. r .. "\n"
                else error("bad argument (invalid format '" .. fmt .. "')", 2) end
            else error("bad argument (expected string or number, got " .. type(fmt), 2) end
            if type(fmt) == "number" then s, e = stdin_buffer:sub(1, fmt), fmt + 1
            elseif fmt == "n" then s, e = stdin_buffer:match("(%d)()")
            elseif fmt == "a" then s, e = stdin_buffer, #stdin_buffer + 1
            elseif fmt == "l" then s, e = stdin_buffer:match("(.*)\n()")
            else s, e = stdin_buffer:match("(.*\n)()") end
            if not s then return nil end
            stdin_buffer = stdin_buffer:sub(e)
            if select("#", ...) > 0 then return s, self:read(...)
            else return s end
        end,
        seek = function() return nil, "Cannot seek default file" end,
        setvbuf = function() end
    }, {__name = "FILE*"})
    local io_stdout = setmetatable({
        close = function() end,
        flush = function() end,
        seek = function() return nil, "Cannot seek default file" end,
        setvbuf = function() end,
        write = function(self, ...)
            do_syscall("write", ...)
            return self
        end
    }, {__name = "FILE*"})
    local io_stderr = setmetatable({
        close = function() end,
        flush = function() end,
        seek = function() return nil, "Cannot seek default file" end,
        setvbuf = function() end,
        write = function(self, ...)
            do_syscall("writeerr", ...)
            return self
        end
    }, {__name = "FILE*"})
    local io_input, io_output = io_stdin, io_stdout

    local io_infile = {
        close = function(self)
            self._file.close()
            self._closed = true
        end,
        lines = function(self, ...)
            local args = table.pack(...)
            return function() return self:read(table.unpack(args, 1, args.n)) end
        end,
        read = function(self, fmt, ...)
            local v
            if fmt == nil then fmt = "l" end
            if type(fmt) == "number" then v = self._file.read(fmt)
            elseif type(fmt) == "string" then
                fmt = fmt:gsub("^%*", "")
                if fmt == "a" then v = self._file.readAll()
                elseif fmt == "l" then v = self._file.readLine(false)
                elseif fmt == "L" then v = self._file.readLine(true)
                elseif fmt == "n" then
                    local s, c = ""
                    repeat c = self._file.read(1) until c:match("%d")
                    while c:match("%d") do s, c = s .. c, self._file.read(1) end
                    v = tonumber(s)
                else error("bad argument (invalid format '" .. fmt .. "')", 2) end
            else error("bad argument (expected string or number, got " .. type(fmt) .. ")", 2) end
            if select("#", ...) > 0 then return v, self:read(...)
            else return v end
        end,
        seek = function(self, whence, offset)
            if self._file.seek then return self._file.seek(whence, offset)
            else return nil, "Cannot seek text file" end
        end,
        setvbuf = function() end
    }
    local io_outfile = {
        close = function(self)
            self._file.close()
            self._closed = true
        end,
        flush = function(self)
            self._file:flush()
        end,
        seek = function(self, whence, offset)
            if self._file.seek then return self._file.seek(whence, offset)
            else return nil, "Cannot seek text file" end
        end,
        setvbuf = function() end,
        write = function(self, ...)
            self._file.write(...)
            return self
        end
    }

    G.io = {
        close = function(file)
            if file == nil then io_output:close()
            elseif type(file) == "table" and getmetatable(file) and getmetatable(file).__name == "FILE*" then file:close()
            else error("bad argument #1 (expected FILE*, got " .. type(file) .. ")", 2) end
        end,
        flush = function()
            return io_output:flush()
        end,
        input = function(file)
            if file == nil then return io_input
            elseif type(file) == "string" then
                local h, err = io.open(file, "r")
                if not h then error(err, 2) end
                io_input = h
            elseif type(file) == "table" and getmetatable(file) and getmetatable(file).__name == "FILE*" then io_input = file
            else error("bad argument #1 (expected string or FILE*, got " .. type(file) .. ")", 2) end
        end,
        lines = function(filename, ...)
            if filename == nil then return io_input:lines(...) end
            if type(filename) ~= "string" then error("bad argument #1 (expected string, got " .. type(filename) .. ")", 2) end
            local h, err = io.open(filename, "r")
            if not h then error(err, 2) end
            local fn = h:lines(...)
            return function(...)
                local retval = table.pack(fn(...))
                if retval.n == 0 or retval[1] == nil then h:close() end
                return table.unpack(retval, 1, retval.n)
            end
        end,
        open = function(filename, mode)
            if type(filename) ~= "string" then error("bad argument #1 (expected string, got " .. type(filename) .. ")", 2) end
            if type(mode) ~= "string" then error("bad argument #2 (expected string, got " .. type(mode) .. ")", 2) end
            local file, err = do_syscall("open", filename, mode)
            if not file then return nil, err
            elseif mode:find("r") then return setmetatable({_file = file}, {__index = io_infile, __name = "FILE*"})
            else return setmetatable({_file = file}, {__index = io_outfile, __name = "FILE*"}) end
        end,
        output = function(file)
            if file == nil then return io_output
            elseif type(file) == "string" then
                local h, err = io.open(file, "w")
                if not h then error(err, 2) end
                io_output = h
            elseif type(file) == "table" and getmetatable(file) and getmetatable(file).__name == "FILE*" then io_output = file
            else error("bad argument #1 (expected string or FILE*, got " .. type(file) .. ")", 2) end
        end,
        -- Extra ability: if mode == "rw", then returns two file handles: first is "r" (stdin), second is "w" (stdout)
        popen = function(path, mode)
            expect(1, path, "string")
            mode = expect(2, mode, "string", "nil") or "r"
            if mode ~= "r" and mode ~= "w" and mode ~= "rw" then error("bad argument #2 (invalid mode)", 2) end
            if mode == "rw" then
                local ibuffer, obuffer = "", ""
                local pid
                local irhandle = {read = function(n)
                    if ibuffer == "" then return nil
                    elseif n then
                        local s = ibuffer:sub(1, n)
                        ibuffer = ibuffer:sub(n + 1)
                        return s
                    else
                        local s, e = ibuffer:match "([^\n]*)\n*()"
                        ibuffer = ibuffer:sub(e)
                        return s
                    end
                end}
                local iwhandle = {
                    write = function(s) ibuffer = ibuffer .. s end,
                    flush = function() end,
                    close = function()
                        local info = do_syscall("getpinfo", pid)
                        if not info then return end
                        repeat local ev, param = coroutine.yield() until ev == "process_complete" and param.pid == pid
                    end
                }
                local orhandle = {
                    read = function(n)
                        if obuffer == "" then return nil
                        elseif n then
                            local s = obuffer:sub(1, n)
                            obuffer = obuffer:sub(n + 1)
                            return s
                        else
                            local s, e = obuffer:match "([^\n]*)\n*()"
                            obuffer = obuffer:sub(e)
                            return s
                        end
                    end,
                    readLine = function()
                        local s, e = obuffer:match "([^\n]*)\n*()"
                        obuffer = obuffer:sub(e)
                        return s
                    end,
                    readAll = function()
                        local s = obuffer
                        obuffer = ""
                        return s
                    end,
                    close = function()
                        local info = do_syscall("getpinfo", pid)
                        if not info then return end
                        repeat local ev, param = coroutine.yield() until ev == "process_complete" and param.pid == pid
                    end
                }
                local owhandle = {write = function(s) obuffer = obuffer .. s end}
                pid = do_syscall("fork", function()
                    do_syscall("stdin", irhandle)
                    do_syscall("stdout", owhandle)
                    do_syscall("exec", "/bin/sh", "-c", path)
                end)
                return setmetatable({_file = orhandle}, {__index = io_infile, __name = "FILE*"}), setmetatable({_file = iwhandle}, {__index = io_outfile, __name = "FILE*"})
            else
                local buffer = ""
                local pid
                local rhandle = {
                    read = function(n)
                        if buffer == "" then return nil
                        elseif n then
                            local s = buffer:sub(1, n)
                            buffer = buffer:sub(n + 1)
                            return s
                        else
                            local s, e = buffer:match "([^\n]*)\n*()"
                            buffer = buffer:sub(e)
                            return s
                        end
                    end,
                    readLine = function()
                        local s, e = buffer:match "([^\n]*)\n*()"
                        buffer = buffer:sub(e)
                        return s
                    end,
                    readAll = function()
                        local s = buffer
                        buffer = ""
                        return s
                    end,
                    close = function()
                        local info = do_syscall("getpinfo", pid)
                        if not info then return end
                        repeat local ev, param = coroutine.yield() until ev == "process_complete" and param.pid == pid
                    end
                }
                local whandle = {
                    write = function(s) buffer = buffer .. s end,
                    flush = function() end,
                    close = function()
                        local info = do_syscall("getpinfo", pid)
                        if not info then return end
                        repeat local ev, param = coroutine.yield() until ev == "process_complete" and param.pid == pid
                    end
                }
                pid = do_syscall("fork", function()
                    do_syscall(mode == "r" and "stdout" or "stdin", mode == "r" and whandle or rhandle)
                    do_syscall("exec", "/bin/sh", "-c", path)
                end)
                return mode == "r" and setmetatable({_file = rhandle}, {__index = io_infile, __name = "FILE*"}) or setmetatable({_file = whandle}, {__index = io_outfile, __name = "FILE*"})
            end
        end,
        read = function(...)
            return io_input:read(...)
        end,
        tmpfile = function()
            -- TODO: make files delete on exit
            return io.open(os.tmpname(), "a")
        end,
        type = function(obj)
            if type(obj) == "table" and getmetatable(obj) and getmetatable(obj).__name == "FILE*" then
                if obj._closed then return "closed file" else return "file" end
            else return nil end
        end,
        write = function(...)
            return io_output:write(...)
        end,
        stdin = io_stdin,
        stdout = io_stdout,
        stderr = io_stderr
    }

    -- Nicely, we're providing a real `os` implementation instead of the jumbled mess CC gives us
    local oldos = os
    G.os = {
        clock = function() return do_syscall("clock") end,
        date = function(fmt, time)
            if type(fmt) == "string" and fmt:sub(1, 1) == "?" then
                local d = oldos.date("!" .. fmt:sub(2), time or oldos.epoch "ingame" / 1000)
                if type(d) == "table" then d.year = d.year - 1970 end
                return d
            else return oldos.date(fmt, time) end
        end,
        difftime = function(a, b) return a - b end,
        execute = function(path)
            do_syscall("exec", "/bin/sh", "-c", path)
        end,
        exit = function(code)
            do_syscall("exit", code)
        end,
        getenv = function(name)
            expect(1, name, "string")
            local env = do_syscall("getenv")
            if not env then return nil end
            return env[name]
        end,
        remove = function(path)
            expect(1, path, "string")
            local ok, err = do_syscall("remove", path)
            if not ok then ok = nil end
            return ok, err
        end,
        rename = function(from, to)
            expect(1, from, "string")
            expect(2, to, "string")
            local ok, err = do_syscall("rename", from, to)
            if not ok then ok = nil end
            return ok, err
        end,
        setlocale = function(locale)
            if locale then error("setlocale is not supported", 2)
            else return "C" end
        end,
        time = function(t)
            if t == "ingame" then return oldos.epoch "ingame" / 1000
            elseif t == "nano" then return oldos.epoch "nano" end
            expect(1, t, "table", "nil")
            if t then return oldos.time(t)
            else return oldos.epoch "utc" / 1000 end
        end,
        tmpname = function()
            local name = "/tmp/lua_"
            for i = 1, 6 do
                local n = math.random(1, 64)
                name = name .. ("qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890._"):sub(n, n)
            end
            return name
        end
    }

    G.debug = deepcopy(debug) -- since debug is protected, we can pretty much just stick it in here and be alright
    -- TODO: Restrict hook modification so programs can't arbitrarily disable preemption

    createRequire(process, G)

    G.periphemu = periphemu -- TODO: TEMPORARY

    -- Protect all global functions from debug
    for k,v in pairs(G) do
        if type(v) == "function" then
            pcall(setfenv, v, G)
            pcall(debug.protect, v)
        elseif type(v) == "table" and k ~= "debug" then
            for _,w in pairs(v) do if type(w) == "function" then pcall(setfenv, w, G) pcall(debug.protect, w) end end
        end
    end
    return G
end


--#endregion

--#region 15-term.lua

--- Returns a new TTY object.
-- @tparam table term The CraftOS terminal object to render on
-- @tparam number width The width of the TTY
-- @tparam number height The height of the TTY
-- @treturn TTY The new TTY object
function terminal.makeTTY(term, width, height)
    local retval = {
        isTTY = true,
        flags = {
            cbreak = false,
            delay = true,
            echo = true,
            keypad = false,
            nlcr = true,
            raw = false,
        },
        cursor = {x = 1, y = 1},
        cursorBlink = true,
        colors = {fg = '0', bg = 'f', bold = false},
        size = {width = width, height = height},
        dirtyLines = {},
        palette = {},
        dirtyPalette = {},
        buffer = "",
        preBuffer = "",
        isLocked = false,
        isGraphics = false,
        textBuffer = {},
        graphicsBuffer = {},
        frontmostProcess = nil,
        processList = {},
        eof = false,
        term = term,
    }
    for y = 1, height do
        retval[y] = {(' '):rep(width), ('0'):rep(width), ('f'):rep(width)}
        retval.dirtyLines[y] = true
    end
    for i = 0, 15 do
        retval.palette[i] = {_G.term.nativePaletteColor(2^i)}
        retval.dirtyPalette[i] = true
    end
    return retval
end

do
    local term_width, term_height = term.getSize()
    --- Stores all virtual TTYs for the main screen.
    TTY = {
        terminal.makeTTY(term, term_width, term_height),
        terminal.makeTTY(term, term_width, term_height),
        terminal.makeTTY(term, term_width, term_height),
        terminal.makeTTY(term, term_width, term_height),
        terminal.makeTTY(term, term_width, term_height),
        terminal.makeTTY(term, term_width, term_height),
        terminal.makeTTY(term, term_width, term_height),
        terminal.makeTTY(term, term_width, term_height)
    }
end
--- Stores the TTY that is currently shown on screen.
currentTTY = TTY[1]
--- Stores all TTYs that have been created in user mode.
terminal.userTTYs = {}

do
    local n = args.console:match "^tty(%d+)$"
    if n then KERNEL.stdout, KERNEL.stderr, KERNEL.stdin = TTY[tonumber(n)], TTY[tonumber(n)], TTY[tonumber(n)] end
end

--- Stores what modifier keys are currently being held.
keysHeld = {ctrl = false, alt = false, shift = false}

eventHooks.term_resize = eventHooks.term_resize or {}
eventHooks.char = eventHooks.char or {}
eventHooks.key = eventHooks.key or {}
eventHooks.key_up = eventHooks.key_up or {}
eventHooks.term_resize[#eventHooks.term_resize+1] = function()
    local w, h = term.getSize()
    for i = 1, 8 do terminal.resize(TTY[i], w, h) end
end
eventHooks.char[#eventHooks.char+1] = function(ev)
    if not currentTTY.isLocked then
        if currentTTY.flags.cbreak then currentTTY.buffer = currentTTY.buffer .. ev[2]
        else currentTTY.preBuffer = currentTTY.preBuffer .. ev[2] end
        if currentTTY.flags.echo then terminal.write(currentTTY, ev[2]) terminal.redraw(currentTTY) end
    end
end
eventHooks.key[#eventHooks.key+1] = function(ev)
    if not currentTTY.isLocked then
        if ev[2] == keys.enter then
            if currentTTY.flags.cbreak then
                currentTTY.buffer = currentTTY.buffer .. "\n"
            else
                currentTTY.buffer = currentTTY.buffer .. currentTTY.preBuffer .. "\n"
                currentTTY.preBuffer = ""
            end
            if currentTTY.flags.echo then terminal.write(currentTTY, "\n") terminal.redraw(currentTTY) end
        elseif ev[2] == keys.backspace then
            if currentTTY.flags.cbreak then
                -- TODO: uh, what is this supposed to be?
            elseif #currentTTY.preBuffer > 0 then
                currentTTY.preBuffer = currentTTY.preBuffer:sub(1, -2)
                if currentTTY.flags.echo then terminal.write(currentTTY, "\b \b") terminal.redraw(currentTTY) end
            end
        end
    end
    if ev[2] == keys.leftCtrl or ev[2] == keys.rightCtrl then keysHeld.ctrl = true
    elseif ev[2] == keys.leftAlt or ev[2] == keys.rightAlt then keysHeld.alt = true
    elseif ev[2] == keys.leftShift or ev[2] == keys.rightShift then keysHeld.shift = true end
    if not currentTTY.flags.raw and currentTTY.frontmostProcess and keysHeld.ctrl and not keysHeld.alt and not keysHeld.shift then
        if ev[2] == keys.c then syscalls.kill(KERNEL, nil, currentTTY.frontmostProcess.id, 2) terminal.write(currentTTY, "^C")
        elseif ev[2] == keys.backslash then syscalls.kill(KERNEL, nil, currentTTY.frontmostProcess.id, 3) terminal.write(currentTTY, "^\\")
        elseif ev[2] == keys.z then syscalls.kill(KERNEL, nil, currentTTY.frontmostProcess.id, 19) terminal.write(currentTTY, "^Z")
        elseif ev[2] == keys.d then currentTTY.eof = true terminal.write(currentTTY, "^D")
        -- TODO: fill in other cool keys
        end
    end
    if keysHeld.ctrl and keysHeld.alt and not keysHeld.shift then
        local changed = true
        if ev[2] == keys.one then currentTTY = TTY[1]
        elseif ev[2] == keys.two then currentTTY = TTY[2]
        elseif ev[2] == keys.three then currentTTY = TTY[3]
        elseif ev[2] == keys.four then currentTTY = TTY[4]
        elseif ev[2] == keys.five then currentTTY = TTY[5]
        elseif ev[2] == keys.six then currentTTY = TTY[6]
        elseif ev[2] == keys.seven then currentTTY = TTY[7]
        elseif ev[2] == keys.eight then currentTTY = TTY[8]
        elseif ev[2] == keys.left then for i = 1, 8 do if currentTTY == TTY[i] then currentTTY = TTY[(i+7)%8] break end end
        elseif ev[2] == keys.right then for i = 1, 8 do if currentTTY == TTY[i] then currentTTY = TTY[(i+1)%8] break end end
        else changed = false end
        if changed then terminal.redraw(currentTTY, true) end
    end
end
eventHooks.key_up[#eventHooks.key_up+1] = function(ev)
    if ev[2] == keys.leftCtrl or ev[2] == keys.rightCtrl then keysHeld.ctrl = false
    elseif ev[2] == keys.leftAlt or ev[2] == keys.rightAlt then keysHeld.alt = false
    elseif ev[2] == keys.leftShift or ev[2] == keys.rightShift then keysHeld.shift = false end
end

--- Redraws the specified TTY if on-screen.
-- @tparam TTY tty The TTY to redraw
-- @tparam boolean full Whether to draw the full screen, or just the changed regions
function terminal.redraw(tty, full)
    if tty.process then tty.process.eventQueue[#tty.process.eventQueue+1] = {"tty_redraw", {id = tty.id}} return
    elseif currentTTY ~= tty and not tty.isMonitor then return end
    local term = tty.term
    local buffer = tty
    if tty.isLocked then
        if tty.isGraphics then
            term.setGraphicsMode(2)
            if term.setFrozen then term.setFrozen(true) end
            if full then
                term.clear()
                term.drawPixels(0, 0, tty.graphicsBuffer)
                for i = 0, 255 do term.setPaletteColor(i, tty.graphicsBuffer.palette[i][1], tty.graphicsBuffer.palette[i][2], tty.graphicsBuffer.palette[i][3]) end
            else
                if tty.graphicsBuffer.frozen then
                    if term.setFrozen then term.setFrozen(false) end
                    return
                end
                for _, v in ipairs(tty.graphicsBuffer.dirtyRects) do
                    if v.color then term.setPixel(v.x, v.y, v.color, v.width, v.height)
                    else term.drawPixels(v.x, v.y, v) end
                end
                for i in pairs(tty.graphicsBuffer.dirtyPalette) do term.setPaletteColor(i, tty.graphicsBuffer.palette[i][1], tty.graphicsBuffer.palette[i][2],tty.graphicsBuffer.palette[i][3]) end
            end
            if term.setFrozen then term.setFrozen(false) end
            buffer.dirtyRects, buffer.dirtyPalette = {}, {}
            return
        end
        if term.setGraphicsMode then term.setGraphicsMode(false) end
        buffer = tty.textBuffer
    elseif tty.isGraphics then
        term.setGraphicsMode(false)
        tty.isGraphics = false
    end
    term.setCursorBlink(false)
    if full then
        term.clear()
        for y = 1, tty.size.height do
            term.setCursorPos(1, y)
            term.blit(buffer[y][1], buffer[y][2], buffer[y][3])
        end
        for i = 0, 15 do term.setPaletteColor(2^i, buffer.palette[i][1], buffer.palette[i][2], buffer.palette[i][3]) end
    else
        for y in pairs(buffer.dirtyLines) do
            if not buffer[y] then error(debug.traceback(y)) end
            term.setCursorPos(1, y)
            if #buffer[y][1] ~= #buffer[y][2] or #buffer[y][2] ~= #buffer[y][3] then
                syslog.log({level = "critical"}, "Bug in text writer! Inequal lengths: " .. #buffer[y][1] .. ", " .. #buffer[y][2] .. ", " .. #buffer[y][3])
                error("Invalid lengths")
            end
            term.blit(buffer[y][1], buffer[y][2], buffer[y][3])
        end
        for i in pairs(buffer.dirtyPalette) do term.setPaletteColor(2^i, buffer.palette[i][1], buffer.palette[i][2], buffer.palette[i][3]) end
    end
    term.setCursorPos(buffer.cursor.x, buffer.cursor.y)
    term.setCursorBlink(buffer.cursorBlink)
    buffer.dirtyLines, buffer.dirtyPalette = {}, {}
end

--- Resizes the TTY.
-- @tparam TTY tty The TTY to resize
-- @tparam number width The new width
-- @tparam number height The new height
function terminal.resize(tty, width, height)
    if width > tty.size.width then
        for y = 1, tty.size.height do
            tty[y][1] = tty[y][1] .. (' '):rep(width - tty.size.width)
            tty[y][2] = tty[y][2] .. tty.colors.fg:rep(width - tty.size.width)
            tty[y][3] = tty[y][3] .. tty.colors.bg:rep(width - tty.size.width)
            tty.dirtyLines[y] = true
        end
        if tty.isLocked then
            if tty.isGraphics then
                for y = 1, tty.size.height * 9 do
                    tty.graphicsBuffer[y] = tty.graphicsBuffer[y] .. ('\15'):rep((width - tty.size.width) * 6)
                end
                tty.graphicsBuffer.dirtyRects[#tty.graphicsBuffer.dirtyRects+1] = {
                    x = tty.size.width * 6 + 1, y = 1,
                    width = (width - tty.size.width) * 6, height = tty.size.height * 9
                }
            else
                for y = 1, tty.size.height do
                    tty.textBuffer[y][1] = tty.textBuffer[y][1] .. (' '):rep(width - tty.size.width)
                    tty.textBuffer[y][2] = tty.textBuffer[y][2] .. tty.textBuffer.colors.fg:rep(width - tty.size.width)
                    tty.textBuffer[y][3] = tty.textBuffer[y][3] .. tty.textBuffer.colors.bg:rep(width - tty.size.width)
                    tty.textBuffer.dirtyLines[y] = true
                end
            end
        end
    elseif width < tty.size.width then
        for y = 1, tty.size.height do
            tty[y][1] = tty[y][1]:sub(1, width)
            tty[y][2] = tty[y][2]:sub(1, width)
            tty[y][3] = tty[y][3]:sub(1, width)
            tty.dirtyLines[y] = true
        end
        if tty.isLocked then
            if tty.isGraphics then
                for y = 1, tty.size.height * 9 do
                    tty.graphicsBuffer[y] = tty.graphicsBuffer[y]:sub(1, width * 6)
                end
            else
                for y = 1, tty.size.height do
                    tty.textBuffer[y][1] = tty.textBuffer[y][1]:sub(1, width)
                    tty.textBuffer[y][2] = tty.textBuffer[y][2]:sub(1, width)
                    tty.textBuffer[y][3] = tty.textBuffer[y][3]:sub(1, width)
                end
            end
        end
    end
    tty.size.width = width

    if height > tty.size.height then
        for y = tty.size.height + 1, height do
            tty[y] = {(' '):rep(width), tty.colors.fg:rep(width), tty.colors.bg:rep(width)}
            tty.dirtyLines[y] = true
        end
        if tty.isLocked then
            if tty.isGraphics then
                for y = tty.size.height * 9 + 1, height * 9 do
                    tty.graphicsBuffer[y] = ('\15'):rep(width * 6)
                end
                tty.graphicsBuffer.dirtyRects[#tty.graphicsBuffer.dirtyRects+1] = {
                    x = 1, y = tty.size.height * 9 + 1,
                    width = tty.size.width * 6, height = (height - tty.size.height) * 9
                }
            else
                for y = tty.size.height + 1, height do
                    tty.textBuffer[y] = {(' '):rep(width), tty.textBuffer.colors.fg:rep(width), tty.textBuffer.colors.bg:rep(width)}
                    tty.textBuffer.dirtyLines[y] = true
                end
            end
        end
    elseif height < tty.size.height then
        for y = height + 1, tty.size.height do
            tty[y] = nil
        end
        if tty.isLocked then
            if tty.isGraphics then
                for y = height * 9 + 1, tty.size.height * 9 do
                    tty.graphicsBuffer[y] = nil
                end
            else
                for y = height + 1, tty.size.height do
                    tty.textBuffer[y] = nil
                end
            end
        end
    end
    tty.size.height = height
end

local function nextline(tty)
    tty.cursor.y = tty.cursor.y + 1
    if tty.cursor.y > tty.size.height then
        --table.remove(tty, 1)
        for i = 1, tty.size.height - 1 do
            tty[i] = tty[i+1]
            tty.dirtyLines[i] = true
        end
        tty[tty.size.height] = {(' '):rep(tty.size.width), tty.colors.fg:rep(tty.size.width), tty.colors.bg:rep(tty.size.width)}
        tty.dirtyLines[tty.size.height] = true
        tty.cursor.y = tty.size.height
    end
end

-- TODO: We could probably optimize a lot of the table indexes here to speed things up.
--       This will become important as things start needing to write quickly.
--       The biggest improvement will likely come from caching `tty.cursor.<x|y>`.

local CSI = {
    ['@'] = function(tty, params) end, -- ICH
    A = function(tty, params)
        local p = params[1] or 1
        if p == 0 then p = 1 end
        tty.cursor.y = math.max(tty.cursor.y - p, 1)
    end, -- CUU
    B = function(tty, params)
        local p = params[1] or 1
        if p == 0 then p = 1 end
        tty.cursor.y = math.min(tty.cursor.y + p, tty.size.height)
    end, -- CUD
    C = function(tty, params)
        local p = params[1] or 1
        if p == 0 then p = 1 end
        tty.cursor.x = math.min(tty.cursor.x + p, tty.size.width)
    end, -- CUF
    D = function(tty, params)
        local p = params[1] or 1
        if p == 0 then p = 1 end
        tty.cursor.x = math.max(tty.cursor.x - p, 1)
    end, -- CUB
    E = function(tty, params)
        local p = params[1] or 1
        if p == 0 then p = 1 end
        tty.cursor.y = math.min(tty.cursor.y + p, tty.size.height)
        tty.cursor.x = 1
    end, -- CNL
    F = function(tty, params)
        local p = params[1] or 1
        if p == 0 then p = 1 end
        tty.cursor.y = math.max(tty.cursor.y - p, 1)
        tty.cursor.x = 1
    end, -- CPL
    G = function(tty, params)
        local p = params[1] or 1
        if p == 0 then p = 1 end
        tty.cursor.x = math.min(p, tty.size.width)
    end, -- CHA
    H = function(tty, params)
        local r, c = params[1] or 1, params[2] or 1
        if r == 0 then r = 1 end
        if c == 0 then c = 1 end
        tty.cursor.x, tty.cursor.y = math.min(c, tty.size.width), math.min(r, tty.size.height)
    end, -- CUP
    I = function(tty, params) end, -- CHT
    J = function(tty, params)
        local n = params[1] or 0
        if n == 0 then
            tty[tty.cursor.y][1] = tty[tty.cursor.y][1]:sub(1, tty.cursor.x - 1) .. (" "):rep(tty.size.width - tty.cursor.x)
            tty[tty.cursor.y][2] = tty[tty.cursor.y][2]:sub(1, tty.cursor.x - 1) .. tty.colors.fg:rep(tty.size.width - tty.cursor.x)
            tty[tty.cursor.y][3] = tty[tty.cursor.y][3]:sub(1, tty.cursor.x - 1) .. tty.colors.bg:rep(tty.size.width - tty.cursor.x)
            tty.dirtyLines[tty.cursor.y] = true
            for y = tty.cursor.y + 1, tty.size.height do
                tty[y][1] = (" "):rep(tty.size.width)
                tty[y][2] = tty.colors.fg:rep(tty.size.width)
                tty[y][3] = tty.colors.bg:rep(tty.size.width)
                tty.dirtyLines[y] = true
            end
        elseif n == 1 then
            tty[tty.cursor.y][1] = (" "):rep(tty.cursor.x) .. tty[tty.cursor.y][1]:sub(tty.cursor.x)
            tty[tty.cursor.y][2] = tty.colors.fg:rep(tty.cursor.x) .. tty[tty.cursor.y][2]:sub(tty.cursor.x)
            tty[tty.cursor.y][3] = tty.colors.bg:rep(tty.cursor.x) .. tty[tty.cursor.y][3]:sub(tty.cursor.x)
            tty.dirtyLines[tty.cursor.y] = true
            for y = tty.cursor.y - 1, 1, -1 do
                tty[y][1] = (" "):rep(tty.size.width)
                tty[y][2] = tty.colors.fg:rep(tty.size.width)
                tty[y][3] = tty.colors.bg:rep(tty.size.width)
                tty.dirtyLines[y] = true
            end
        elseif n == 2 then
            for y = 1, tty.size.height do
                tty[y][1] = (" "):rep(tty.size.width)
                tty[y][2] = tty.colors.fg:rep(tty.size.width)
                tty[y][3] = tty.colors.bg:rep(tty.size.width)
                tty.dirtyLines[y] = true
            end
        -- NOTE: if we ever want scroll support in the console, add n == 3 to clear the scrollback buffer
        --       this will probably never happen, but who knows?
        end
    end, -- ED
    K = function(tty, params)
        local n = params[1] or 0
        if n == 0 then
            tty[tty.cursor.y][1] = tty[tty.cursor.y][1]:sub(1, tty.cursor.x - 1) .. (" "):rep(tty.size.width - tty.cursor.x)
            tty[tty.cursor.y][2] = tty[tty.cursor.y][2]:sub(1, tty.cursor.x - 1) .. tty.colors.fg:rep(tty.size.width - tty.cursor.x)
            tty[tty.cursor.y][3] = tty[tty.cursor.y][3]:sub(1, tty.cursor.x - 1) .. tty.colors.bg:rep(tty.size.width - tty.cursor.x)
            tty.dirtyLines[tty.cursor.y] = true
        elseif n == 1 then
            tty[tty.cursor.y][1] = (" "):rep(tty.cursor.x) .. tty[tty.cursor.y][1]:sub(tty.cursor.x)
            tty[tty.cursor.y][2] = tty.colors.fg:rep(tty.cursor.x) .. tty[tty.cursor.y][2]:sub(tty.cursor.x)
            tty[tty.cursor.y][3] = tty.colors.bg:rep(tty.cursor.x) .. tty[tty.cursor.y][3]:sub(tty.cursor.x)
            tty.dirtyLines[tty.cursor.y] = true
        elseif n == 2 then
            tty[tty.cursor.y][1] = (" "):rep(tty.size.width)
            tty[tty.cursor.y][2] = tty.colors.fg:rep(tty.size.width)
            tty[tty.cursor.y][3] = tty.colors.bg:rep(tty.size.width)
            tty.dirtyLines[tty.cursor.y] = true
        end
    end, -- EL
    L = function(tty, params) end, -- IL
    M = function(tty, params) end, -- DL
    N = function(tty, params) end, -- EF
    O = function(tty, params) end, -- EA
    P = function(tty, params) end, -- DCH
    Q = function(tty, params) end, -- SSE
    R = function(tty, params) end, -- CPR
    S = function(tty, params)
        local n = params[1] or 0
        if n == 0 then n = 1 end
        -- TODO: possibly optimize this?
        for _ = 1, n do
            table.insert(tty, 1, {(' '):rep(tty.size.width), tty.colors.fg:rep(tty.size.width), tty.colors.bg:rep(tty.size.width)})
            tty[tty.size.height + 1] = nil
        end
    end, -- SU
    T = function(tty, params)
        local n = params[1] or 0
        if n == 0 then n = 1 end
        -- TODO: possibly optimize this?
        for _ = 1, n do
            table.remove(tty, 1)
            tty[tty.size.height] = {(' '):rep(tty.size.width), tty.colors.fg:rep(tty.size.width), tty.colors.bg:rep(tty.size.width)}
        end
    end, -- SD
    U = function(tty, params) end, -- NP
    V = function(tty, params) end, -- PP
    W = function(tty, params) end, -- CTC
    X = function(tty, params) end, -- ECH
    Y = function(tty, params) end, -- CVT
    Z = function(tty, params) end, -- CBT
    ['['] = function(tty, params) end, -- SRS
    ['\\'] = function(tty, params) end, -- PTX
    [']'] = function(tty, params) end, -- SDS
    ['^'] = function(tty, params) end, -- SIMD
    ['_'] = function(tty, params) end, -- N/A
    ['`'] = function(tty, params) end, -- HPA
    a = function(tty, params) end, -- HPR
    b = function(tty, params) end, -- REP
    c = function(tty, params) end, -- DA
    d = function(tty, params) end, -- VPA
    e = function(tty, params) end, -- VPR
    f = function(tty, params) end, -- HVP
    g = function(tty, params) end, -- TBC
    h = function(tty, params)
        if params[1] == 25 then tty.cursorBlink = true end
    end, -- SM
    i = function(tty, params) end, -- MC
    j = function(tty, params) end, -- HPB
    k = function(tty, params) end, -- VPB
    l = function(tty, params)
        if params[1] == 25 then tty.cursorBlink = false end
    end, -- RM
    m = function(tty, params)
        local n, m = params[1] or 0, params[2]

        if n == 0 then tty.colors.fg, tty.colors.bg = '0', 'f'
        elseif n == 1 then tty.colors.bold = true
        elseif n == 7 or n == 27 then tty.colors.fg, tty.colors.bg = tty.colors.bg, tty.colors.fg
        elseif n == 22 then tty.colors.bold = false
        elseif n >= 30 and n <= 37 then tty.colors.fg = ("%x"):format(15 - (n - 30) - (tty.colors.bold and 8 or 0))
        elseif n == 39 then tty.colors.fg = '0'
        elseif n >= 40 and n <= 47 then tty.colors.bg = ("%x"):format(15 - (n - 40) - (tty.colors.bold and 8 or 0))
        elseif n == 49 then tty.colors.bg = 'f'
        elseif n >= 90 and n <= 97 then tty.colors.fg = ("%x"):format(15 - (n - 90) - 8)
        elseif n >= 100 and n <= 107 then tty.colors.bg = ("%x"):format(15 - (n - 100) - 8) end
        if m ~= nil then
            if m == 0 then tty.colors.fg, tty.colors.bg = '0', 'f'
            elseif m == 1 then tty.colors.bold = true
            elseif m == 7 or m == 27 then tty.colors.fg, tty.colors.bg = tty.colors.bg, tty.colors.fg
            elseif m == 22 then tty.colors.bold = false
            elseif m >= 30 and m <= 37 then tty.colors.fg = ("%x"):format(15 - (m - 30) - (tty.colors.bold and 8 or 0))
            elseif m == 39 then tty.colors.fg = '0'
            elseif m >= 40 and m <= 47 then tty.colors.bg = ("%x"):format(15 - (m - 40) - (tty.colors.bold and 8 or 0))
            elseif m == 49 then tty.colors.bg = 'f'
            elseif m >= 90 and m <= 97 then tty.colors.fg = ("%x"):format(15 - (m - 90) - 8)
            elseif m >= 100 and m <= 107 then tty.colors.bg = ("%x"):format(15 - (m - 100) - 8) end
        end
    end, -- SGR
    n = function(tty, params)
        -- TODO: send the cursor position to stdin
    end, -- DSR
    o = function(tty, params) end, -- DAQ
}
for i = 0x70, 0x7F do CSI[string.char(i)] = function(tty, params) end end

--- Writes some text to a TTY's text buffer, allowing ANSI escapes.
-- @tparam TTY tty The TTY to write to
-- @tparam string text The text to write
function terminal.write(tty, text)
    local start, size = 1, 0
    local function commit(x)
        if size == 0 then
            start, size = x, 0
            return
        end
        while tty.cursor.x + size > tty.size.width do
            tty[tty.cursor.y][1] = tty[tty.cursor.y][1]:sub(1, tty.cursor.x - 1) .. text:sub(start, start + tty.size.width - tty.cursor.x)
            tty[tty.cursor.y][2] = tty[tty.cursor.y][2]:sub(1, tty.cursor.x - 1) .. tty.colors.fg:rep(tty.size.width - tty.cursor.x + 1)
            tty[tty.cursor.y][3] = tty[tty.cursor.y][3]:sub(1, tty.cursor.x - 1) .. tty.colors.bg:rep(tty.size.width - tty.cursor.x + 1)
            tty.dirtyLines[tty.cursor.y] = true
            start = start + tty.size.width - tty.cursor.x + 1
            size = size - (tty.size.width - tty.cursor.x + 1)
            tty.cursor.x = 1
            nextline(tty)
        end
        tty[tty.cursor.y][1] = tty[tty.cursor.y][1]:sub(1, tty.cursor.x - 1) .. text:sub(start, start + size - 1) .. tty[tty.cursor.y][1]:sub(tty.cursor.x + size)
        tty[tty.cursor.y][2] = tty[tty.cursor.y][2]:sub(1, tty.cursor.x - 1) .. tty.colors.fg:rep(size) .. tty[tty.cursor.y][2]:sub(tty.cursor.x + size)
        tty[tty.cursor.y][3] = tty[tty.cursor.y][3]:sub(1, tty.cursor.x - 1) .. tty.colors.bg:rep(size) .. tty[tty.cursor.y][3]:sub(tty.cursor.x + size)
        tty.dirtyLines[tty.cursor.y] = true
        tty.cursor.x = tty.cursor.x + size
        start, size = x, 0
    end
    local state = 0
    local params, nextParam
    for x, c, n in text:gmatch "()(.)()" do
        if state == 0 then
            if c == '\a' then
                commit(n)
                -- TODO: make a sound or something
            elseif c == '\b' then
                commit(n)
                if tty.cursor.x == 1 then
                    if tty.cursor.y > 1 then tty.cursor.x, tty.cursor.y = tty.size.width, tty.cursor.y - 1 end
                else tty.cursor.x = tty.cursor.x - 1 end
            elseif c == '\t' then
                commit(n)
                tty.cursor.x = math.floor(tty.cursor.x / 8) * 8 + 8
                if tty.cursor.x > tty.size.width then
                    tty.cursor.x = 1
                    nextline(tty)
                end
            elseif c == '\n' then
                commit(n)
                nextline(tty)
                if tty.flags.nlcr then tty.cursor.x = 1 end
            elseif c == '\f' then
                commit(n)
                nextline(tty)
            elseif c == '\r' then
                commit(n)
                tty.cursor.x = 1
            elseif c == '\27' then
                state = 1
            else
                size = size + 1
            end
        elseif state == 1 then
            -- TODO: Implement whatever of these are applicable
            if false then
            --[[ elseif c == 'B' then -- BPH
            elseif c == 'C' then -- NBH
            elseif c == 'E' then -- NEL
            elseif c == 'F' then -- SSA
            elseif c == 'G' then -- ESA
            elseif c == 'H' then -- HTS
            elseif c == 'I' then -- HTJ
            elseif c == 'J' then -- VTS
            elseif c == 'K' then -- PLD
            elseif c == 'L' then -- PLU
            elseif c == 'M' then -- RI
            elseif c == 'N' then -- SS2
            elseif c == 'O' then -- SS3
            elseif c == 'P' then -- DCS
            elseif c == 'Q' then -- PU1
            elseif c == 'R' then -- PU2
            elseif c == 'S' then -- STS
            elseif c == 'T' then -- CCH
            elseif c == 'U' then -- MW
            elseif c == 'V' then -- SPA
            elseif c == 'W' then -- EPA
            elseif c == 'X' then -- SOS
            elseif c == 'Z' then -- SCI ]]
            elseif c == '[' then -- CSI
                state = 2
                params, nextParam = {}, 0
            --[[ elseif c == '\\' then -- ST ]]
            elseif c == ']' then -- OSC
                if text:byte(n) == 0x50 then
                    state = 4
                    params = {}
                else
                    state = 3
                    params, nextParam = {}, 0
                end
            --[[ elseif c == '^' then -- PM
            elseif c == '_' then -- APC ]]
            else
                commit(n)
                state = 0
            end
        elseif state == 2 then
            if c >= '@' and c <= '\127' then
                commit(n)
                params[#params+1] = nextParam
                CSI[c](tty, params)
                state = 0
            elseif c >= '0' and c <= '?' then
                if c <= '9' then
                    nextParam = nextParam * 10 + tonumber(c)
                elseif c == ';' then
                    params[#params+1], nextParam = nextParam, 0
                end
            else
                commit(n)
                state = 0
            end
        elseif state == 3 then
            -- TODO: properly handle this
            if c == '\\' and text:byte(x - 1) == '\27' then
                commit(n)
                state = 0
            end
        elseif state == 4 then
            if #params == 0 then
                params[1] = tonumber(c, 16) or 0
            elseif #params == 1 and not nextParam then
                nextParam = (tonumber(c, 16) or 0) * 16
            elseif #params == 1 then
                params[2], nextParam = nextParam + (tonumber(c, 16) or 0), nil
            elseif #params == 2 and not nextParam then
                nextParam = (tonumber(c, 16) or 0) * 16
            elseif #params == 2 then
                params[3], nextParam = nextParam + (tonumber(c, 16) or 0), nil
            elseif #params == 3 and not nextParam then
                nextParam = (tonumber(c, 16) or 0) * 16
            elseif #params == 3 then
                commit(n)
                params[4], nextParam = nextParam + (tonumber(c, 16) or 0), nil
                tty.palette[params[1]] = {params[2] / 255, params[3] / 255, params[4] / 255}
                tty.dirtyPalette[params[1]] = true
                state = 0
            end
        end
    end
    commit()
end

function syscalls.write(process, thread, ...)
    if not process.stdout then return end
    --[[if process.stdout.isTTY and process ~= process.stdout.frontmostProcess then
        syscalls.kill(KERNEL, nil, process.id, 22)
        if process.paused then return kSyscallYield, "write" end
    end]]
    local function write(t)
        if process.stdout.isTTY then terminal.write(process.stdout, t)
        else process.stdout.write(t) end
    end
    for i, v in ipairs{...} do
        if i > 1 then write("\t") end
        write(tostring(v))
    end
    if process.stdout.isTTY then terminal.redraw(process.stdout) end
end

function syscalls.writeerr(process, thread, ...)
    if not process.stderr then return end
    --[[if process.stderr.isTTY and process ~= process.stderr.frontmostProcess then
        syscalls.kill(KERNEL, nil, process.id, 22)
        if process.paused then return kSyscallYield, "writeerr" end
    end]]
    local function write(t)
        if process.stderr.isTTY then terminal.write(process.stderr, t)
        else process.stderr.write(t) end
    end
    for i, v in ipairs{...} do
        if i > 1 then write("\t") end
        write(tostring(v))
    end
    if process.stderr.isTTY then terminal.redraw(process.stderr) end
end

function syscalls.read(process, thread, n)
    expect(1, n, "number")
    if process.stdin then
        --[[if process.stdin.isTTY and process ~= process.stdin.frontmostProcess then
            syscalls.kill(KERNEL, nil, process.id, 21)
            if process.paused then return kSyscallYield, "readline" end
        end]]
        if process.stdin.eof then
            process.stdin.eof = false
            return nil
        end
        while #process.stdin.buffer < n do
            if process.stdin.eof then
                process.stdin.eof = false
                return nil
            end
            if process.stdin.isTTY and not process.stdin.flags.delay then return nil end
            if process.stdin.read then
                local s = process.stdin.read(n - #process.stdin.buffer)
                if not s then return nil end
                process.stdin.buffer = process.stdin.buffer .. s
            else return kSyscallYield, "read", n end
        end
        local s = process.stdin.buffer:sub(1, n - 1)
        process.stdin.buffer = process.stdin.buffer:sub(n)
        return s
    else return nil end
end

function syscalls.readline(process, thread)
    if process.stdin then
        --[[if process.stdin.isTTY and process ~= process.stdin.frontmostProcess then
            syscalls.kill(KERNEL, nil, process.id, 21)
            if process.paused then return kSyscallYield, "readline" end
        end]]
        if process.stdin.eof then
            process.stdin.eof = false
            return nil
        end
        while not process.stdin.buffer:find("\n") do
            if process.stdin.eof then
                process.stdin.eof = false
                return nil
            end
            if process.stdin.isTTY and not process.stdin.flags.delay then return nil end
            if process.stdin.read then
                local s = process.stdin.read()
                if not s then return nil end
                process.stdin.buffer = process.stdin.buffer .. s
            else return kSyscallYield, "readline" end
        end
        local n = process.stdin.buffer:find("\n")
        local s = process.stdin.buffer:sub(1, n - 1)
        process.stdin.buffer = process.stdin.buffer:sub(n + 1)
        return s
    else return nil end
end

function syscalls.termctl(process, thread, flags)
    expect(1, flags, "table", "nil")
    if not process.stdout or not process.stdout.isTTY then return nil end
    if process ~= process.stdout.frontmostProcess then
        syscalls.kill(KERNEL, nil, process.id, 22)
        if process.paused then return kSyscallYield, "termctl", flags end
    end
    if flags then
        expect.field(flags, "cbreak", "boolean", "nil")
        expect.field(flags, "delay", "boolean", "nil")
        expect.field(flags, "echo", "boolean", "nil")
        expect.field(flags, "keypad", "boolean", "nil")
        expect.field(flags, "nlcr", "boolean", "nil")
        expect.field(flags, "raw", "boolean", "nil")
        for k, v in pairs(flags) do if process.stdout.flags[k] ~= nil then process.stdout.flags[k] = v end end
    end
    local t = deepcopy(process.stdout.flags)
    t.hasgfx = term.getGraphicsMode ~= nil
    return t
end

function terminal.openterm(tty, process)
    if tty.isLocked then return nil, "Terminal already in use" end
    local size = tty.size
    local buffer = {
        cursor = {x = 1, y = 1},
        cursorBlink = false,
        colors = {fg = '0', bg = 'f'},
        palette = {},
        dirtyLines = {},
        dirtyPalette = {},
    }
    tty.textBuffer = buffer
    tty.isLocked = true
    tty.isGraphics = false
    for y = 1, size.height do
        buffer[y] = {(' '):rep(size.width), ('0'):rep(size.width), ('f'):rep(size.width)}
        buffer.dirtyLines[y] = true
    end
    for i = 0, 15 do
        buffer.palette[i] = {term.nativePaletteColor(2^i)}
        buffer.dirtyPalette[i] = true
    end

    tty.processList[#tty.processList+1] = tty.frontmostProcess
    tty.frontmostProcess = process

    local win = setmetatable({}, {__name = "Terminal"})
    local redraw = terminal.redraw
    local expect = expect

    function win.close()
        if not win then error("terminal is already closed", 2) end
        win = nil
        tty.isLocked = false
        tty.frontmostProcess = table.remove(tty.processList)
        redraw(tty, true)
    end

    function win.write(text)
        if not win then error("terminal is already closed", 2) end
        text = tostring(text)
        expect(1, text, "string")
        if buffer.cursor.y < 1 or buffer.cursor.y > size.height then return
        elseif buffer.cursor.x > size.width or buffer.cursor.x + #text < 1 then
            buffer.cursor.x = buffer.cursor.x + #text
            return
        elseif buffer.cursor.x < 1 then
            text = text:sub(-buffer.cursor.x + 2)
            buffer.cursor.x = 1
        end
        local ntext = #text
        if buffer.cursor.x + #text > size.width then text = text:sub(1, size.width - buffer.cursor.x + 1) end
        buffer[buffer.cursor.y][1] = buffer[buffer.cursor.y][1]:sub(1, buffer.cursor.x - 1) .. text .. buffer[buffer.cursor.y][1]:sub(buffer.cursor.x + #text)
        buffer[buffer.cursor.y][2] = buffer[buffer.cursor.y][2]:sub(1, buffer.cursor.x - 1) .. buffer.colors.fg:rep(#text) .. buffer[buffer.cursor.y][2]:sub(buffer.cursor.x + #text)
        buffer[buffer.cursor.y][3] = buffer[buffer.cursor.y][3]:sub(1, buffer.cursor.x - 1) .. buffer.colors.bg:rep(#text) .. buffer[buffer.cursor.y][3]:sub(buffer.cursor.x + #text)
        buffer.cursor.x = buffer.cursor.x + ntext
        buffer.dirtyLines[buffer.cursor.y] = true
        --redraw(tty)
    end

    function win.blit(text, fg, bg)
        if not win then error("terminal is already closed", 2) end
        text = tostring(text)
        expect(1, text, "string")
        expect(2, fg, "string")
        expect(3, bg, "string")
        if #text ~= #fg or #fg ~= #bg then error("Arguments must be the same length", 2) end
        if buffer.cursor.y < 1 or buffer.cursor.y > size.height then return
        elseif buffer.cursor.x > size.width or buffer.cursor.x < 1 - #text then
            buffer.cursor.x = buffer.cursor.x + #text
            redraw(tty)
            return
        elseif buffer.cursor.x < 1 then
            text, fg, bg = text:sub(-buffer.cursor.x + 2), fg:sub(-buffer.cursor.x + 2), bg:sub(-buffer.cursor.x + 2)
            buffer.cursor.x = 1
        end
        local ntext = #text
        if buffer.cursor.x + #text > size.width then text, fg, bg = text:sub(1, size.width - buffer.cursor.x + 1), fg:sub(1, size.width - buffer.cursor.x + 1), bg:sub(1, size.width - buffer.cursor.x + 1) end
        buffer[buffer.cursor.y][1] = buffer[buffer.cursor.y][1]:sub(1, buffer.cursor.x - 1) .. text .. buffer[buffer.cursor.y][1]:sub(buffer.cursor.x + #text)
        buffer[buffer.cursor.y][2] = buffer[buffer.cursor.y][2]:sub(1, buffer.cursor.x - 1) .. fg .. buffer[buffer.cursor.y][2]:sub(buffer.cursor.x + #fg)
        buffer[buffer.cursor.y][3] = buffer[buffer.cursor.y][3]:sub(1, buffer.cursor.x - 1) .. bg .. buffer[buffer.cursor.y][3]:sub(buffer.cursor.x + #bg)
        buffer.cursor.x = buffer.cursor.x + ntext
        buffer.dirtyLines[buffer.cursor.y] = true
        --redraw(tty)
    end

    function win.clear()
        if not win then error("terminal is already closed", 2) end
        for y = 1, size.height do
            buffer[y] = {(' '):rep(size.width), buffer.colors.fg:rep(size.width), buffer.colors.bg:rep(size.width)}
            buffer.dirtyLines[y] = true
        end
        --redraw(tty)
    end

    function win.clearLine()
        if not win then error("terminal is already closed", 2) end
        if buffer.cursor.y >= 1 and buffer.cursor.y <= size.height then
            buffer[buffer.cursor.y] = {(' '):rep(size.width), buffer.colors.fg:rep(size.width), buffer.colors.bg:rep(size.width)}
            buffer.dirtyLines[buffer.cursor.y] = true
            --redraw(tty)
        end
    end

    function win.getCursorPos()
        if not win then error("terminal is already closed", 2) end
        return buffer.cursor.x, buffer.cursor.y
    end

    function win.setCursorPos(cx, cy)
        if not win then error("terminal is already closed", 2) end
        expect(1, cx, "number")
        expect(2, cy, "number")
        if cx == buffer.cursor.x and cy == buffer.cursor.y then return end
        buffer.cursor.x, buffer.cursor.y = math.floor(cx), math.floor(cy)
        --redraw(tty)
    end

    function win.getCursorBlink()
        if not win then error("terminal is already closed", 2) end
        return buffer.cursorBlink
    end

    function win.setCursorBlink(b)
        if not win then error("terminal is already closed", 2) end
        expect(1, b, "boolean")
        buffer.cursorBlink = b
        --redraw(tty)
    end

    function win.isColor()
        if not win then error("terminal is already closed", 2) end
        return true
    end

    function win.getSize()
        if not win then error("terminal is already closed", 2) end
        return size.width, size.height
    end

    function win.scroll(lines)
        if not win then error("terminal is already closed", 2) end
        expect(1, lines, "number")
        if math.abs(lines) >= size.width then
            for y = 1, size.height do buffer[y] = {(' '):rep(size.width), buffer.colors.fg:rep(size.width), buffer.colors.bg:rep(size.width)} end
        elseif lines > 0 then
            for i = lines + 1, size.height do buffer[i - lines] = buffer[i] end
            for i = size.height - lines + 1, size.height do buffer[i] = {(' '):rep(size.width), buffer.colors.fg:rep(size.width), buffer.colors.bg:rep(size.width)} end
        elseif lines < 0 then
            for i = 1, size.height + lines do buffer[i - lines] = buffer[i] end
            for i = 1, -lines do buffer[i] = {(' '):rep(size.width), buffer.colors.fg:rep(size.width), buffer.colors.bg:rep(size.width)} end
        else return end
        for i = 1, size.height do buffer.dirtyLines[i] = true end
        --redraw(tty)
    end

    function win.getTextColor()
        if not win then error("terminal is already closed", 2) end
        return tonumber(buffer.colors.fg)
    end

    function win.setTextColor(color)
        if not win then error("terminal is already closed", 2) end
        expect(1, color, "number")
        expect.range(color, 0, 15)
        buffer.colors.fg = ("%x"):format(color)
    end

    function win.getBackgroundColor()
        if not win then error("terminal is already closed", 2) end
        return tonumber(buffer.colors.bg)
    end

    function win.setBackgroundColor(color)
        if not win then error("terminal is already closed", 2) end
        expect(1, color, "number")
        expect.range(color, 0, 15)
        buffer.colors.bg = ("%x"):format(color)
    end

    function win.getPaletteColor(color)
        if not win then error("terminal is already closed", 2) end
        expect(1, color, "number")
        expect.range(color, 0, 15)
        return table.unpack(buffer.palette[math.floor(color)])
    end

    function win.setPaletteColor(color, r, g, b)
        if not win then error("terminal is already closed", 2) end
        expect(1, color, "number")
        expect(2, r, "number")
        if g == nil and b == nil then r, g, b = bit32.band(bit32.rshift(r, 16), 0xFF) / 255, bit32.band(bit32.rshift(r, 8), 0xFF) / 255, bit32.band(r, 0xFF) / 255 end
        expect(3, g, "number")
        expect(4, b, "number")
        expect.range(color, 0, 15)
        if r < 0 or r > 1 then error("bad argument #2 (value out of range)", 2) end
        if g < 0 or g > 1 then error("bad argument #3 (value out of range)", 2) end
        if b < 0 or b > 1 then error("bad argument #4 (value out of range)", 2) end
        buffer.palette[math.floor(color)] = {r, g, b}
        buffer.dirtyPalette[math.floor(color)] = true
        --redraw(tty)
    end

    function win.getLine(y)
        if not win then error("terminal is already closed", 2) end
        expect(1, y, "number")
        local l = buffer[y]
        return l and table.unpack(l, 1, 3)
    end

    for _, v in pairs(win) do setfenv(v, process.env) debug.protect(v) end
    win.isColour = win.isColor
    win.getTextColour = win.getTextColor
    win.setTextColour = win.setTextColor
    win.getBackgroundColour = win.getBackgroundColor
    win.setBackgroundColour = win.setBackgroundColor
    win.getPaletteColour = win.getPaletteColor
    win.setPaletteColour = win.setPaletteColor
    process.dependents[#process.dependents+1] = {gc = function() if win then return win.close() end end}
    redraw(tty, true)
    return win
end

function syscalls.openterm(process, thread)
    if not process.stdout or not process.stdout.isTTY then return nil, "No valid TTY attached" end
    if process ~= process.stdout.frontmostProcess then
        syscalls.kill(KERNEL, nil, process.id, 22)
        if process.paused then return kSyscallYield, "openterm" end
    end
    return terminal.openterm(process.stdout, process)
end

-- TODO: make final decision on whether graphics terminals are 0-based or 1-based

function terminal.opengfx(tty, process)
    if not term.drawPixels then return nil, "Graphics mode not supported" end
    if tty.isLocked then return nil, "Terminal already in use" end
    local size = tty.size
    local buffer = {
        palette = {},
        dirtyRects = {},
        dirtyPalette = {},
        frozen = false,
    }
    tty.graphicsBuffer = buffer
    tty.isLocked = true
    tty.isGraphics = true
    for y = 1, size.height * 9 do buffer[y] = ('\15'):rep(size.width * 6) end
    for i = 0, 15 do
        buffer.palette[i] = {term.nativePaletteColor(2^i)}
        buffer.dirtyPalette[i] = true
    end
    for i = 16, 255 do
        buffer.palette[i] = {0, 0, 0}
        buffer.dirtyPalette[i] = true
    end

    tty.processList[#tty.processList+1] = tty.frontmostProcess
    tty.frontmostProcess = process

    local win = setmetatable({}, {__name = "GFXTerminal"})
    local redraw = terminal.redraw
    local expect = expect

    function win.close()
        if not win then error("terminal is already closed", 2) end
        win = nil
        tty.isLocked = false
        tty.frontmostProcess = table.remove(tty.processList)
        redraw(tty, true)
    end

    function win.getSize()
        return size.width * 6, size.height * 9
    end

    function win.clear()
        if not win then error("terminal is already closed", 2) end
        for y = 1, size.height * 9 do buffer[y] = ('\15'):rep(size.width * 6) end
        redraw(tty, true)
    end

    function win.getPixel(x, y)
        if not win then error("terminal is already closed", 2) end
        expect(1, x, "number")
        expect(2, y, "number")
        expect.range(x, 0, size.width * 6 - 1)
        expect.range(y, 0, size.height * 9 - 1)
        x, y = math.floor(x), math.floor(y)
        return buffer[y+1]:byte(x+1)
    end

    function win.setPixel(x, y, color)
        if not win then error("terminal is already closed", 2) end
        expect(1, x, "number")
        expect(2, y, "number")
        expect(3, color, "number")
        expect.range(x, 0, size.width * 6 - 1)
        expect.range(y, 0, size.height * 9 - 1)
        expect.range(color, 0, 255)
        x, y = math.floor(x), math.floor(y)
        buffer[y+1] = buffer[y+1]:sub(1, x) .. string.char(color) .. buffer[y+1]:sub(x + 2)
        buffer.dirtyRects[#buffer.dirtyRects+1] = {x = x, y = y, color = color}
        --if not buffer.frozen then redraw(tty) end
    end

    function win.getPixels(x, y, width, height, asStr)
        if not win then error("terminal is already closed", 2) end
        expect(1, x, "number")
        expect(2, y, "number")
        expect(3, width, "number")
        expect(4, height, "number")
        expect(5, asStr, "boolean", "nil")
        expect.range(width, 0)
        expect.range(height, 0)
        x, y = math.floor(x), math.floor(y)
        local t = {}
        for py = 1, height do
            if asStr then t[py] = buffer[y+py]:sub(x + 1, x + width)
            else t[py] = {buffer[y+py]:sub(x + 1, x + width):byte(1, -1)} end
        end
        return t
    end

    function win.drawPixels(x, y, data, width, height)
        if not win then error("terminal is already closed", 2) end
        expect(1, x, "number")
        expect(2, y, "number")
        expect(3, data, "table", "number")
        local isn = type(data) == "number"
        expect(4, width, "number", not isn and "nil" or nil)
        expect(5, height, "number", not isn and "nil" or nil)
        expect.range(x, 0, size.width * 6 - 1)
        expect.range(y, 0, size.height * 9 - 1)
        if width then expect.range(width, 0) end
        if height then expect.range(height, 0) end
        if isn then expect.range(data, 0, 255) end
        if width == 0 or height == 0 then return end
        x, y = math.floor(x), math.floor(y)
        if width and x + width >= size.width * 6 then width = size.width * 6 - x end
        height = height or #data
        local rect = {x = x, y = y, width = width, height = height}
        for py = 1, height do
            if y + py > size.height * 9 then break end
            if isn then
                local s = string.char(data):rep(width)
                buffer[y+py] = buffer[y+py]:sub(1, x) .. s .. buffer[y+py]:sub(x + width + 1)
                rect[py] = s
            elseif data[py] ~= nil then
                if type(data[py]) ~= "table" and type(data[py]) ~= "string" then
                    error("bad argument #3 to 'drawPixels' (invalid row " .. py .. ")", 2)
                end
                local width = width or #data[py]
                if x + width >= size.width * 6 then width = size.width * 6 - x end
                local s
                if type(data[py]) == "string" then
                    s = data[py]
                    if #s < width then s = s .. ('\15'):rep(width - #s)
                    elseif #s > width then s = s:sub(1, width) end
                else
                    s = ""
                    for px = 1, width do s = s .. string.char(data[py][px] or buffer[y+py]:byte(x+px)) end
                end
                buffer[y+py] = buffer[y+py]:sub(1, x) .. s .. buffer[y+py]:sub(x + width + 1)
                rect[py] = s
            end
        end
        buffer.dirtyRects[#buffer.dirtyRects+1] = rect
        --if not buffer.frozen then redraw(tty) end
    end

    function win.getFrozen()
        if not win then error("terminal is already closed", 2) end
        return buffer.frozen
    end

    function win.setFrozen(f)
        if not win then error("terminal is already closed", 2) end
        expect(1, f, "boolean")
        buffer.frozen = f
        --if not buffer.frozen then redraw(tty) end
    end

    function win.getPaletteColor(color)
        if not win then error("terminal is already closed", 2) end
        expect(1, color, "number")
        expect.range(color, 0, 255)
        return table.unpack(buffer.palette[color])
    end

    function win.setPaletteColor(color, r, g, b)
        if not win then error("terminal is already closed", 2) end
        expect(1, color, "number")
        expect(2, r, "number")
        if g == nil and b == nil then r, g, b = bit32.band(bit32.rshift(r, 16), 0xFF) / 255, bit32.band(bit32.rshift(r, 8), 0xFF) / 255, bit32.band(r, 0xFF) / 255 end
        expect(3, g, "number")
        expect(4, b, "number")
        expect.range(r, 0, 1)
        expect.range(g, 0, 1)
        expect.range(b, 0, 1)
        expect.range(color, 0, 255)
        buffer.palette[color] = {r, g, b}
        buffer.dirtyPalette[color] = true
        --if not buffer.frozen then redraw(tty) end
    end

    for _, v in pairs(win) do setfenv(v, process.env) debug.protect(v) end
    win.getPaletteColour = win.getPaletteColor
    win.setPaletteColour = win.setPaletteColor
    process.dependents[#process.dependents+1] = {gc = function() if win then return win.close() end end}
    redraw(tty, true)
    return win
end

function syscalls.opengfx(process, thread)
    if not process.stdout or not process.stdout.isTTY then return nil, "No valid TTY attached" end
    if process ~= process.stdout.frontmostProcess then
        syscalls.kill(KERNEL, nil, process.id, 22)
        if process.paused then return kSyscallYield, "openterm" end
    end
    return terminal.opengfx(process.stdout, process)
end

function syscalls.mktty(process, thread, width, height)
    expect(1, width, "number")
    expect(2, height, "number")
    expect.range(width, 1)
    expect.range(height, 1)
    local tty = terminal.makeTTY(term, width, height)
    tty.id = math.random(0, 0x7FFFFFFF)
    tty.process = process
    local retval = setmetatable({}, {__index = tty, __metatable = {}})
    terminal.userTTYs[retval] = tty
    process.dependents[#process.dependents+1] = {gc = function() terminal.userTTYs[retval] = nil end}
    return retval
end

function syscalls.stdin(process, thread, handle)
    expect(1, handle, "number", "table", "string", "nil")
    if process.stdin and process.stdin.isTTY and process.stdin.frontmostProcess == process then
        process.stdin.frontmostProcess = table.remove(process.stdin.processList)
        process.stdin.preBuffer = ""
    end
    if type(handle) == "number" then process.stdin = TTY[handle]
    elseif type(handle) == "string" then
        local node = hardware.get(handle)
        if not node then error("bad argument #1 (no such device)", 2) end
        if not node.internalState.tty then error("bad argument #1 (no TTY available on device)", 2) end
        handle = node.internalState.tty
        if process.stdin.frontmostProcess ~= process then
            process.stdin.frontmostProcess = table.remove(process.stdin.processList)
            handle.processList[#handle.processList+1] = handle.frontmostProcess
            handle.frontmostProcess = process
        end
        process.stdin = handle
    elseif handle == nil then process.stdin = nil
    else
        if handle.isTTY then
            handle = terminal.userTTYs[handle]
            if not handle then error("bad argument #1 (invalid TTY)", 2) end
            if process.stdin.frontmostProcess ~= process then
                process.stdin.frontmostProcess = table.remove(process.stdin.processList)
                handle.processList[#handle.processList+1] = handle.frontmostProcess
                handle.frontmostProcess = process
                handle.preBuffer = ""
            end
        else
            expect.field(handle, "read", "function")
            local read = handle.read
            handle = {
                buffer = "",
                read = function(...)
                    local ok, res = userModeCallback(process, read, ...)
                    if ok then return res else error(res, 2) end
                end
            }
        end
        process.stdin = handle
    end
end

function syscalls.stdout(process, thread, handle)
    expect(1, handle, "number", "table", "string", "nil")
    if process.stdout and process.stdout.isTTY and process.stdout.frontmostProcess == process then
        process.stdout.frontmostProcess = table.remove(process.stdout.processList)
    end
    if type(handle) == "number" then process.stdout = TTY[handle]
    elseif type(handle) == "string" then
        local node = hardware.get(handle)
        if not node then error("bad argument #1 (no such device)", 2) end
        if not node.internalState.tty then error("bad argument #1 (no TTY available on device)", 2) end
        handle = node.internalState.tty
        if process.stdout.frontmostProcess ~= process then
            process.stdout.frontmostProcess = table.remove(process.stdout.processList)
            handle.processList[#handle.processList+1] = handle.frontmostProcess
            handle.frontmostProcess = process
        end
        process.stdout = handle
    elseif handle == nil then process.stdout = nil
    else
        if handle.isTTY then
            handle = terminal.userTTYs[handle]
            if not handle then error("bad argument #1 (invalid TTY)", 2) end
            if process.stdout.frontmostProcess ~= process then
                process.stdout.frontmostProcess = table.remove(process.stdout.processList)
                handle.processList[#handle.processList+1] = handle.frontmostProcess
                handle.frontmostProcess = process
            end
        else
            expect.field(handle, "write", "function")
            local write = handle.write
            handle = {
                write = function(...)
                    local ok, res = userModeCallback(process, write, ...)
                    if ok then return res else error(res, 2) end
                end
            }
        end
        process.stdout = handle
    end
end

function syscalls.stderr(process, thread, handle)
    expect(1, handle, "number", "table", "string", "nil")
    if process.stderr and process.stderr.isTTY and process.stderr.frontmostProcess == process then
        process.stderr.frontmostProcess = table.remove(process.stderr.processList)
    end
    if type(handle) == "number" then process.stderr = TTY[handle]
    elseif type(handle) == "string" then
        local node = hardware.get(handle)
        if not node then error("bad argument #1 (no such device)", 2) end
        if not node.internalState.tty then error("bad argument #1 (no TTY available on device)", 2) end
        handle = node.internalState.tty
        if process.stderr.frontmostProcess ~= process then
            process.stderr.frontmostProcess = table.remove(process.stderr.processList)
            handle.processList[#handle.processList+1] = handle.frontmostProcess
            handle.frontmostProcess = process
        end
        process.stderr = handle
    elseif handle == nil then process.stderr = nil
    else
        if handle.isTTY then
            handle = terminal.userTTYs[handle]
            if not handle then error("bad argument #1 (invalid TTY)", 2) end
            if process.stderr.frontmostProcess ~= process then
                process.stderr.frontmostProcess = table.remove(process.stderr.processList)
                handle.processList[#handle.processList+1] = handle.frontmostProcess
                handle.frontmostProcess = process
            end
        else
            expect.field(handle, "write", "function")
            local write = handle.write
            handle = {
                write = function(...)
                    local ok, res = userModeCallback(process, write, ...)
                    if ok then return res else error(res, 2) end
                end
            }
        end
        process.stderr = handle
    end
end

function syscalls.istty(process, thread)
    return process.stdin and process.stdin.isTTY, process.stdout and process.stdout.isTTY
end

function syscalls.termsize(process, thread)
    if not process.stdout or not process.stdout.isTTY then return nil, nil end
    return process.stdout.size.width, process.stdout.size.height
end

--#endregion

--#region 20-syslog.lua

--- Stores all open system logs.
syslogs = {
    default = {
        --file = filesystem.open(KERNEL, "/var/log/default.log", "a"),
        stream = {},
        tty = KERNEL.stdout, -- console (tty0)
        tty_level = args.loglevel,
        colorize = true
    }
}

local loglevels = {
    [0] = "Debug",
    "Info",
    "Notice",
    "Warning",
    "Error",
    "Critical",
    "Panic"
}

local lognames = {}
for i = 0, #loglevels do lognames[loglevels[i]:lower()] = i end

local logcolors = {[0] = '\27[90m', '\27[97m', '\27[36m', '\27[93m', '\27[31m', '\27[95m', '\27[96m'}

local function concat(t, sep, i, j)
    if i >= j then return tostring(t[i])
    else return tostring(t[i]) .. sep .. concat(t, sep, i + 1, j) end
end

function syscalls.syslog(process, thread, options, ...)
    local args = table.pack(...)
    if type(options) == "table" then
        expect.field(options, "name", "string", "nil")
        expect.field(options, "category", "string", "nil")
        expect.field(options, "level", "number", "string", "nil")
        expect.field(options, "time", "number", "nil")
        expect.field(options, "process", "number", "nil")
        expect.field(options, "thread", "number", "nil")
        expect.field(options, "module", "string", "nil")
        expect.field(options, "traceback", "boolean", "nil")
        if type(options.level) == "string" then
            options.level = lognames[options.level:lower()]
            if not options.level then error("bad field 'level' (invalid name)", 0) end
        elseif options.level and (options.level < 0 or options.level > #loglevels) then error("bad field 'level' (level out of range)", 0) end
        options.name = options.name or "default"
        options.process = options.process or process.id
        options.thread = options.thread or (thread and thread.id)
        options.level = options.level or 1
        options.time = options.time or os.epoch "utc"
    else
        local n = args.n
        table.insert(args, 1, options)
        args.n = n + 1
        options = {process = process.id, thread = thread and thread.id, level = 1, name = "default", time = os.epoch "utc"}
    end
    local log = syslogs[options.name]
    if log == nil then error("No such log named " .. options.name, 0) end
    local message
    for i = 1, args.n do message = (i == 1 and "" or message .. " ") .. serialize(args[i]) end
    if log.file then
        log.file.writeLine(("[%s]%s %s[%d%s]%s [%s]: %s"):format(
            os.date("%b %d %X", options.time / 1000),
            options.category and " <" .. options.category .. ">" or "",
            processes[options.process] and processes[options.process].name or "(unknown)",
            options.process,
            options.thread and ":" .. options.thread or "",
            options.module and " (" .. options.module .. ")" or "",
            loglevels[options.level],
            concat(args, " ", 1, args.n)
        ))
        log.file.flush()
    end
    if log.stream then
        options.message = message
        for _,v in pairs(log.stream) do
            -- A filter consists of a series of clauses separated by semicolons
            -- Each clause consists of a name, operator, and one or more values separated by bars ('|')
            -- String values may be surrounded with double quotes to allow semicolons, bars, and leading spaces
            -- If multiple values are specified, any value matching will cause the clause to resolve to true
            -- Available operators: ==, !=/~=, =% (match), !%/~% (not match), <, <=, >=, > (numbers only)
            -- All clauses must be true for the filter to match
            -- Example: level == 3 | 4 | 5; category != filesystem; process > 0; message =% "Unexpected error"
            local ok = true
            if v.filter then
                local name, op, val = ""
                local i = 1
                local quoted, escaped = false, false
                while i < #v.filter do
                    if op == nil then
                        name, i = v.filter:match("(%a+)%s*()", i)
                        if options[name] == nil then
                            -- Report error?
                            ok = false
                            break
                        end
                        op = ""
                    elseif val == nil then
                        local o = v.filter:sub(i, i+1)
                        if o == "==" or o == "!=" or o == "=%" or o == "!%" or o == "<=" or o == ">=" then op = o
                        elseif o == "~=" then op = "!="
                        elseif o == "~%" then op = "!%"
                        elseif v.filter:sub(i, i) == '<' or v.filter:sub(i, i) == '>' then op = v.filter:sub(i, i)
                        else
                            -- Report error?
                            ok = false
                            break
                        end
                        val = ""
                    else
                        local c = v.filter:sub(i, i)
                        if quoted then
                            if c == quoted and not escaped then
                                quoted, escaped = false, false
                            else
                                val = val .. c
                                if not escaped and c == '\\' then escaped = true
                                else escaped = false end
                            end
                        elseif c == '"' or c == "'" then
                            quoted = c
                        elseif c == '|' or c == ';' then
                            -- Evaluate the current expression
                            if (op == "==" and options[name] == val) or
                               (op == "!=" and options[name] ~= val) or
                               (op == "=%" and options[name]:match(val)) or
                               (op == "!%" and not options[name]:match(val)) or
                               (op == "<" and (tonumber(options[name]) or 0) < (tonumber(val) or 0)) or
                               (op == "<=" and (tonumber(options[name]) or 0) <= (tonumber(val) or 0)) or
                               (op == ">=" and (tonumber(options[name]) or 0) >= (tonumber(val) or 0)) or
                               (op == ">" and (tonumber(options[name]) or 0) > (tonumber(val) or 0)) then
                                if c == '|' then
                                    i = v.filter:match("[^;]*;+()", i)
                                    if i == nil then break end
                                    i=i-1 -- increment gets hit before looping
                                end
                                name, op, val = ""
                                quoted, escaped = false, false
                            else
                                ok = c == '|'
                                val = ""
                                if not ok then break end
                            end
                        elseif not (c == ' ' and val == "") then
                            val = val .. c
                        end
                        i=i+1
                    end
                end
                if quoted then
                    -- Report error?
                    ok = false
                    break
                end
            end
            if ok then
                process.queueEvent(v.pid, "syslog", v.id, options)
            end
        end
    end
    if log.tty and log.tty_level <= options.level then
        if log.tty.isTTY then
            local str = concat(args, " ", 1, args.n)
            if log.colorize and options.traceback then
                str = str:gsub("\t", "  ")
                         :gsub("([^\n]+):(%d+):", "\27[96m%1\27[37m:\27[95m%2\27[37m:")
                         :gsub("'([^']+)'\n", "\27[93m'%1'\27[37m\n")
            end
            terminal.write(log.tty, ("%s[%s]%s %s[%d%s]%s [%s]: %s%s\n"):format(
                log.colorize and logcolors[options.level] or "",
                os.date("%b %d %X", options.time / 1000),
                options.category and " <" .. options.category .. ">" or "",
                processes[options.process] and processes[options.process].name or "(unknown)",
                options.process,
                options.thread and ":" .. options.thread or "",
                options.module and " (" .. options.module .. ")" or "",
                loglevels[options.level],
                str,
                log.colorize and "\27[0m" or ""
            ))
            terminal.redraw(log.tty)
        else end
    end
end

function syscalls.mklog(process, thread, name, streamed, path)
    expect(1, name, "string")
    expect(2, streamed, "boolean", "nil")
    expect(3, path, "string", "nil")
    if syslogs[name] then error("Log already exists", 0) end
    syslogs[name] = {}
    if path then
        local err
        syslogs[name].file, err = filesystem.open(process, path, "a")
        if syslogs[name].file == nil then
            syslogs[name] = nil
            return error("Could not open log file: " .. err, 0)
        end
    end
    if streamed then syslogs[name].stream = {} end
end

function syscalls.rmlog(process, thread, name)
    expect(1, name, "string")
    if name == "default" then error("Cannot delete default log", 0) end
    if not syslogs[name] then error("Log does not exist", 0) end
    if syslogs[name].stream then for _,v in pairs(syslogs[name].stream) do
        process.queueEvent(v.pid, "syslog_close", v.id)
        processes[v.pid].dependents[v.id] = nil
    end end
    syslogs[name] = nil
end

function syscalls.openlog(process, thread, name, filter)
    expect(1, name, "string")
    expect(2, filter, "string", "nil")
    if not syslogs[name] then error("Log does not exist", 0) end
    if not syslogs[name].stream then error("Log does not have streaming enabled", 0) end
    local id = #process.dependents+1
    local pid = process.pid
    process.dependents[id] = {type = "log", name = name, filter = filter, gc = function()
        for i,v in pairs(syslogs[name].stream) do
            if v.id == id and v.pid == pid then
                syslogs[name].stream[i] = nil
            end
        end
    end}
    syslogs[name].stream[#syslogs[name].stream+1] = {pid = pid, id = id, filter = filter}
    return id
end

function syscalls.closelog(process, thread, name)
    expect(1, name, "string", "number")
    if type(name) == "string" then
        -- Close all logs on `name`
        if not syslogs[name] then error("Log does not exist", 0) end
        if not syslogs[name].stream then error("Log does not have streaming enabled", 0) end
        for i,v in pairs(syslogs[name].stream) do
            if v.pid == process.pid then
                process.dependents[v.id] = nil
                syslogs[name].stream[i] = nil
            end
        end
    else
        -- Close log connection with ID
        if not process.dependents[name] then error("Log connection does not exist", 0) end
        local log = syslogs[process.dependents[name].name].stream
        for i,v in pairs(log) do
            if v.pid == process.pid and v.id == name then
                process.dependents[v.id] = nil
                log[i] = nil
                break
            end
        end
    end
end

function syscalls.logtty(process, thread, name, tty, level)
    if process.user ~= "root" then error("Permission denied", 0) end
    expect(1, name, "string")
    expect(2, tty, "table", "number", "nil")
    expect(3, level, "number", "nil")
    if not syslogs[name] then error("Log does not exist", 0) end
    syslogs[name].tty = type(tty) == "table" and tty or TTY[tty]
    syslogs[name].tty_level = level
    return true
end

function syslog.log(options, ...)
    return pcall(syscalls.syslog, KERNEL, nil, options, ...)
end

function syslog.debug(...)
    return pcall(syscalls.syslog, KERNEL, nil, {level = "debug", process = 0}, ...)
end

local oldpanic = panic
--- Immediately halts the system and shows an error message on screen.
-- This function can be called either standalone or from within xpcall.
-- This function never returns.
-- @tparam[opt] any message A message to display on screen
function panic(message)
    syslog.log({level = "panic"}, "Kernel panic:", message)
    if debug then
        local traceback = debug.traceback(nil, 2)
        syslog.log({level = "panic", traceback = true}, traceback)
    end
    syslog.log({level = "panic"}, "We are hanging here...")
    term.setCursorBlink(false)
    while true do coroutine.yield() end
end

syslogs.default.file = filesystem.open(KERNEL, "/var/log/default.log", "a")

syslog.log("Starting Phoenix version", PHOENIX_VERSION, PHOENIX_BUILD)
syslog.log("Initialized system logger")
syslog.log("System started at " .. systemStartTime .. " on computer " .. os.computerID() .. (os.computerLabel() and "('" .. os.computerLabel() .. "')" or ""))
syslog.log("Computer host is " .. _HOST)


--#endregion

--#region 25-linker.lua

local function trim(s) return string.match(s, '^()%s*$') and '' or string.match(s, '^%s*(.*%S)') end
local expect, do_syscall = expect, do_syscall

local function ar_load(data)
    local pos = 1
    local function read(c)
        if pos > #data then return nil end
        c = c or 1
        local s = data:sub(pos, pos + c - 1)
        pos = pos + c
        return s
    end
    if read(8) ~= "!<arch>\n" then error("Not an ar archive", 2) end
    local retval = {}
    local name_table = nil
    local name_rep = {}
    while true do
        local data = {}
        local first_c = read()
        while first_c == "\n" do first_c = read() end
        if first_c == nil then break end
        local name = read(15)
        if name == nil then break end
        name = first_c .. name
        if string.find(name, "/") and string.find(name, "/") > 1 then name = string.sub(name, 1, string.find(name, "/") - 1)
        else name = trim(name) end
        data.timestamp = tonumber(trim(read(12)))
        data.owner = tonumber(trim(read(6)))
        data.group = tonumber(trim(read(6)))
        data.mode = tonumber(trim(read(8)), 8)
        local size = tonumber(trim(read(10)))
        if read(2) ~= "`\n" then error("Invalid header for file " .. name, 2) end
        if string.match(name, "^#1/%d+$") then name = read(tonumber(string.match(name, "#1/(%d+)")))
        elseif string.match(name, "^/%d+$") then if name_table then
            local n = tonumber(string.match(name, "/(%d+)"))
            name = name_table:match("[^/]*", n+1)
        else table.insert(name_rep, name) end end
        data.name = name
        data.data = read(size)
        if name == "//" then name_table = data.data
        elseif name ~= "/" and name ~= "/SYM64/" then table.insert(retval, data) end
    end
    if name_table then for k,v in pairs(name_rep) do
        local n = tonumber(string.match(v, "/(%d+)"))
        for l,w in pairs(retval) do if w.name == v then w.name = name_table:match("[^/]*", n+1) break end end
    end end
    local retval2 = {}
    for _, v in ipairs(retval) do retval2[v.name] = v end
    return retval2
end

--- Creates a new `package` and `require` set in a global table for the specified process.
-- @tparam Process process The process to make the functions for
-- @tparam _G G The global environment to install in
function createRequire(process, G)
    G.package = {}
    local oldenv = processes[process.parent] and processes[process.parent].env
    if oldenv then
        G.package.path = oldenv.package and oldenv.package.path
        G.package.libpath = oldenv.package and oldenv.package.libpath
    end
    G.package.path = G.package.path or "/lib/?.lua;/lib/?/init.lua;/usr/lib/?.lua;/usr/lib/?/init.lua;./?.lua;./?/init.lua"
    G.package.libpath = G.package.libpath or "/lib/lib?.a;/usr/lib/lib?.a"
    G.package.config = "/\n;\n?\n!\n-"
    G.package.loaded = {}
    G.package.preload = {}
    G.package.forceload = false
    for k, v in pairs(G) do if type(v) == "table" then G.package.loaded[k] = v end end

    local sentinel = setmetatable({}, {__newindex = function() end, __metatable = false})
    local localLoaders = {}

    local function fileLoader(name, path)
        local file, err = do_syscall("open", path, "rb")
        if not file then error(path .. ": " .. err, 3) end
        local data = file.readAll()
        file.close()
        local fn, err = load(data, "@" .. path, nil, _ENV)
        if not fn then error(path .. ": " .. err, 3) end
        local dir = path:match("^(.*)/[^/]*$") or "/"
        localLoaders[#localLoaders+1] = function(name2)
            local path, err = package.searchpath(name2, dir .. "/?.lua;" .. dir .. "/?/init.lua")
            if not path then return nil, err end
            return fileLoader, path
        end
        local ok, res = pcall(fn, name)
        localLoaders[#localLoaders] = nil
        if ok then return res
        else error(path .. ": " .. res, 3) end
    end

    local function libraryLoader(name, path)
        local libname
        if path:find "%z" then path, libname = path:match "^([^%z]*)%z(.*)$"
        elseif name:find "%-" then libname = name:match("^([^%-]*)%-(.*)$")
        else libname = "init" end
        local file, err = do_syscall("open", path, "rb")
        if not file then error(path .. ": " .. err, 3) end
        local data = file.readAll()
        file.close()
        local dir = ar_load(data)
        local function preloader(name)
            local p = name .. ".lua"
            if not dir[p] then error(path .. ":" .. p .. ": File not found", 0) end
            local data = dir[p].data
            local fn, err = load(data, "@" .. path .. ":" .. p, nil, _ENV)
            if not fn then error(path .. ":" .. p .. ": " .. err, 3) end
            local ok, res = pcall(fn, name)
            if ok then return res
            else error(path .. ":" .. p .. ": " .. res) end
        end
        localLoaders[#localLoaders+1] = function(name2) return preloader, name2 end
        local res = preloader(libname)
        localLoaders[#localLoaders] = nil
        return res
    end

    localLoaders[1] = function(name)
        local dir = do_syscall("getname"):match("^(.*)/[^/]*$") or "/"
        local path, err = package.searchpath(name, dir .. "/?.lua;" .. dir .. "/?/init.lua")
        if not path then return nil, err end
        return fileLoader, path
    end

    function G.package.searchpath(name, path, sep, rep)
        expect(1, name, "string")
        expect(2, path, "string")
        expect(3, sep, "string", "nil")
        expect(4, rep, "string", "nil")
        sep = (sep or "."):gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1")
        rep = (rep or "/"):gsub("([%^%$%(%)%%%.%[%]%*%+%-%?])", "%%%1")
        local msg = ""

        for p in path:gmatch "[^;]+" do
            local pp = p:gsub("%?", name:gsub(sep, rep), nil)
            local file, err = do_syscall("open", pp, "r")
            if file then
                file.close()
                return pp
            else
                msg = msg .. "\t" .. pp .. ": " .. err .. "\n"
            end
        end
        return nil, msg
    end

    G.package.searchers = {
        function(name)
            local p = package.preload[name]
            if p then return p else return nil, "\tpackage.preload['" .. name .. "']: No such field\n" end
        end,
        function(name)
            local path, err = package.searchpath(name, package.path)
            if not path then return nil, err end
            return fileLoader, path, path
        end,
        function(name)
            local path, err = package.searchpath(name:match("^[^%-]*"), package.libpath)
            if not path then return nil, err end
            local n = name:match("%-(.+)$")
            if n then return libraryLoader, path, path .. ":" .. n
            else return libraryLoader, path, path .. ":init" end
        end,
        function(name)
            if not name:find "%." then return nil end
            local path, err = package.searchpath(name:match("^[^%.]*"), package.libpath)
            if not path then return nil, err end
            local n = name:match("^[^%.]*%.(.*)$")
            return libraryLoader, path .. "\0" .. n, path .. ":" .. n
        end,
        function(name)
            if #localLoaders > 0 then return localLoaders[#localLoaders](name) end
            return nil, "no local loaders found"
        end
    }

    setfenv(fileLoader, G) debug.protect(fileLoader)
    setfenv(libraryLoader, G) debug.protect(libraryLoader)
    setfenv(localLoaders[1], G) debug.protect(localLoaders[1])
    for _,v in pairs(G.package.searchers) do setfenv(v, G) debug.protect(v) end

    function G.require(name)
        expect(1, name, "string")
        local err = "module '" .. name .. "' not found:\n"
        local loader, arg, pathname
        for _, v in ipairs(package.searchers) do
            loader, arg, pathname = v(name)
            if loader then break end
            err = err .. (arg or "")
        end
        if not loader then error(err, 2) end
        if pathname then
            if package.loaded[pathname] then
                if package.loaded[pathname] == sentinel then error("loop detected loading '" .. name .. "'", 3)
                elseif not package.forceload then return package.loaded[pathname] end
            end
            package.loaded[pathname] = sentinel
        else
            if package.loaded[name] then
                if package.loaded[name] == sentinel then error("loop detected loading '" .. name .. "'", 3)
                elseif not package.forceload then return package.loaded[name] end
            end
        end
        package.loaded[name] = sentinel
        local ok, res = pcall(loader, name, arg)
        if ok then
            if res ~= nil then package.loaded[name] = res
            elseif package.loaded[name] == sentinel then package.loaded[name] = true end
            if pathname then
                if res ~= nil then package.loaded[pathname] = res
                elseif package.loaded[pathname] == sentinel then package.loaded[pathname] = true end
            end
            return package.loaded[name]
        else
            package.loaded[name] = nil
            if pathname then package.loaded[pathname] = nil end
            error(err .. "\t" .. res .. "\n", 2)
        end
    end

    return G
end

--#endregion

--#region 30-event.lua

--- Stores a list of used timers.
timerMap = {}
--- Stores a list of used alarms.
alarmMap = {}

local serviceRegistry = {}

function syscalls.kill(process, thread, pid, signal)
    expect(1, pid, "number")
    expect(2, signal, "number")
    local target = processes[pid]
    if not target then error("No such process", 2) end
    if process.user ~= "root" and process.user ~= target.user then error("Permission denied", 2) end
    --syslog.debug("Sending signal", signal, "to PID", pid)
    if signal == 9 then
        reap_process(target)
        if processes[target.parent] then syscalls.queueEvent(processes[target.parent], nil, "process_complete", {id = pid, result = 9}) end
        processes[pid] = nil
    elseif target.signalHandlers[signal] then
        userModeCallback(target, target.signalHandlers[signal], signal)
    else
        syscalls.queueEvent(target, nil, "signal", {signal = signal})
    end
end

function syscalls.signal(process, thread, signal, handler)
    expect(1, signal, "number")
    expect(2, handler, "function", "nil")
    process.signalHandlers[signal] = handler
end

function syscalls.queueEvent(process, thread, name, params)
    expect(1, name, "string")
    expect(2, params, "table")
    process.eventQueue[#process.eventQueue+1] = {name, params}
end

function syscalls.sendEvent(process, thread, pid, name, params)
    expect(1, pid, "number")
    expect(2, name, "string")
    local target = processes[pid]
    if not target then return false end
    -- TODO: figure out filtering
    target.eventQueue[#target.eventQueue+1] = {"remote_event", {type = name, sender = process.id, data = params}}
    return true -- TODO: ?
end

function syscalls.register(process, thread, name)
    expect(1, name, "string")
    if serviceRegistry[name] then return false end
    serviceRegistry[name] = process.id
    process.dependents[#process.dependents+1] = {gc = function() serviceRegistry[name] = nil end}
    return true
end

function syscalls.lookup(process, thread, name)
    expect(1, name, "string")
    return serviceRegistry[name]
end

function syscalls.timer(process, thread, timeout)
    expect(1, timeout, "number")
    local tm = os.startTimer(timeout)
    timerMap[tm] = process
    return bit32.band(tm, 0x7FFFFFFF)
end

-- TODO: Determine the type of time for the alarm + how to expose it to userland
function syscalls.alarm(process, thread, timeout)
    expect(1, timeout, "number")
    local tm = os.setAlarm(timeout)
    alarmMap[tm] = process
    return bit32.bor(tm, 0x80000000)
end

function syscalls.cancel(process, thread, tm)
    expect(1, tm, "number")
    if bit32.btest(tm, 0x80000000) then
        tm = bit32.band(tm, 0x7FFFFFFF)
        if alarmMap[tm] ~= process then error("No such alarm") end
        os.cancelAlarm(tm)
        alarmMap[tm] = nil
    else
        if timerMap[tm] ~= process then error("No such timer") end
        os.cancelTimer(tm)
        timerMap[tm] = nil
    end
end

eventHooks.terminate = eventHooks.terminate or {}
eventHooks.terminate[#eventHooks.terminate+1] = function()
    if currentTTY.frontmostProcess then syscalls.kill(KERNEL, nil, currentTTY.frontmostProcess.id, 2) terminal.write(currentTTY, "^T") end
end

eventParameterMap = {
    alarm = {"id"},
    char = {"character"},
    key = {"keycode", "isRepeat"},
    key_up = {"keycode"},
    mouse_click = {"button", "x", "y"},
    mouse_drag = {"button", "x", "y"},
    mouse_up = {"button", "x", "y"},
    mouse_scroll = {"direction", "x", "y"},
    paste = {"text"},
    redstone = {},
    term_resize = {},
    timer = {"id"},
    turtle_inventory = {}
}

do
    local maxkey = 0
    for _, v in pairs(keys) do if type(v) == "number" then maxkey = math.max(maxkey, v) end end
    -- We're using some sneaky hacks here to be able to ensure the LUT is allocated as an array and not a hashmap
    -- Essentially, we load a pre-assembled function with the instructions `NEWTABLE 0 $maxkey 0; RETURN 0 2`
    -- This depends on the Lua version, so we implement it specially for each version detected
    local code
    local template = string.dump(function() end)
    local tabsize = (function(x)
        if x < 8 then return x end
        local e = 0
        while x >= 128 do x, e = bit32.rshift(x + 0xf, 4), e + 4 end
        while x >= 16 do x, e = bit32.rshift(x + 1, 1), e + 1 end
        return bit32.bor((e + 1) * 8, x - 8)
    end)(maxkey)
    if _VERSION == "Lua 5.1" then code = template:sub(1, 12) .. ("I" .. template:byte(9) .. "IIBBBBIIIIIIII"):pack(0, 0, 0, 0, 0, 0, 1, 2, tabsize * 0x800000 + 10, 0x0100001E, 0, 0, 0, 0, 0)
    elseif _VERSION == "Lua 5.2" then code = template:sub(1, 18) .. ("IIBBBIIIIIIIIII"):pack(0, 0, 0, 0, 1, 2, tabsize * 0x800000 + 11, 0x0100001F, 0, 0, 0, 0, 0, 0, 0)
    elseif _VERSION == "Lua 5.3" then code = template:sub(1, 17 + ("jn"):packsize()) .. ("BBIIBBBIIIIIIIII"):pack(0, 0, 0, 0, 0, 0, 1, 2, tabsize * 0x800000 + 11, 0x01000026, 0, 0, 0, 0, 0, 0)
    elseif _VERSION == "Lua 5.4" then code = template:sub(1, 15 + ("jn"):packsize()) .. ("BBBBBBBBIIIBBBBBBB"):pack(0, 0x80, 0x80, 0x80, 0, 0, 1, 0x83, 0x00000013, maxkey * 0x80 + 82, 0x00008048, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80, 0x80) end
    if code then
        local fn, err = load(code, nil, "b")
        if fn then keymap = fn() else syslog.debug("Could not load key table code:", err) end
    end
    if not keymap then
        -- Fall back on an O(log n) allocation method
        --- Stores a mapping of CraftOS keys to Phoenix keycodes.
        keymap = {}
        for i = 1, maxkey do keymap[i] = 0 end
        for i = 1, maxkey do if not keys.getName(i) then keymap[i] = nil end end
    end
    -- Letters, numpad numbers and function keys are easy
    for i = 0x61, 0x7A do keymap[keys[string.char(i)]] = i end
    for i = 0x81, 0x99 do if keys["f" .. bit32.band(i, 31)] then keymap[keys["f" .. bit32.band(i, 31)]] = i end end
    for i = 0xA0, 0xA9 do keymap[keys["numPad" .. bit32.band(i, 15)]] = i end
    -- The rest have to be added manually
    keymap[keys.backspace] = 0x08
    keymap[keys.tab] = 0x09
    keymap[keys.enter or keys["return"]] = 0x0A
    keymap[keys.space] = 0x20
    keymap[keys.apostrophe] = 0x27
    keymap[keys.comma] = 0x2C
    keymap[keys.minus] = 0x2D
    keymap[keys.period] = 0x2E
    keymap[keys.slash] = 0x2F
    keymap[keys.zero] = 0x30
    keymap[keys.one] = 0x31
    keymap[keys.two] = 0x32
    keymap[keys.three] = 0x33
    keymap[keys.four] = 0x34
    keymap[keys.five] = 0x35
    keymap[keys.six] = 0x36
    keymap[keys.seven] = 0x37
    keymap[keys.eight] = 0x38
    keymap[keys.nine] = 0x39
    keymap[keys.semicolon or keys.semiColon] = 0x3B
    keymap[keys.equals] = 0x3D
    keymap[keys.leftBracket] = 0x5B
    keymap[keys.backslash] = 0x5C
    keymap[keys.rightBracket] = 0x5D
    keymap[keys.grave] = 0x60
    keymap[keys.delete] = 0x7F
    keymap[keys.insert] = 0x80
    if keys.convert then keymap[keys.convert] = 0x9A end
    if keys.noconvert then keymap[keys.noconvert] = 0x9B end
    if keys.kana then keymap[keys.kana] = 0x9C end
    if keys.kanji then keymap[keys.kanji] = 0x9D end
    if keys.yen then keymap[keys.yen] = 0x9E end
    keymap[keys.numPadDecimal] = 0x9F
    keymap[keys.numPadAdd] = 0xAA
    keymap[keys.numPadSubtract] = 0xAB
    if keys.numPadMultiply then keymap[keys.numPadMultiply] = 0xAC end
    keymap[keys.numPadDivide] = 0xAD
    keymap[keys.numPadEqual or keys.numPadEquals] = 0xAE
    keymap[keys.numPadEnter] = 0xAF
    keymap[keys.leftCtrl] = 0xB0
    keymap[keys.rightCtrl] = 0xB1
    keymap[keys.leftAlt] = 0xB2
    keymap[keys.rightAlt] = 0xB3
    keymap[keys.leftShift] = 0xB4
    keymap[keys.rightShift] = 0xB5
    if keys.leftSuper then keymap[keys.leftSuper] = 0xB6 end
    if keys.rightSuper then keymap[keys.rightSuper] = 0xB7 end
    keymap[keys.capsLock] = 0xB8
    keymap[keys.numLock] = 0xB9
    keymap[keys.scrollLock or keys.scollLock] = 0xBA
    if keys.printScreen then keymap[keys.printScreen] = 0xBB end
    keymap[keys.pause] = 0xBC
    if keys.menu then keymap[keys.menu] = 0xBD end
    if keys.stop then keymap[keys.stop] = 0xBE end
    if keys.ax then keymap[keys.ax] = 0xBF end
    keymap[keys.up] = 0xC0
    keymap[keys.down] = 0xC1
    keymap[keys.left] = 0xC2
    keymap[keys.right] = 0xC3
    keymap[keys.pageUp] = 0xC4
    keymap[keys.pageDown] = 0xC5
    keymap[keys.home] = 0xC6
    keymap[keys["end"]] = 0xC7
    if keys.circumflex or keys.cimcumflex then keymap[keys.circumflex or keys.cimcumflex] = 0xC8 end
    if keys.at then keymap[keys.at] = 0xC9 end
    if keys.colon then keymap[keys.colon] = 0xCA end
    if keys.underscore then keymap[keys.underscore] = 0xCB end
end

--#endregion

--#region 35-process.lua

local process_template = {
    id = 1,
    name = "init",
    user = "root",
    dependents = {
        {gc = function() end}
    },
    parent = 0,
    dir = "/",
    stdin = TTY[1],
    stdout = {}, -- pipe
    stderr = TTY[1],
    cputime = 0.2,
    systime = 0.1,
    env = {},
    syscallyield = nil,
    eventQueue = {},
    signalHandlers = {},
    paused = false,
    threads = {
        [0] = {
            id = 0,
            name = "",
            coro = coroutine.create(function() end),
            status = "starting",
            args = {"a", n = 1},
            filter = function(process, thread, event) end
        }
    }
}

local function mkenv(process)
    local env = createLuaLib(process)
    if _VERSION < "Lua 5.2" then
        -- Emulate _ENV environments on Lua 5.1
        setmetatable(env, {
            __index = function(self, idx)
                if idx == "_ENV" then return getfenv(2) end
                return nil
            end,
            __newindex = function(self, idx, val)
                if idx == "_ENV" then setfenv(2, val) return end
                rawset(self, idx, val)
            end
        })
    end
    env._G = env
    return env
end

local function preempt_hook()
    coroutine.yield("preempt", "test", 7)
end

--- Finishes a process's resources so it can be removed cleanly.
-- @tparam Process process The process to reap
function reap_process(process)
    -- TODO: finish this
    syslog.debug("Reaping process " .. process.id .. " (" .. process.name .. ")")
    for _, v in ipairs(process.dependents) do v:gc() end
    if process.stdin and process.stdin.isTTY then
        if process.stdin.frontmostProcess == process then
            process.stdin.frontmostProcess = table.remove(process.stdin.processList)
            process.stdin.preBuffer = ""
        else for i, v in ipairs(process.stdin.processList) do
            if v == process then table.remove(process.stdin.processList, i) break end
        end end
    end
    if process.stdout and process.stdout.isTTY then
        if process.stdout.frontmostProcess == process then
            process.stdout.frontmostProcess = table.remove(process.stdout.processList)
        else for i, v in ipairs(process.stdout.processList) do
            if v == process then table.remove(process.stdout.processList, i) break end
        end end
    end
    if process.stderr and process.stderr.isTTY then
        if process.stderr.frontmostProcess == process then
            process.stderr.frontmostProcess = table.remove(process.stderr.processList)
        else for i, v in ipairs(process.stderr.processList) do
            if v == process then table.remove(process.stderr.processList, i) break end
        end end
    end
end

function syscalls.getpid(process, thread)
    return process.id
end

function syscalls.getppid(process, thread)
    return process.parent
end

function syscalls.clock(process, thread)
    return process.cputime
end

function syscalls.getenv(process, thread)
    return process.env
end

function syscalls.getname(process, thread)
    return process.name
end

function syscalls.getcwd(process, thread)
    return process.dir
end

function syscalls.chdir(process, thread, dir)
    expect(1, dir, "string")
    local stat = filesystem.stat(process, dir)
    if not stat or stat.type ~= "directory" then return false, "No such file or directory"
    elseif not (stat.permissions[process.user] or stat.worldPermissions).execute then return false, "Permission denied" end
    process.dir = dir:gsub("^([^/])", "/" .. process.dir .. "/%1")
    return true
end

function syscalls.getuser(process, thread)
    return process.user, process.realuser
end

function syscalls.setuser(process, thread, user)
    expect(1, user, "string")
    if process.user ~= "root" then error("Permission denied") end
    process.user = user
    process.realuser = nil
end

function syscalls.fork(process, thread, func, name, ...)
    expect(1, func, "function")
    expect(2, name, "string", "nil")
    local id = #processes + 1
    processes[id] = {
        id = id,
        name = name or process.name,
        user = process.user,
        dependents = {},
        parent = process.id,
        dir = process.dir,
        stdin = process.stdin,
        stdout = process.stdout,
        stderr = process.stderr,
        cputime = 0,
        systime = 0,
        syscallyield = nil,
        eventQueue = {},
        signalHandlers = {
            [1] = function() return coroutine.yield("syscall", "exit", 1) end,
            [2] = function() return coroutine.yield("syscall", "exit", 1) end,
            [3] = function()
                -- TODO: finalize this behavior
                coroutine.yield("syscall", "syslog", {level = "error", category = "Application Error", traceback = true}, debug.traceback("Quit"))
                return coroutine.yield("syscall", "exit", 1)
            end,
            [6] = function(err)
                -- TODO: finalize this behavior
                coroutine.yield("syscall", "syslog", {level = "error", category = "Application Error", traceback = true}, debug.traceback(err or "Aborted"))
                return coroutine.yield("syscall", "exit", 1)
            end,
            [13] = function() return coroutine.yield("syscall", "exit", 1) end,
            [15] = function() return coroutine.yield("syscall", "exit", 1) end,
            [19] = function() return coroutine.yield("syscall", "suspend") end,
            [21] = function() return coroutine.yield("syscall", "suspend") end,
            [22] = function() return coroutine.yield("syscall", "suspend") end,
        },
        paused = false,
        threads = {
            [0] = {
                id = 0,
                name = "<main thread>",
                coro = coroutine.create(func),
                status = "starting",
                args = table.pack(...),
                filter = nil,
            }
        }
    }
    processes[id].env = mkenv(processes[id])
    setfenv(func, processes[id].env)
    if process.stdin and process.stdin.isTTY and not process.stdin.isLocked then
        process.stdin.processList[#process.stdin.processList+1] = process.stdin.frontmostProcess
        process.stdin.frontmostProcess = processes[id]
        process.stdin.preBuffer = ""
    end
    if process.stdout and process.stdout.isTTY and not process.stdout.isLocked and process.stdout.frontmostProcess ~= processes[id] then
        process.stdout.processList[#process.stdout.processList+1] = process.stdout.frontmostProcess
        process.stdout.frontmostProcess = processes[id]
    end
    if process.stderr and process.stderr.isTTY and not process.stderr.isLocked and process.stderr.frontmostProcess ~= processes[id] then
        process.stderr.processList[#process.stderr.processList+1] = process.stderr.frontmostProcess
        process.stderr.frontmostProcess = processes[id]
    end
    if args.preemptive then debug.sethook(processes[id].threads[0].coro, preempt_hook, "", args.quantum) end
    return id
end

function syscalls.exec(process, thread, path, ...)
    expect(1, path, "string")
    local file, err = filesystem.open(process, path, "r")
    if not file then
        path = path .. ".lua"
        file, err = filesystem.open(process, path, "r")
        if not file then error("Could not open file: " .. err, 0) end
    end
    local contents = file.readAll()
    file.close()
    if contents:match("\x1bLua") then
        file, err = filesystem.open(process, path, "rb")
        if not file then error("Could not open file: " .. err, 0) end
        contents = file.readAll()
        file.close()
    end
    local stat = filesystem.stat(process, path)
    if not (stat.permissions[stat.owner] or stat.worldPermissions).execute then error("Could not execute file: Permission denied", 0) end
    if stat.setuser then process.realuser, process.user = process.user, stat.owner end
    if contents:sub(1, 2) == "#!" then
        local command = contents:sub(3, contents:find("\n") - 1)
        local args, i = {}, 0
        for s in command:gmatch "%S+" do args[i] = s i=i+1 end
        for _,v in ipairs{...} do args[i] = v i=i+1 end
        if args[0] == path then error("Recursive path detected while resolving shebang", 0) end
        syscalls.exec(process, thread, args[0], table.unpack(args, 1, i - 1))
        local f = filesystem.open(process, path, "rb")
        process.stdin = {read = function(n) if n then return f.read(n) else return f.readLine() end end}
        process.name = "/" .. fs.combine(path:sub(1, 1) == "/" and "" or process.dir, path)
    else
        local func, err = load(contents, "@" .. path, "bt", process.env)
        if not func then error("Could not execute file: " .. err, 0) end
        process.name = "/" .. fs.combine(path:sub(1, 1) == "/" and "" or process.dir, path)
        process.threads = {
            [0] = {
                id = 0,
                name = "<main thread>",
                coro = coroutine.create(func),
                status = "starting",
                args = table.pack(...),
                filter = nil,
            }
        }
        if args.preemptive then debug.sethook(process.threads[0].coro, preempt_hook, "", args.quantum) end
    end
end

function syscalls.newthread(process, thread, func, ...)
    expect(1, func, "function")
    local id = #process.threads + 1
    process.threads[id] = {
        id = id,
        name = "<thread:" .. id .. ">",
        coro = coroutine.create(func),
        status = "starting",
        args = table.pack(...),
        filter = nil,
    }
    setfenv(func, process.env)
    if args.preemptive then debug.sethook(process.threads[id].coro, preempt_hook, "", args.quantum) end
    return id
end

function syscalls.exit(process, thread, code)
    -- TODO
    for _, thread in pairs(process.threads) do thread.status = "dead" end
end

function syscalls.getplist(process, thread)
    local pids = {}
    for k in pairs(processes) do pids[#pids+1] = k end
    table.sort(pids)
    return pids
end

function syscalls.getpinfo(process, thread, pid)
    expect(1, pid, "number")
    local p = processes[pid]
    if not p then return nil, "No such process" end
    local stdin, stdout, stderr
    for i, v in ipairs(TTY) do
        if p.stdin == v then stdin = i end
        if p.stdout == v then stdout = i end
        if p.stderr == v then stderr = i end
    end
    local threads = {}
    if p.threads then for i, v in pairs(p.threads) do threads[i] = {
        id = v.id,
        name = v.name,
        status = v.status,
    } end end
    return {
        id = p.id,
        name = p.name,
        user = p.user,
        realuser = p.realuser,
        parent = p.parent,
        dir = p.dir,
        stdin = stdin,
        stdout = stdout,
        stderr = stderr,
        cputime = p.cputime or 0,
        systime = p.systime or 0,
        threads = threads,
    }
end

function syscalls.suspend(process, thread)
    process.paused = true
end

--#endregion

--#region 40-hardware.lua

-- UUID generation code

-- Borrowed from https://github.com/mpeterv/sha1
-- Calculates SHA1 for a string, returns it encoded as 40 hexadecimal digits.
local function sha1(str)
    str = str .. "\x80" .. ("\0"):rep(-(#str + 9) % 64) .. (">I8"):pack(#str)
    local h0, h1, h2, h3, h4, w = 0x67452301, 0xEFCDAB89, 0x98BADCFE, 0x10325476, 0xC3D2E1F0, {}
    for chunk_start = 1, #str, 64 do
        local uint32_start = chunk_start
        for i = 0, 15 do
            w[i] = str:byte(uint32_start) * 0x1000000 + str:byte(uint32_start+1) * 0x10000 + str:byte(uint32_start+2) * 0x100 + str:byte(uint32_start+3)
            uint32_start = uint32_start + 4
        end
        for i = 16, 79 do w[i] = bit32.lrotate(bit32.bxor(w[i - 3], w[i - 8], w[i - 14], w[i - 16]), 1) end
        local a, b, c, d, e = h0, h1, h2, h3, h4
        for i = 0, 79 do
            local f, k
            if i <= 19 then f, k = bit32.bxor(d, bit32.band(b, bit32.bxor(c, d))), 0x5A827999
            elseif i <= 39 then f, k = bit32.bxor(b, c, d), 0x6ED9EBA1
            elseif i <= 59 then f, k = bit32.bor(bit32.band(b, bit32.bor(c, d)), bit32.band(c, d)), 0x8F1BBCDC
            else f, k = bit32.bxor(b, c, d), 0xCA62C1D6 end
            local temp = bit32.band(bit32.lrotate(a, 5) + f + e + k + w[i], 0xFFFFFFFF)
            e, d, c, b, a = d, c, bit32.lrotate(b, 30), a, temp
        end
        h0 = bit32.band(h0 + a, 0xFFFFFFFF)
        h1 = bit32.band(h1 + b, 0xFFFFFFFF)
        h2 = bit32.band(h2 + c, 0xFFFFFFFF)
        h3 = bit32.band(h3 + d, 0xFFFFFFFF)
        h4 = bit32.band(h4 + e, 0xFFFFFFFF)
    end
    return {h0, h1, h2, h3, h4}
end

-- Creates version 5 UUIDs from a parent UUID + node name
local function makeUUID(parentUUID, name)
    local hash = sha1(parentUUID:gsub("%X", ""):gsub("%x%x", function(s) return string.char(tonumber(s, 16)) end) .. name)
    local a, b, c, d = hash[1], bit32.bor(bit32.band(hash[2], 0xFFFF0FFF), 0x5000), bit32.bor(bit32.band(hash[3], 0x3FFFFFFF), 0x80000000), hash[4]
    return ("%08x-%04x-%04x-%04x-%04x%08x"):format(a, bit32.rshift(b, 16), bit32.band(b, 0xFFFF), bit32.rshift(c, 16), bit32.band(c, 0xFFFF), d)
end

local PHOENIX_ROOT_UUID = "a6f53b7d-50f3-4e51-adef-8728c83e3f3a"

--- Stores the root device for hardware.
deviceTreeRoot = {
    id = tostring(os.getComputerID()),
    uuid = makeUUID(PHOENIX_ROOT_UUID, tostring(os.getComputerID())),
    parent = nil,
    displayName = os.getComputerLabel() or "",
    drivers = {},
    metadata = {},      -- external static metadata table for driver use - this MUST NOT be modified after registration!
    internalState = {}, -- internal state table for driver use - this may change during use
                        -- drivers should make their own table inside!!!
    children = {},
    listeners = setmetatable({}, {__mode = "k"}),
}

local deviceUUIDs = {[deviceTreeRoot.uuid] = deviceTreeRoot}
local deviceListeners = {}

--- Returns all devices that match a path specifier.
-- @tparam string path The path to query
-- @treturn Device... The device objects that match
function hardware.get(path)
    expect(1, path, "string")
    if path:find("^%x+%-%x+%-%x+%-%x+%-%x+$") then return deviceUUIDs[path]
    elseif path:find("/") then
        -- Absolute path
        local node = deviceTreeRoot
        for name in path:gmatch "[^/]+" do
            node = node.children[name]
            if node == nil then break end
        end
        return node
    else
        -- Search the entire tree for objects with the specified name (slow!)
        local matches = {}
        local function search(node)
            if node.id == path or node.alias == path then matches[#matches+1] = node end
            for _, v in pairs(node.children) do search(v) end
        end
        search(deviceTreeRoot)
        return table.unpack(matches)
    end
end

--- Returns all devices that match a type.
-- @tparam string type The type to find
-- @treturn Device... The device objects that match
function hardware.find(type)
    expect(1, type, "string")
    local found = {}
    local function traverse(node)
        for _, v in ipairs(node.drivers) do if v.type == type then found[#found+1] = node break end end
        for _, v in pairs(node.children) do traverse(v) end
    end
    traverse(deviceTreeRoot)
    return table.unpack(found)
end

--- Returns the absolute path to a device node.
-- @tparam Device node The node to lookup
-- @treturn string The path to the node
function hardware.path(node)
    expect(1, node, "table")
    expect.field(node, "uuid", "string")
    if not deviceUUIDs[node.uuid] then error("bad argument #1 (invalid node)", 2) end
    local path = node.id
    node = node.parent
    while node do
        path = node.id .. "/" .. path
        node = node.parent
    end
    path = path:gsub("^[^/]+", "")
    return path == "" and "/" or path
end

--- Adds a new child to the specified node.
-- @tparam Device parent The parent of the new node
-- @tparam string name The name of the new node
-- @treturn Device The newly added node
function hardware.add(parent, name)
    expect(1, parent, "table")
    expect(2, name, "string")
    expect.field(parent, "uuid", "string")
    if not deviceUUIDs[parent.uuid] then return nil, "Invalid parent node" end
    if parent.children[name] then return nil, "Node already exists" end
    local node = {
        id = name,
        uuid = makeUUID(parent.uuid, name),
        parent = parent,
        displayName = "",
        drivers = {},
        metadata = {},
        internalState = {},
        children = {},
        listeners = setmetatable({}, {__mode = "k"}),
    }
    parent.children[name] = node
    deviceUUIDs[node.uuid] = node
    syslog.log({module = "Hardware"}, "Added new device at " .. hardware.path(node))
    for _, v in ipairs(deviceListeners) do
        if (not v.parent or v.parent == parent) and (not v.pattern or name:match(v.pattern)) then
            v.callback(node)
        end
    end
    return node
end

--- Removes a node from its parent and the device tree. The device node should
-- no longer be used.
-- @tparam Device node The node to remove
-- @treturn boolean Whether the operation succeeded
-- @treturn string? An error message if it failed
function hardware.remove(node)
    expect(1, node, "table")
    expect.field(node, "uuid", "string")
    if not deviceUUIDs[node.uuid] then return false, "Invalid node" end
    if node == deviceTreeRoot or not node.parent then return false, "Cannot remove root node" end
    for i = #node.drivers, 1, -1 do hardware.deregister(node, node.drivers[i]) end
    for _, v in pairs(node.children) do hardware.remove(v) end -- Any children still present are removed immediately
    syslog.log({module = "Hardware"}, "Device at " .. hardware.path(node) .. " has been removed")
    node.parent.children[node.id] = nil
    deviceUUIDs[node.uuid] = nil
    node.parent = nil
    return true
end

--- Registers a device driver on a node.
-- @tparam Device node The node to modify
-- @tparam Driver driver The driver to add
-- @treturn boolean Whether the operation succeeded
-- @treturn string? An error message if it failed
function hardware.register(node, driver)
    expect(1, node, "table")
    expect(2, driver, "table")
    expect.field(node, "uuid", "string")
    expect.field(driver, "name", "string")
    expect.field(driver, "type", "string")
    expect.field(driver, "properties", "table")
    expect.field(driver, "methods", "table")
    expect.field(driver, "init", "function", "nil")
    expect.field(driver, "deinit", "function", "nil")
    for k in pairs(driver.methods) do
        if type(k) ~= "string" then error("bad method name '" .. tostring(k) .. "' (not a string)", 2) end
        expect.field(driver.methods, k, "function")
    end
    for _, v in ipairs(driver.properties) do
        if type(v) ~= "string" then error("bad property name '" .. tostring(v) .. "' (not a string)", 2) end
        if not driver.methods["get" .. v:sub(1, 1):upper() .. v:sub(2)] then error("bad property '" .. v .. "' (no getter present)", 2) end
    end
    if not deviceUUIDs[node.uuid] then error("bad argument #1 (invalid node)", 2) end
    for _, v in ipairs(node.drivers) do if v == driver then return false end end
    -- TODO: check for method collisions
    node.drivers[#node.drivers+1] = driver
    syslog.log({module = "Hardware"}, "Registered device with type " .. driver.type .. " on device " .. hardware.path(node) .. " using driver " .. driver.name)
    if driver.init then driver.init(node) end
    return true
end

--- Returns a function that automatically attaches a driver to a node.
-- @tparam Driver driver The driver to use
-- @treturn function A function that takes a node and registers the driver on it
-- @see hardware.listen For use with the callback parameter
function hardware.register_callback(driver)
    return function(node) return hardware.register(node, driver) end
end

--- Deregisters a driver from a node.
-- @tparam Device node The node to modify
-- @tparam Driver driver The driver to remove
-- @treturn boolean Whether the operation succeeded
-- @treturn string? An error message if it failed
function hardware.deregister(node, driver)
    expect(1, node, "table")
    expect(2, driver, "table")
    expect.field(node, "uuid", "string")
    if not deviceUUIDs[node.uuid] then error("bad argument #1 (invalid node)", 2) end
    for i, v in ipairs(node.drivers) do if v == driver then
        if driver.deinit then driver.deinit(node) end
        table.remove(node.drivers, i)
        syslog.log({module = "Hardware"}, "Driver " .. driver.name .. " has been deregistered from device " .. hardware.path(node))
        return true
    end end
    return false
end

--- Adds a function that is called when either a parent node or pattern matches on a new node.
-- @tparam function callback A function that is called with a node when the pattern matches
-- @tparam[opt] Device parent A parent node to watch on
-- @tparam[opt] string pattern A Lua pattern to match on the device name
function hardware.listen(callback, parent, pattern)
    expect(1, callback, "function")
    expect(2, parent, "table", "nil")
    expect(3, pattern, "string", "nil")
    if parent then expect.field(parent, "uuid", "string") end
    if pattern and not pcall(string.match, "", pattern) then error("bad argument #3 (invalid pattern)", 2) end
    deviceListeners[#deviceListeners+1] = {callback = callback, parent = parent, pattern = pattern}
end

--- Removes a listener callback from the listener list.
-- @tparam function callback The function to remove
function hardware.unlisten(callback)
    expect(1, callback, "function")
    local i = 1
    while i < #deviceListeners do
        if deviceListeners[i].callback == callback then table.remove(deviceListeners, i)
        else i = i + 1 end
    end
end

--- Broadcasts an event to all processes listening to events on a node.
-- @tparam Device node The node to broadcast for
-- @tparam string event The event to broadcast
-- @tparam table param The parameters to pass for the event
function hardware.broadcast(node, event, param)
    expect(1, node, "table")
    expect(2, event, "string")
    expect(3, param, "table")
    expect.field(node, "uuid", "string")
    if not deviceUUIDs[node.uuid] then error("bad argument #1 (invalid node)", 2) end
    for v in pairs(node.listeners) do v.eventQueue[#v.eventQueue+1] = {event, param} end
end

--- Calls a method on a device.
-- @tparam Process process The process to run as
-- @tparam Device node The node to call on
-- @tparam string method The method to call
-- @tparam any ... Any arguments to pass
-- @treturn any... Any return values from the method
function hardware.call(process, node, method, ...)
    for _, driver in ipairs(node.drivers) do if driver.methods[method] then return driver.methods[method](node, process, ...) end end
    error("No such method", 2)
end

-- Syscalls

function syscalls.devlookup(process, thread, name)
    expect(1, name, "string")
    local dev = {hardware.get(name)}
    for k, v in ipairs(dev) do dev[k] = hardware.path(v) end
    return table.unpack(dev)
end

function syscalls.devfind(process, thread, type)
    expect(1, type, "string")
    local dev = {hardware.find(type)}
    for k, v in ipairs(dev) do dev[k] = hardware.path(v) end
    return table.unpack(dev)
end

function syscalls.devinfo(process, thread, device)
    expect(1, device, "string")
    local node = hardware.get(device)
    if not node then return nil end
    local types = {}
    for _, v in ipairs(node.drivers) do types[v.type] = v.name end
    return {
        id = node.id,
        uuid = node.uuid,
        alias = node.alias,
        parent = node.parent and hardware.path(node.parent) or "/",
        displayName = node.displayName,
        types = types,
        metadata = deepcopy(node.metadata)
    }
end

function syscalls.devalias(process, thread, device, alias)
    expect(1, device, "string")
    expect(2, alias, "string", "nil")
    local node = hardware.get(device)
    if not node then error("No such device", 2) end
    node.alias = alias
end

function syscalls.devmethods(process, thread, device)
    expect(1, device, "string")
    local node = hardware.get(device)
    if not node then error("No such device", 2) end
    local methods = {}
    for _, v in ipairs(node.drivers) do for k in pairs(v.methods) do methods[#methods+1] = k end end
    return methods
end

function syscalls.devproperties(process, thread, device)
    expect(1, device, "string")
    local node = hardware.get(device)
    if not node then error("No such device", 2) end
    local properties = {}
    for _, v in ipairs(node.drivers) do for _, k in pairs(v.properties) do properties[#properties+1] = k end end
    return properties
end

function syscalls.devchildren(process, thread, device)
    expect(1, device, "string")
    local node = hardware.get(device)
    if not node then error("No such device", 2) end
    local children = {}
    for k in pairs(node.children) do children[#children+1] = k end
    return children
end

function syscalls.devcall(process, thread, device, method, ...)
    expect(1, device, "string")
    expect(2, method, "string")
    local node = hardware.get(device)
    if not node then error("No such device", 2) end
    if node.process and node.process ~= process.id then error("Device is locked", 2) end
    return hardware.call(process, node, method, ...)
end

function syscalls.devlisten(process, thread, device, state)
    expect(1, device, "string")
    expect(2, state, "boolean", "nil")
    if state == nil then state = true end
    local node = hardware.get(device)
    if not node then error("No such device", 2) end
    if state then
        for _, v in ipairs(node.listeners) do if v == process then return end end
        node.listeners[process] = true
        process.dependents[#process.dependents+1] = {type = "hardware listen", node = node, gc = function() node.listeners[process] = nil end}
    else
        node.listeners[process] = nil
        for i, v in ipairs(process.dependents) do if v.type == "hardware listen" and v.node == node then table.remove(process.dependents, i) break end end
    end
end

function syscalls.devlock(process, thread, device, wait)
    expect(1, device, "string")
    expect(2, wait, "boolean", "nil")
    if wait == nil then wait = true end
    local node = hardware.get(device)
    if not node then error("No such device", 2) end
    if node.process == nil then
        node.process = process.id
        process.dependents[#process.dependents+1] = {type = "hardware lock", node = node, gc = function() node.process = nil end}
        return true
    elseif node.process == process.id then
        return true
    elseif wait then
        thread.filter = function(process, thread)
            return node.process == nil or node.process == process.id
        end
        return kSyscallYield, "devlock", device, true
    else return false end
end

function syscalls.devunlock(process, thread, device)
    expect(1, device, "string")
    local node = hardware.get(device)
    if not node then error("No such device", 2) end
    if node.process and node.process ~= process.id then error("Device is locked", 2) end
    node.process = nil
    for i, v in ipairs(process.dependents) do if v.type == "hardware lock" and v.node == node then table.remove(process.dependents, i) break end end
end

function syscalls.version(process, thread, buildnum)
    if buildnum then return PHOENIX_BUILD
    else return PHOENIX_VERSION end
end

function syscalls.cchost(process, thread)
    return _HOST
end

function syscalls.uptime(process, thread)
    return (os.epoch "utc" - systemStartTime) / 1000
end

-- TODO: temporary?
function syscalls.serialize(process, thread, value)
    return serialize(value)
end

--#endregion

--#region 45-atomics.lua

local nextMutexID = 0

function syscalls.lockmutex(process, thread, mtx)
    expect(1, mtx, "table")
    if mtx.owner then
        if mtx.owner ~= thread.id then
            thread.filter = function(process, thread)
                return mtx.owner == nil or mtx.owner == thread.id
            end
            return kSyscallYield, "lockmutex", mtx
        elseif type(mtx.recursive) == "number" then
            mtx.recursive = mtx.recursive + 1
        else error("cannot recursively lock mutex", 0) end
    else
        mtx.owner = thread.id
        if mtx.recursive then mtx.recursive = 1 end
    end
end

function syscalls.__timeout_check(process, thread, info)
    if info.timeout then return false end
    return syscalls[info.call](process, thread, info.object, 0)
end

function syscalls.timelockmutex(process, thread, mtx, timeout)
    expect(1, mtx, "table")
    expect(2, timeout, "number")
    if mtx.owner then
        if mtx.owner ~= thread.id then
            local timer = os.startTimer(timeout)
            local info = {object = mtx, timeout = false, call = "timelockmutex"}
            thread.filter = function(process, thread, ev)
                if ev[1] == "timer" and ev[2].id == timer then
                    info.timeout = true
                    return true
                end
                return mtx.owner == nil or mtx.owner == thread.id
            end
            return kSyscallYield, "__timeout_check", info
        elseif type(mtx.recursive) == "number" then
            mtx.recursive = mtx.recursive + 1
        else error("cannot recursively lock mutex", 0) end
    else
        mtx.owner = thread.id
        if mtx.recursive then mtx.recursive = 1 end
    end
    return true
end

function syscalls.unlockmutex(process, thread, mtx)
    expect(1, mtx, "table")
    if mtx.owner == thread.id then
        if type(mtx.recursive) == "number" then
            mtx.recursive = mtx.recursive - 1
            if mtx.recursive <= 0 then mtx.owner = nil end
        else mtx.owner = nil end
    elseif mtx.owner == nil then error("mutex already unlocked", 0)
    else error("mutex not locked by current thread") end
end

function syscalls.trylockmutex(process, thread, mtx)
    expect(1, mtx, "table")
    if mtx.owner then
        if mtx.owner ~= process.id then
            return false
        elseif type(mtx.recursive) == "number" then
            mtx.recursive = mtx.recursive + 1
            return true
        else error("cannot recursively lock mutex", 0) end
    else
        mtx.owner = process.id
        if mtx.recursive then mtx.recursive = 1 end
        return true
    end
end

function syscalls.acquiresemaphore(process, thread, sem)
    expect(1, sem, "table")
    expect.field(sem, "count", "number")
    if sem.count <= 0 then
        thread.filter = function(process, thread)
            return type(sem.count) ~= "number" or sem.count > 0
        end
        return kSyscallYield, "acquiresemaphore", sem
    end
    sem.count = sem.count - 1
end

function syscalls.timeacquiresemaphore(process, thread, sem, timeout)
    expect(1, sem, "table")
    expect.field(sem, "count", "number")
    expect(2, timeout, "number")
    if sem.count <= 0 then
        local timer = os.startTimer(timeout)
        local info = {object = sem, timeout = false, call = "timeacquiresemaphore"}
        thread.filter = function(process, thread, ev)
            if ev[1] == "timer" and ev[2].id == timer then
                info.timeout = true
                return true
            end
            return type(sem.count) ~= "number" or sem.count > 0
        end
        return kSyscallYield, "__timeout_check", info
    end
    sem.count = sem.count - 1
    return true
end

function syscalls.releasesemaphore(process, thread, sem)
    expect(1, sem, "table")
    expect.field(sem, "count", "number")
    sem.count = sem.count + 1
end

--#endregion

--#region 55-drivers.lua

local driverTemplate = {
    name = "root",
    type = "computer",
    properties = {
        "label",
        "id"
    },
    methods = {
        getLabel = function() end,
        setLabel = function(label) end,
        getId = function() end,
        shutdown = function() end,
        reboot = function() end
    },
    init = function(node)
        -- initialize node
    end,
    deinit = function(node)
        -- deinitialize node
    end
}

local localPeripherals = {top = true, bottom = true, left = true, right = true, front = true, back = true}

local drivers = {}

function getNodeById(name)
    if localPeripherals[name] then
        if deviceTreeRoot.children[name] then
            return deviceTreeRoot.children[name]
        end
    else
        -- We don't know the parent of this peripheral, so we have to traverse all modems :(
        for k in pairs(localPeripherals) do
            if peripheral.getType(k) == "modem" and not peripheral.call(k, "isWireless") and deviceTreeRoot.children[k] and deviceTreeRoot.children[k].children[name] then
                return deviceTreeRoot.children[k].children[name]
            end
        end
    end
end

local function checkCall(self)
    self.internalState.peripheral = self.internalState.peripheral or {}
    if not self.internalState.peripheral.call then self.internalState.peripheral.call = peripheral.call end
    if self.internalState.peripheral.call == peripheral.call or not self.parent then
        self.internalState.peripheral.getMethods = peripheral.getMethods
    else
        self.internalState.peripheral.getMethods = function(id) return peripheral.call(self.parent.id, "getMethodsRemote", id) end
    end
end

local function shadowTable(process, mt)
    mt.__metatable = {}
    for _, v in pairs(mt) do
        setfenv(v, process.env)
        debug.protect(v)
    end
    return setmetatable({}, mt)
end

local function peripheralTypeCallback(driver, type)
    return function(node)
        local types, fn
        if node.parent == deviceTreeRoot then types, fn = {peripheral.getType(node.id)}, peripheral.call
        else types, fn = {peripheral.call(node.parent.id, "getTypeRemote", node.id)}, function(...) return peripheral.call(node.parent.id, "callRemote", node.id, ...) end end
        for _, v in ipairs(types) do if v == type then node.internalState.peripheral = {call = fn} return hardware.register(node, driver) end end
    end
end

local function register(type)
    return hardware.listen(peripheralTypeCallback(drivers["peripheral_" .. type], type), deviceTreeRoot)
end

local function noArgMethod(method)
    return function(self)
        return self.internalState.peripheral.call(self.id, method)
    end
end

local function noArgRootMethod(method)
    return function(self, process)
        if process.user ~= "root" then error("Permission denied", 0) end
        return self.internalState.peripheral.call(self.id, method)
    end
end

local function oneArgMethod(method)
    return function(...)
        local types = {...}
        return function(self, process, value)
            expect(1, value, table.unpack(types))
            return self.internalState.peripheral.call(self.id, method, value)
        end
    end
end

local function oneArgRootMethod(method)
    return function(...)
        local types = {...}
        return function(self, process, value)
            expect(1, value, table.unpack(types))
            if process.user ~= "root" then error("Permission denied", 0) end
            return self.internalState.peripheral.call(self.id, method, value)
        end
    end
end

--#region Root driver

local function killall()
    syslog.log("Sending SIGTERM to all processes")
    local living = false
    for pid, process in pairs(processes) do if pid ~= 0 then
        syscalls.kill(KERNEL, nil, pid, 15)
        local gotev, ev = false, nil
        local dead = true
        for tid, thread in pairs(process.threads) do
            if not gotev and thread.status == "suspended" then
                ev = table.remove(process.eventQueue, 1) -- TODO: decide whether to optimize this
                gotev = true
            end
            if ev or thread.status ~= "suspended" then dead = executeThread(process, thread, ev or {n = 0}, dead, true)
            else dead = false end
        end
        if dead then
            process.isDead = true
            if process.parent ~= 0 and processes[process.parent] then
                processes[process.parent].eventQueue[#processes[process.parent].eventQueue+1] = {"process_complete", process.lastReturnValue}
            end
            reap_process(process)
            processes[pid] = nil
        else living = true end
    end end
    terminal.redraw(currentTTY)
    if living then
        syslog.log("Sending SIGKILL to all processes")
        for pid in pairs(processes) do if pid ~= 0 then syscalls.kill(KERNEL, nil, pid, 9) end end
    end
end

drivers.root = {
    name = "root",
    type = "computer",
    properties = {
        "isOn",
        "label"
    },
    methods = {}
}

function drivers.root.methods:getIsOn(process)
    return true
end

function drivers.root.methods:getLabel(process)
    return os.getComputerLabel()
end

function drivers.root.methods:setLabel(process, label)
    expect(1, label, "string", "nil")
    os.setComputerLabel(label)
end

function drivers.root.methods:turnOn(process) end -- do nothing

function drivers.root.methods:shutdown(process)
    if process.user ~= "root" then error("Permission denied", 2) end
    syslog.log("System is shutting down.")
    killall()
    hardware.deregister(deviceTreeRoot, drivers.root)
    os.shutdown()
    while true do coroutine.yield() end
end

function drivers.root.methods:reboot(process)
    if process.user ~= "root" then error("Permission denied", 2) end
    syslog.log("System is restarting.")
    killall()
    hardware.deregister(deviceTreeRoot, drivers.root)
    os.reboot()
    while true do coroutine.yield() end
end

function drivers.root:init()
    local rsdev = hardware.add(self, "redstone")
    for _, v in ipairs{"top", "bottom", "left", "right", "front", "back"} do
        local d = hardware.add(rsdev, v)
        d.internalState.redstone = {side = v}
        hardware.register(d, drivers.root_redstone)
    end
    hardware.register(hardware.add(deviceTreeRoot, "lo"), drivers.loopback_modem)
    registerLoopback()
    for v in pairs(localPeripherals) do
        if peripheral.isPresent(v) then
            hardware.add(self, v)
        end
    end
    self.displayName = os.getComputerLabel()
    self.metadata.id = os.getComputerID()
end

function drivers.root:deinit()
    for v in pairs(localPeripherals) do
        if peripheral.isPresent(v) and self.children[v] then
            hardware.remove(self.children[v])
        end
    end
    hardware.remove(hardware.get("/lo"))
    hardware.remove(hardware.get("/redstone"))
end

eventHooks.peripheral = eventHooks.peripheral or {}
eventHooks.peripheral[#eventHooks.peripheral+1] = function(ev)
    if localPeripherals[ev[2]] then
        local node, err = hardware.add(deviceTreeRoot, ev[2])
        if node then hardware.broadcast(deviceTreeRoot, "device_added", {device = hardware.path(node)})
        else syslog.log({level = "error", module = "Hardware"}, "Could not create new device: " .. err) end
    else
        -- We don't know the parent of this peripheral, so we have to traverse all modems :(
        for k in pairs(localPeripherals) do
            if peripheral.getType(k) == "modem" and not peripheral.call(k, "isWireless") and peripheral.call(k, "isPresentRemote", ev[2]) then
                if not deviceTreeRoot.children[k] then hardware.add(deviceTreeRoot, k) end
                local node, err = hardware.add(deviceTreeRoot.children[k], ev[2])
                if node then hardware.broadcast(deviceTreeRoot.children[k], "device_added", {device = hardware.path(node)})
                else syslog.log({level = "error", module = "Hardware"}, "Could not create new device: " .. err) end
                break
            end
        end
    end
end

eventHooks.peripheral_detach = eventHooks.peripheral_detach or {}
eventHooks.peripheral_detach[#eventHooks.peripheral_detach+1] = function(ev)
    local node = getNodeById(ev[2])
    if not node then
        syslog.log({level = "notice", module = "Hardware"}, "Received " .. ev[1] .. " event for device ID " .. ev[2] .. ", but no device node was found; ignoring")
        return
    end
    local path, parent = hardware.path(node), node.parent
    hardware.remove(node)
    hardware.broadcast(parent, "device_removed", {device = path})
end

rootDriver = drivers.root

--#endregion
--#region Redstone driver

drivers.root_redstone = {
    name = "root_redstone",
    type = "redstone",
    properties = {
        "input",
        "output",
        "bundledInput",
        "bundledOutput"
    },
    methods = {}
}

local function zeronil(n) if n == 0 then return nil else return n end end

function drivers.root_redstone.methods:getInput() return zeronil(redstone.getAnalogInput(self.internalState.redstone.side)) end
function drivers.root_redstone.methods:getOutput() return zeronil(redstone.getAnalogOutput(self.internalState.redstone.side)) end
function drivers.root_redstone.methods:setOutput(process, n) n = expect(1, n, "number", "nil") or 0 expect.range(n, 0, 15) redstone.setAnalogOutput(self.internalState.redstone.side, n) end
function drivers.root_redstone.methods:getBundledInput() return redstone.getBundledInput(self.internalState.redstone.side) end
function drivers.root_redstone.methods:getBundledOutput() return redstone.getBundledOutput(self.internalState.redstone.side) end
function drivers.root_redstone.methods:setBundledOutput(process, n) expect(1, n, "number") expect.range(n, 0, 65535) redstone.setBundledOutput(self.internalState.redstone.side, n) end

function drivers.root_redstone:init()
    if not self.internalState.redstone or not self.internalState.redstone.side then error("No assigned side on redstone device!", 2) end
    self.displayName = "Redstone I/O on side " .. self.internalState.redstone.side
end

--#endregion
--#region Command block peripheral

drivers.peripheral_command = {
    name = "peripheral_command",
    type = "command",
    properties = {
        "command"
    },
    methods = {}
}

drivers.peripheral_command.methods.getCommand = noArgRootMethod "getCommand"
drivers.peripheral_command.methods.setCommand = oneArgRootMethod "setCommand" ("string")
drivers.peripheral_command.methods.run = noArgRootMethod "runCommand"

function drivers.peripheral_command:init()
    checkCall(self)
    self.displayName = "Command block at " .. self.id
end

register "command"

--#endregion
--#region Computer peripheral

drivers.peripheral_computer = {
    name = "peripheral_computer",
    type = "computer",
    properties = {
        "isOn",
        "label"
    },
    methods = {}
}

drivers.peripheral_computer.methods.getIsOn = noArgMethod "isOn"
drivers.peripheral_computer.methods.getLabel = noArgMethod "getLabel"
drivers.peripheral_computer.methods.turnOn = noArgRootMethod "turnOn"
drivers.peripheral_computer.methods.shutdown = noArgRootMethod "shutdown"
drivers.peripheral_computer.methods.reboot = noArgRootMethod "reboot"

function drivers.peripheral_command:init()
    checkCall(self)
    local label = self.internalState.peripheral.call(self.id, "getLabel")
    self.metadata.id = self.internalState.peripheral.call(self.id, "getID")
    self.displayName = (label or ("Computer " .. self.metadata.id)) .. " at " .. self.id
end

register "computer"
hardware.listen(peripheralTypeCallback(drivers["peripheral_computer"], "turtle"), deviceTreeRoot)


--#endregion
--#region Disk drive peripheral

drivers.peripheral_drive = {
    name = "peripheral_drive",
    type = "drive",
    properties = {
        "state"
    },
    methods = {}
}

function drivers.peripheral_drive.methods:getState(process)
    if not self.internalState.peripheral.call(self.id, "isDiskPresent") then return nil end
    return {
        audio = self.internalState.peripheral.call(self.id, "getAudioTitle") or nil,
        label = self.internalState.peripheral.call(self.id, "getDiskLabel"),
        id = self.internalState.peripheral.call(self.id, "getDiskID")
    }
end

drivers.peripheral_drive.methods.setLabel = oneArgMethod "setDiskLabel" ("string", "nil")

function drivers.peripheral_drive.methods:play(process)
    if not self.internalState.peripheral.call(self.id, "hasAudio") then error("Inserted disk is not an audio disc", 2) end
    return self.internalState.peripheral.call(self.id, "playAudio")
end

drivers.peripheral_drive.methods.stop = noArgMethod "stopAudio"
drivers.peripheral_drive.methods.eject = noArgMethod "ejectDisk"
drivers.peripheral_drive.methods.insert = oneArgRootMethod "insertDisk" ("string")

function drivers.peripheral_drive:init()
    checkCall(self)
    self.displayName = (peripheral.call(self.id, "getDiskLabel") or "No disk") .. " on drive " .. self.id
end

register "device"

eventHooks.disk = eventHooks.disk or {}
eventHooks.disk[#eventHooks.disk+1] = function(ev)
    local node = getNodeById(ev[2])
    if not node then
        syslog.log({level = "notice", module = "Hardware"}, "Received " .. ev[1] .. " event for device ID " .. ev[2] .. ", but no device node was found; ignoring")
        return
    end
    hardware.broadcast(node, "disk", {device = hardware.path(node)})
end

eventHooks.disk_eject = eventHooks.disk_eject or {}
eventHooks.disk_eject[#eventHooks.disk_eject+1] = function(ev)
    local node = getNodeById(ev[2])
    if not node then
        syslog.log({level = "notice", module = "Hardware"}, "Received " .. ev[1] .. " event for device ID " .. ev[2] .. ", but no device node was found; ignoring")
        return
    end
    hardware.broadcast(node, "disk_eject", {device = hardware.path(node)})
end

--#endregion
--#region Generic energy storage peripheral

drivers.peripheral_energy_storage = {
    name = "peripheral_energy_storage",
    type = "energy_storage",
    properties = {
        "energy"
    },
    methods = {}
}

drivers.peripheral_energy_storage.methods.getEnergy = noArgMethod "getEnergy"

function drivers.peripheral_energy_storage:init()
    checkCall(self)
    self.displayName = "Energy storage block at " .. self.id
    self.metadata.capacity = self.internalState.peripheral.call(self.id, "getEnergyCapacity")
end

register "energy_storage"

--#endregion
--#region Generic fluid storage peripheral

drivers.peripheral_fluid_storage = {
    name = "peripheral_fluid_storage",
    type = "fluid_storage",
    properties = {
        "tanks"
    },
    methods = {}
}

drivers.peripheral_fluid_storage.methods.getTanks = noArgMethod "tanks"

function drivers.peripheral_fluid_storage.methods:push(process, to, limit, name)
    expect(1, to, "string")
    expect(2, limit, "number", "nil")
    expect(3, name, "string", "nil")
    local target
    local targets = {hardware.get(to)}
    if #targets == 1 then target = targets[1]
    else for _, v in ipairs(targets) do if v.parent == self.parent then target = v break end end end
    if not target then error("No such device", 0)
    elseif target.parent ~= self.parent then error("Devices must be on the same network", 0) end
    local ok = false
    for _, v in ipairs(target.drivers) do if v == drivers.peripheral_fluid_storage then ok = true break end end
    if not ok then error("Target device is not a fluid storage block", 0) end
    return self.internalState.peripheral.call(self.id, "pushFluid", target.id, limit, name)
end

function drivers.peripheral_fluid_storage.methods:pull(process, from, limit, name)
    expect(1, from, "string")
    expect(2, limit, "number", "nil")
    expect(3, name, "string", "nil")
    local target
    local targets = {hardware.get(from)}
    if #targets == 1 then target = targets[1]
    else for _, v in ipairs(targets) do if v.parent == self.parent then target = v break end end end
    if not target then error("No such device", 0)
    elseif target.parent ~= self.parent then error("Devices must be on the same network", 0) end
    local ok = false
    for _, v in ipairs(target.drivers) do if v == drivers.peripheral_fluid_storage then ok = true break end end
    if not ok then error("Target device is not a fluid storage block", 0) end
    return self.internalState.peripheral.call(self.id, "pullFluid", target.id, limit, name)
end

function drivers.peripheral_fluid_storage:init()
    checkCall(self)
    self.displayName = "Fluid storage block at " .. self.id
end

register "fluid_storage"

--#endregion
--#region Generic inventory peripheral

drivers.peripheral_inventory = {
    name = "peripheral_inventory",
    type = "inventory",
    properties = {
        "items"
    },
    methods = {}
}

drivers.peripheral_inventory.methods.getItems = noArgMethod "list"
drivers.peripheral_inventory.methods.detail = oneArgMethod "getItemDetail" ("number")
drivers.peripheral_inventory.methods.limit = oneArgMethod "getItemLimit" ("number")

function drivers.peripheral_inventory.methods:push(process, to, slot, limit, toSlot)
    expect(1, to, "string")
    expect(2, slot, "number")
    expect(3, limit, "number", "nil")
    expect(4, toSlot, "number", "nil")
    local target
    local targets = {hardware.get(to)}
    if #targets == 1 then target = targets[1]
    else for _, v in ipairs(targets) do if v.parent == self.parent then target = v break end end end
    if not target then error("No such device", 0)
    elseif target.parent ~= self.parent then error("Devices must be on the same network", 0) end
    local ok = false
    for _, v in ipairs(target.drivers) do if v == drivers.peripheral_inventory then ok = true break end end
    if not ok then error("Target device is not an inventory block", 0) end
    return self.internalState.peripheral.call(self.id, "pushItems", target.id, slot, limit, toSlot)
end

function drivers.peripheral_inventory.methods:pull(process, from, slot, limit, toSlot)
    expect(1, from, "string")
    expect(2, slot, "number")
    expect(3, limit, "number", "nil")
    expect(4, toSlot, "number", "nil")
    local target
    local targets = {hardware.get(from)}
    if #targets == 1 then target = targets[1]
    else for _, v in ipairs(targets) do if v.parent == self.parent then target = v break end end end
    if not target then error("No such device", 0)
    elseif target.parent ~= self.parent then error("Devices must be on the same network", 0) end
    local ok = false
    for _, v in ipairs(target.drivers) do if v == drivers.peripheral_inventory then ok = true break end end
    if not ok then error("Target device is not an inventory block", 0) end
    return self.internalState.peripheral.call(self.id, "pullItems", target.id, slot, limit, toSlot)
end

function drivers.peripheral_inventory:init()
    checkCall(self)
    self.displayName = "Inventory at " .. self.id
    self.metadata.size = self.internalState.peripheral.call(self.id, "size")
end

register "inventory"

--#endregion
--#region Monitor peripheral

drivers.peripheral_monitor = {
    name = "peripheral_monitor",
    type = "monitor",
    properties = {
        "scale",
        "size"
    },
    methods = {}
}

drivers.peripheral_monitor.methods.getScale = noArgMethod "getTextScale"
drivers.peripheral_monitor.methods.setScale = oneArgMethod "setTextScale" ("number")

function drivers.peripheral_monitor.methods:getSize()
    local w, h = self.internalState.peripheral.call(self.id, "getSize")
    return {width = w, height = h}
end

function drivers.peripheral_monitor.methods:write(process, ...)
    for i, v in ipairs{...} do
        if i > 1 then terminal.write(self.internalState.tty, "\t") end
        terminal.write(self.internalState.tty, v)
    end
    terminal.redraw(self.internalState.tty)
end

function drivers.peripheral_monitor.methods:termctl(process, flags)
    expect(1, flags, "table", "nil")
    if flags then
        expect.field(flags, "cbreak", "boolean", "nil")
        expect.field(flags, "delay", "boolean", "nil")
        expect.field(flags, "echo", "boolean", "nil")
        expect.field(flags, "keypad", "boolean", "nil")
        expect.field(flags, "nlcr", "boolean", "nil")
        expect.field(flags, "raw", "boolean", "nil")
        for k, v in pairs(flags) do if self.internalState.tty.flags[k] ~= nil then self.internalState.tty.flags[k] = v end end
    end
    local t = deepcopy(self.internalState.tty.flags)
    t.hasgfx = term.getGraphicsMode ~= nil
    return t
end

function drivers.peripheral_monitor.methods:openterm(process)
    return terminal.openterm(self.internalState.tty, process)
end

function drivers.peripheral_monitor.methods:opengfx(process)
    return terminal.opengfx(self.internalState.tty, process)
end

function drivers.peripheral_monitor:init()
    checkCall(self)
    local w, h = self.internalState.peripheral.call(self.id, "getSize")
    local scale = self.internalState.peripheral.call(self.id, "getTextScale")
    self.displayName = (w * scale) .. "x" .. (h * scale) .. " monitor at " .. self.id
    local term = {}
    for _, v in ipairs(self.internalState.peripheral.getMethods(self.id)) do
        term[v] = function(...) return self.internalState.peripheral.call(self.id, v, ...) end
    end
    self.internalState.tty = terminal.makeTTY(term, w, h)
    self.internalState.tty.isMonitor = true
    terminal.redraw(self.internalState.tty, true)
end

function drivers.peripheral_monitor:deinit()
    local tty = self.internalState.tty
    if tty.frontmostProcess then
        local v = tty.frontmostProcess
        if v.stdin == tty then v.stdin = nil end
        if v.stdout == tty then v.stdout = nil end
        if v.stderr == tty then v.stderr = nil end
    end
    for _, v in ipairs(tty.processList) do
        if v.stdin == tty then v.stdin = nil end
        if v.stdout == tty then v.stdout = nil end
        if v.stderr == tty then v.stderr = nil end
    end
end

register "monitor"

eventHooks.monitor_resize = eventHooks.monitor_resize or {}
eventHooks.monitor_resize[#eventHooks.monitor_resize+1] = function(ev)
    local node = getNodeById(ev[2])
    if not node then
        syslog.log({level = "notice", module = "Hardware"}, "Received " .. ev[1] .. " event for device ID " .. ev[2] .. ", but no device node was found; ignoring")
        return
    end
    local w, h = drivers.peripheral_monitor.methods.getSize(node)
    terminal.resize(node.internalState.tty, w, h)
    hardware.broadcast(node, "monitor_resize", {device = hardware.path(node), width = w, height = h})
end

-- TODO: monitor_touch/mouse event handling

--#endregion
--#region Printer peripheral

drivers.peripheral_printer = {
    name = "peripheral_printer",
    type = "printer",
    properties = {
        "inkLevel",
        "paperLevel"
    },
    methods = {}
}

drivers.peripheral_printer.methods.getInkLevel = noArgMethod "getInkLevel"
drivers.peripheral_printer.methods.getPaperLevel = noArgMethod "getPaperLevel"

-- This is most definitely overengineered
function drivers.peripheral_printer.methods:page(process)
    if self.internalState.printer.open then
        self.internalState.peripheral.call(self.id, "endPage")
        self.internalState.printer.open = false
    end
    if not self.internalState.peripheral.call(self.id, "newPage") then return nil end
    self.internalState.printer.open = true
    local title, x, y
    local function write(...)
        if not self.internalState.printer.open then error("attempt to use closed page", 2) end
        return self.internalState.peripheral.call(self.id, "write", ...)
    end
    local function close()
        if not self.internalState.printer.open then return true end
        if not self.internalState.peripheral.call(self.id, "endPage") then return false end
        self.internalState.printer.open = false
    end
    setfenv(write, process.env)
    setfenv(close, process.env)
    debug.protect(write)
    debug.protect(close)
    return shadowTable(process, {
        __index = function(_, idx)
            if not self.internalState.printer.open then error("attempt to use closed page", 2) end
            if idx == "size" then
                local width, height = self.internalState.peripheral.call(self.id, "getPageSize")
                return shadowTable(process, {
                    __index = function(_, idx)
                        if idx == "width" then return width
                        elseif idx == "height" then return height end
                    end,
                    __newindex = function()
                        error("Cannot modify read-only table", 2)
                    end
                })
            elseif idx == "cursor" then
                x, y = self.internalState.peripheral.call(self.id, "getCursorPos")
                return shadowTable(process, {
                    __index = function(_, idx)
                        if idx == "x" then return x
                        elseif idx == "y" then return y end
                    end,
                    __newindex = function(_, idx, val)
                        if idx == "x" then
                            x = val
                            self.internalState.peripheral.call(self.id, "setCursorPos", x, y)
                        elseif idx == "y" then
                            y = val
                            self.internalState.peripheral.call(self.id, "setCursorPos", x, y)
                        else error("Cannot modify member '" .. idx .. "'", 2) end
                    end
                })
            elseif idx == "title" then return title
            elseif idx == "isOpen" then return self.internalState.printer.open
            elseif idx == "write" then return write
            elseif idx == "close" then return close end
        end,
        __newindex = function(_, idx, val)
            if not self.internalState.printer.open then error("attempt to use closed page", 2) end
            if idx == "cursor" then
                if type(val) ~= "table" then error("bad value for 'cursor' (expected table, got " .. type(val) .. ")", 2) end
                expect.field(val, "x", "number")
                expect.field(val, "y", "number")
                x, y = val.x, val.y
                self.internalState.peripheral.call(self.id, "setCursorPos", x, y)
            elseif idx == "title" then
                if type(val) ~= "string" and val ~= nil then error("bad value for 'title' (expected string, got " .. type(val) .. ")", 2) end
                title = val
                self.internalState.peripheral.call(self.id, "setPageTitle", title)
            else error("Cannot modify member '" .. idx .. "'", 2) end
        end
    })
end

function drivers.peripheral_printer:init()
    checkCall(self)
    self.displayName = "Speaker at " .. self.id
    self.internalState.printer = {open = false}
end

register "printer"

--#endregion
--#region Speaker peripheral

drivers.peripheral_speaker = {
    name = "peripheral_speaker",
    type = "speaker",
    properties = {},
    methods = {}
}

function drivers.peripheral_speaker.methods:playNote(process, instrument, volume, pitch)
    expect(1, instrument, "string")
    expect(2, volume, "number", "nil")
    expect(3, pitch, "number", "nil")
    if volume then expect.range(volume, 0, 3) end
    if pitch then expect.range(pitch, 0, 24) end
    return self.internalState.peripheral.call(self.id, "playNote", instrument, volume, pitch)
end

function drivers.peripheral_speaker.methods:playSound(process, name, volume, speed)
    expect(1, name, "string")
    expect(2, volume, "number", "nil")
    expect(3, speed, "number", "nil")
    if volume then expect.range(volume, 0, 3) end
    if speed then expect.range(speed, 0.5, 2.0) end
    return self.internalState.peripheral.call(self.id, "playNote", name, volume, speed)
end

function drivers.peripheral_speaker.methods:playAudio(audio, volume)
    expect(1, audio, "table")
    expect(2, volume, "number", "nil")
    if volume then expect.range(volume, 0, 3) end
    return self.internalState.peripheral.call(self.id, "playAudio", audio, volume)
end

drivers.peripheral_speaker.methods.stop = noArgMethod "stop"

function drivers.peripheral_command:init()
    checkCall(self)
    self.displayName = "Speaker at " .. self.id
end

register "speaker"

eventHooks.speaker_audio_empty = eventHooks.speaker_audio_empty or {}
eventHooks.speaker_audio_empty[#eventHooks.speaker_audio_empty+1] = function(ev)
    local node = getNodeById(ev[2])
    if not node then
        syslog.log({level = "notice", module = "Hardware"}, "Received " .. ev[1] .. " event for device ID " .. ev[2] .. ", but no device node was found; ignoring")
        return
    end
    hardware.broadcast(node, "speaker_audio_empty", {device = hardware.path(node)})
end

--#endregion
--#region Modem peripheral

local peripheralDrivers = {
    drivers.peripheral_command, drivers.peripheral_computer,
    drivers.peripheral_drive, drivers.peripheral_energy_storage,
    drivers.peripheral_fluid_storage, drivers.peripheral_inventory,
    drivers.peripheral_monitor, drivers.peripheral_printer,
    drivers.peripheral_speaker
}

drivers.peripheral_modem = {
    name = "peripheral_modem",
    type = "modem",
    properties = {
        "remainingChannels"
    },
    methods = {}
}

function drivers.peripheral_modem.methods:getRemainingChannels()
    local num = 128
    for _ in pairs(self.internalState.modem) do num = num - 1 end
    return num
end

function drivers.peripheral_modem.methods:open(process, channel)
    if not self.internalState.modem[channel] then
        self.internalState.peripheral.call(self.id, "open", channel)
        self.internalState.modem[channel] = {}
    end
    self.internalState.modem[channel][process] = true
end

function drivers.peripheral_modem.methods:isOpen(process, channel)
    return self.internalState.modem[channel] and self.internalState.modem[channel][process]
end

function drivers.peripheral_modem.methods:close(process, channel)
    self.internalState.modem[channel][process] = nil
    if not next(self.internalState.modem[channel]) then
        self.internalState.peripheral.call(self.id, "close", channel)
        self.internalState.modem[channel] = nil
    end
end

function drivers.peripheral_modem.methods:closeAll(process)
    for channel = 0, 65535 do
        self.internalState.modem[channel][process] = nil
        if not next(self.internalState.modem[channel]) then
            self.internalState.peripheral.call(self.id, "close", channel)
            self.internalState.modem[channel] = nil
        end
    end
end

function drivers.peripheral_modem.methods:transmit(process, channel, replyChannel, payload)
    expect(1, channel, "number")
    replyChannel = expect(2, replyChannel, "number", "nil") or channel
    return self.internalState.peripheral.call(self.id, "transmit", channel, replyChannel, payload)
end

function drivers.peripheral_modem:init()
    checkCall(self)
    self.metadata.wireless = self.internalState.peripheral.call(self.id, "isWireless")
    self.displayName = (self.metadata.wireless and "Wireless" or "Wired") .. " modem at " .. self.id
    self.internalState.modem = {}
    self.internalState.modem.channels = {}
    self.internalState.peripheral.call(self.id, "closeAll")
    if not self.metadata.wireless then
        self.internalState.modem.callbacks = {}
        for _, v in ipairs(peripheralDrivers) do
            local f = peripheralTypeCallback(v, v.type)
            hardware.listen(f, self)
            self.internalState.modem.callbacks[#self.internalState.modem.callbacks+1] = f
        end
        local f = peripheralTypeCallback(drivers["peripheral_computer"], "turtle")
        hardware.listen(f, self)
        self.internalState.modem.callbacks[#self.internalState.modem.callbacks+1] = f
    end
end

function drivers.peripheral_modem:deinit()
    if not self.metadata.wireless then for _, v in ipairs(self.internalState.modem.callbacks) do hardware.unlisten(v) end end
end

register "modem"

eventHooks.modem_message = eventHooks.modem_message or {}
eventHooks.modem_message[#eventHooks.modem_message+1] = function(ev)
    local node = getNodeById(ev[2]) or hardware.get(ev[2])
    if not node then
        syslog.log({level = "notice", module = "Hardware"}, "Received " .. ev[1] .. " event for device ID " .. ev[2] .. ", but no device node was found; ignoring")
        return
    end
    local retval = false
    for v in pairs(node.listeners) do if node.internalState.modem[ev[3]][v] then v.eventQueue[#v.eventQueue+1], retval = {"modem_message", {device = hardware.path(node), channel = ev[3], replyChannel = ev[4], message = ev[5], distance = ev[6]}}, true end end
    return retval
end

--#endregion
--#region Loopback modem

drivers.loopback_modem = {
    name = "loopback_modem",
    type = "modem",
    properties = {
        "remainingChannels"
    },
    methods = {}
}

function drivers.loopback_modem.methods:getRemainingChannels()
    local num = 128
    for _ in pairs(self.internalState.modem) do num = num - 1 end
    return num
end

function drivers.loopback_modem.methods:open(process, channel)
    if not self.internalState.modem[channel] then
        self.internalState.modem[channel] = {}
    end
    self.internalState.modem[channel][process] = true
end

function drivers.loopback_modem.methods:isOpen(process, channel)
    return self.internalState.modem[channel] and self.internalState.modem[channel][process]
end

function drivers.loopback_modem.methods:close(process, channel)
    self.internalState.modem[channel][process] = nil
    if not next(self.internalState.modem[channel]) then
        self.internalState.modem[channel] = nil
    end
end

function drivers.loopback_modem.methods:closeAll(process)
    for channel = 0, 65535 do
        self.internalState.modem[channel][process] = nil
        if not next(self.internalState.modem[channel]) then
            self.internalState.modem[channel] = nil
        end
    end
end

function drivers.loopback_modem.methods:transmit(process, channel, replyChannel, payload)
    expect(1, channel, "number")
    replyChannel = expect(2, replyChannel, "number", "nil") or channel
    os.queueEvent("modem_message", self.uuid, channel, replyChannel, payload, 0)
end

function drivers.loopback_modem:init()
    self.metadata.wireless = true
    self.displayName = "Loopback modem"
    self.internalState.modem = {}
    self.internalState.modem.channels = {}
end

--#endregion


--#endregion

--#region 60-network.lua

-- TODO: fix user:password@domain URIs (uncommon but part of spec)
local function parseURI(uri)
    local info = {scheme = ""}
    for c in uri:gmatch "." do
        if info.fragment then
            if c:match "[%w%-%._~%%@:/!%$&'%(%)%*%+,;=/?]" then info.fragment = info.fragment .. c
            else error("Invalid URI", 3) end
        elseif info.query then
            if c == "#" then info.fragment = ""
            elseif c:match "[%w%-%._~%%@:/!%$&'%(%)%*%+,;=/?]" then info.query = info.query .. c
            else error("Invalid URI", 3) end
        elseif info.path then
            if c == "/" and info.path == "/" and not info.host then info.path, info.host = nil, ""
            elseif c == "?" then info.query = ""
            elseif c == "#" then info.fragment = ""
            elseif c:match "[%w%-%._~%%@:/!%$&'%(%)%*%+,;=/]" then info.path = info.path .. c
            else error("Invalid URI", 3) end
        elseif info.port then
            if tonumber(c) then info.port = info.port .. c
            elseif c == "/" then info.path = "/"
            else error("Invalid URI", 3) end
        elseif info.host then
            if c == "@" and not info.user then info.user, info.host = info.host, ""
            elseif c == ":" then info.port = ""
            elseif c == "/" then info.path = "/"
            elseif c:match "[%w%-%._~%%/!%$&'%(%)%*%+,;=]" then info.host = info.host .. c
            else error("Invalid URI", 3) end
        else
            if c == ":" then info.path = ""
            elseif c:match(info.scheme == "" and "[%a%+%-%.]" or "[%w%+%-%.]") then info.scheme = info.scheme .. c
            else error("Invalid URI", 3) end
        end
    end
    if info.port then info.port = tonumber(info.port) end
    return info
end

local function ipToNumber(ip)
    if ip:match "^%d+$" then return tonumber(ip)
    elseif ip:match "^%d+%.%d+$" then return tonumber(ip:match "^%d+") * 0x1000000 + tonumber(ip:match "^%d+%.(%d+)")
    elseif ip:match "^%d+%.%d+%.%d+$" then return tonumber(ip:match "^(%d+)") * 0x1000000 + tonumber(ip:match "^%d+%.(%d+)") * 0x10000 + tonumber(ip:match "^%d+%.%d+%.(%d+)")
    elseif ip:match "^%d+%.%d+%.%d+%.%d+$" then return tonumber(ip:match "^(%d+)") * 0x1000000 + tonumber(ip:match "^%d+%.(%d+)") * 0x10000 + tonumber(ip:match "^%d+%.%d+%.(%d+)") * 0x100 + tonumber(ip:match "^%d+%.%d+%.%d+%.(%d+)")
    else error("Invalid IP address", 2) end
end

local function numberToIP(num)
    if not num then return nil end
    return ("%d.%d.%d.%d"):format(bit32.band(bit32.rshift(num, 24), 0xFF), bit32.band(bit32.rshift(num, 16), 0xFF), bit32.band(bit32.rshift(num, 8), 0xFF), bit32.band(num, 0xFF))
end

local function randomString(len)
    local s = ""
    for i = 1, len do s = s .. string.char(math.random(0, 255)) end
    return s
end

local function prefixToMask(num) return bit32.bnot(2^(32-num)-1) end

local function maskToPrefix(mask)
    local n = 0
    while bit32.btest(mask, 0x80000000) do mask, n = bit32.lshift(mask, 1), n + 1 end
    return n
end

local function checkModem(node)
    if not node then error("No such device") end
    for _, v in pairs(node.drivers) do if v.type == "modem" then return node end end
    error("Not a modem")
end

local nextHandleID = 0

--#region Network stack implementation

local ipconfig = {}
local routes = {maxn = 0, [0] = {}}
local arptable = {}
local protocols = {send = {}, recv = {}}
local openSockets = {}
local networkListeners = setmetatable({}, {__mode = "k"})
local waiting = {arp = {}, socket = {}}
local usedMessageIDs = {}

--[[
    socket object:
    * ip: IP address of the remote host
    * port: Port of the remote host
    * localPort: Receive port on the local host
    * id: ID of the socket/handle
    * sendSeq: last sequence acknowledged by peer [SND.UNA]
    * sendSeqNext: next sender sequence to peer [SND.NXT]
    * sendSeqMax: maximum sequence to peer (for window) [SND.WND]
      - on close, this is set to the sequence for the FIN message
    * recvSeq: next expected received sequence from peer [RCV.NXT]
    * recvSeqMax: maximum sequence from peer (for window) [RCV.WND]
    * status: status of socket (listening, syn-sent, syn-received, connected, fin-wait, closing, close-wait [LAST-ACK], time-wait, closed)
    * nextUpdate: time that the next update can be triggered
    * process?: process that opened the socket
    * retryCount: number of retries in the current state
    * error?: an error status if something went wrong
    * outQueue: list of messages that were sent but not ACKed
    * nextAck?: whether the next timer should be for sending an ACK
    * buffer: data queue for the socket (string)
]]

-- TODO: Make a final decision on whether to use channels for PSP ports.
-- There's a limit on open channels, so that would arbitrarily limit
-- the number of sockets that could be open at once, much below the
-- port exhaustion limit. However, putting everything on the same
-- channel may cause too much chatter on the channel.

function protocols.send.link(info, destination, message)
    expect(2, destination, "number", "nil")
    expect.field(info, "device", "table")
    local obj = {
        PhoenixNetworking = true,
        type = "link",
        source = os.computerID(),
        destination = destination,
        payload = message
    }
    if destination == os.computerID() then os.queueEvent("modem_message", info.device.id, info.outPort or 0, info.inPort or 0, obj, 0)
    else hardware.call(info.process or KERNEL, info.device, "transmit", info.outPort or 0, info.inPort or 0, obj) end
end

function protocols.send.arp_request(info, ip)
    expect.field(info, "device", "table")
    expect(2, ip, "string")
    hardware.call(info.process or KERNEL, info.device, "transmit", 0, 0, {
        PhoenixNetworking = true,
        type = "arp",
        reply = false,
        source = os.computerID(),
        sourceIP = ipconfig[info.device.uuid] and numberToIP(ipconfig[info.device.uuid].ip),
        destinationIP = ip
    })
end

function protocols.send.arp_reply(info, destination, destIP)
    expect.field(info, "device", "table")
    expect(2, destination, "number")
    expect(3, destIP, "string", "nil")
    hardware.call(info.process or KERNEL, info.device, "transmit", 0, 0, {
        PhoenixNetworking = true,
        type = "arp",
        reply = true,
        source = os.computerID(),
        sourceIP = numberToIP(ipconfig[info.device.uuid].ip),
        destination = destination,
        destinationIP = destIP
    })
end

function protocols.send.internet(info, destination, message)
    expect(2, destination, "number")
    local msg = {PhoenixNetworking = true, type = "internet", hopsLeft = 15, payload = message, destination = numberToIP(destination)}
    local id = randomString(32)
    msg.messageID = id
    --usedMessageIDs[id] = os.epoch "utc"
    local v
    for i = routes.maxn, 0, -1 do if routes[i] then
        for _, rt in ipairs(routes[i]) do
            if bit32.band(rt.source, rt.sourceNetmask) == bit32.band(destination, rt.sourceNetmask) and
               (not v or maskToPrefix(rt.sourceNetmask) > maskToPrefix(v.sourceNetmask)) then v = rt end
        end
    end end
    if not v then return protocols.recv.control({}, {
        PhoenixNetworking = true,
        messageType = "unreachable",
        error = "No route to host",
        payload = msg
    }) end
    if v.action == "unicast" and ipconfig[v.device.uuid] and ipconfig[v.device.uuid].up then
        info.device = v.device
        msg.source = numberToIP(ipconfig[v.device.uuid].ip)
        if arptable[v.device.uuid] and arptable[v.device.uuid][v.destination] then return protocols.send.link(info, arptable[v.device.uuid][v.destination], msg) end
        local sent = false
        local timer
        local function arp_reply(_, ip, dest)
            if not sent and ipToNumber(ip) == v.destination then
                sent = true
                protocols.send.link(info, dest, msg)
            end
            if sent then for i, f in ipairs(waiting.arp) do if f == arp_reply then table.remove(waiting.arp, i) break end end end
        end
        local function timer_func(ev)
            if ev[2] == timer then
                if not sent then protocols.recv.control({}, {
                    PhoenixNetworking = true,
                    messageType = "unreachable",
                    error = "No route to host",
                    payload = msg
                }) end
                sent = true
                for i, v in ipairs(eventHooks.timer) do if v == timer_func then table.remove(eventHooks.timer, i) break end end
                for i, f in ipairs(waiting.arp) do if f == arp_reply then table.remove(waiting.arp, i) break end end
            end
        end
        waiting.arp[#waiting.arp+1] = arp_reply
        protocols.send.arp_request(info, numberToIP(v.destination))
        eventHooks.timer = eventHooks.timer or {}
        eventHooks.timer[#eventHooks.timer+1] = timer_func
        timer = os.startTimer(2)
        return
    elseif v.action == "broadcast" and ipconfig[v.device.uuid] and ipconfig[v.device.uuid].up then
        info.device = v.device
        msg.source = numberToIP(ipconfig[v.device.uuid].ip)
        return protocols.send.link(info, nil, msg)
    elseif v.action == "local" and ipconfig[v.device.uuid] and ipconfig[v.device.uuid].up then
        info.device = v.device
        msg.source = numberToIP(ipconfig[v.device.uuid].ip)
        if arptable[v.device.uuid] and arptable[v.device.uuid][destination] then return protocols.send.link(info, arptable[v.device.uuid][destination], msg) end
        local sent = false
        local timer
        local function arp_reply(_, ip, dest)
            if not sent and ipToNumber(ip) == destination then
                sent = true
                protocols.send.link(info, dest, msg)
            end
            if sent then for i, f in ipairs(waiting.arp) do if f == arp_reply then table.remove(waiting.arp, i) break end end end
        end
        local function timer_func(ev)
            if ev[2] == timer then
                if not sent then protocols.recv.control({}, {
                    PhoenixNetworking = true,
                    messageType = "unreachable",
                    error = "No route to host",
                    payload = msg
                }) end
                sent = true
                for i, v in ipairs(eventHooks.timer) do if v == timer_func then table.remove(eventHooks.timer, i) break end end
            end
        end
        waiting.arp[#waiting.arp+1] = arp_reply
        protocols.send.arp_request(info, numberToIP(destination))
        eventHooks.timer = eventHooks.timer or {}
        eventHooks.timer[#eventHooks.timer+1] = timer_func
        timer = os.startTimer(2)
        return
    elseif v.action == "unreachable" then
        return protocols.recv.control({}, {
            PhoenixNetworking = true,
            messageType = "unreachable",
            error = "Destination unreachable",
            payload = msg
        })
    elseif v.action == "prohibit" then
        return protocols.recv.control({}, {
            PhoenixNetworking = true,
            messageType = "unreachable",
            error = "Prohibited",
            payload = msg
        })
    elseif v.action == "blackhole" then
        return
    end
end

function protocols.send.control(info, destination, type, err, packet)
    expect(3, type, "string")
    expect(4, err, "string", "nil")
    return protocols.send.internet(info, destination, {
        PhoenixNetworking = true,
        type = "control",
        messageType = type,
        error = err,
        payload = packet
    })
end

protocols.send.socket = {}

function protocols.send.socket.connect(info, ip, port, socket)
    for i = 1, 16384 do
        local p = math.random(49152, 65535)
        if not openSockets[p] then socket.localPort = p break end
    end
    if not socket.localPort then error("Too many open sockets") end
    socket.id = nextHandleID
    nextHandleID = nextHandleID + 1
    socket.ip = ip
    socket.port = port
    socket.sendSeq = math.floor(math.random()*0x1000000000000)
    socket.sendSeqNext = socket.sendSeq + 2
    socket.sendSeqMax = socket.sendSeq + 256
    info.outPort = port
    info.inPort = socket.localPort
    protocols.send.internet(info, ip, {
        PhoenixNetworking = true,
        type = "socket",
        sequence = socket.sendSeqNext - 1,
        windowSize = 256,
        synchronize = true
    })
    local ok, err = pcall(hardware.call, info.process or KERNEL, info.device, "open", socket.localPort)
    if not ok then
        protocols.send.internet(info, ip, {
            PhoenixNetworking = true,
            type = "socket",
            sequence = socket.sendSeqNext,
            windowSize = 0,
            reset = true
        })
        error(err)
    end
    socket.status = "syn-sent"
    socket.nextUpdate = os.epoch "utc" + 5000
    socket.process = info.process
    socket.retryCount = 0
    openSockets[socket.localPort] = socket
end

function protocols.send.socket.data(info, message, socket)
    info.outPort = socket.port
    info.inPort = socket.localPort
    message.PhoenixNetworking = true
    message.type = "socket"
    if not message.sequence then
        message.sequence = socket.sendSeqNext
        socket.sendSeqNext = socket.sendSeqNext + 1
    end
    message.acknowledgement = message.acknowledgement or (socket.recvSeq - 1)
    socket.nextAck = nil
    if not message.final then message.windowSize = 256 end -- TODO: adjustable?
    return protocols.send.internet(info, socket.ip, message)
end

function protocols.send.socket.ack(info, num, socket)
    return protocols.send.socket.data(info, {acknowledgement = num}, socket)
end

function protocols.send.socket.reset(info, ip, port, seq, ack, inPort)
    info.outPort = port
    info.inPort = inPort or port
    return protocols.send.internet(info, ip, {
        PhoenixNetworking = true,
        type = "socket",
        sequence = seq,
        acknowledgement = ack,
        reset = true
    })
end

local function socket_read(socket, mode, ...)
    mode = mode or "*l"
    if type(mode) ~= "string" and type(mode) ~= "number" then error("bad argument (expected string or number, got " .. type(mode) .. ")", 2) end
    if socket.buffer == "" then return nil end
    mode = mode:gsub("^%*", "")
    if mode == "a" then
        local str = socket.buffer
        socket.buffer = ""
        return str
    elseif mode == "l" then
        local str, pos = socket.buffer:match "^([^\n]*)\n?()"
        if str then
            socket.buffer = socket.buffer:sub(pos)
            if select("#", ...) > 0 then return str, socket_read(socket, ...)
            else return str end
        else return nil end
    elseif mode == "L" then
        local str, pos = socket.buffer:match "^([^\n]*\n?)()"
        if str then
            socket.buffer = socket.buffer:sub(pos)
            if select("#", ...) > 0 then return str, socket_read(socket, ...)
            else return str end
        else return nil end
    elseif mode == "n" then
        local str, pos = socket.buffer:match "(%d+)()"
        if str then
            socket.buffer = socket.buffer:sub(pos)
            if select("#", ...) > 0 then return tonumber(str), socket_read(socket, ...)
            else return tonumber(str) end
        else return nil end
    elseif type(mode) == "number" then
        local str = socket.buffer:sub(1, mode)
        socket.buffer = socket.buffer:sub(mode + 1)
        if select("#", ...) > 0 then return str, socket_read(socket, ...)
        else return str end
    else error("bad argument (invalid mode '" .. mode .. "')", 2) end
end

local function socket_write(socket, data, ...)
    data = tostring(data)
    socket.outQueue[socket.sendSeqNext] = data
    protocols.send.socket.data({}, {payload = data}, socket)
    if select("#", ...) > 0 then return socket_write(socket, ...) end
end

function syscalls.__socketcall(process, thread, port, method, ...)
    local socket = openSockets[port]
    if not socket or socket.process ~= process then error("No such socket") end
    if method == "close" then
        socket.sendSeqMax = socket.sendSeqNext
        protocols.send.socket.data({}, {final = true}, socket)
        socket.status = "fin-wait"
    elseif method == "read" then return socket_read(socket, ...)
    elseif method == "write" then return socket_write(socket, ...)
    else error("No such method") end
end

local do_syscall = do_syscall

local function makePSPHandle(socket)
    local obj = setmetatable({id = socket.id}, {__name = "socket"})
    function obj:status()
        if socket.status == "listening" or socket.status == "syn-sent" or socket.status == "syn-received" then return "connecting"
        elseif socket.status == "connected" then return "connected"
        elseif socket.status == "error" then return "error", socket.error
        else return "closed" end
    end
    function obj:read(mode, ...)
        if socket.status ~= "connected" then error("attempt to read from a " .. socket.status .. " handle", 2) end
        return do_syscall("__socketcall", socket.localPort, "read", mode, ...)
    end
    function obj:write(data, ...)
        if socket.status ~= "connected" then error("attempt to write to a " .. socket.status .. " handle", 2) end
        return do_syscall("__socketcall", socket.localPort, "write", data, ...)
    end
    function obj:close()
        if not (socket.status == "listening" or socket.status == "syn-sent" or socket.status == "syn-received" or socket.status == "connected") then error("attempt to close a " .. socket.status .. " handle", 2) end
        return do_syscall("__socketcall", socket.localPort, "close")
    end
    return obj
end

-- prefilled entries in info: channel, replyChannel, device

function protocols.recv.link(info, message)
    expect.field(message, "source", "number")
    expect.field(message, "destination", "number")
    expect.field(message, "payload", "table")
    syslog.debug("Received link message from", message.source, "to", message.destination)
    if message.destination ~= os.computerID() then return end
    info.sourceID = message.source
    assert(message.payload.PhoenixNetworking)
    expect.field(message.payload, "type", "string")
    if not protocols.recv[message.payload.type] then error("Unknown protocol '" .. message.payload.type .. "'") end
    return protocols.recv[message.payload.type](info, message.payload)
end

function protocols.recv.arp(info, message)
    expect.field(message, "source", "number")
    expect.field(message, "reply", "boolean")
    syslog.debug("Received arp message from", message.source)
    if not message.reply and message.destinationIP and message.sourceIP ~= message.destinationIP then
        local ip = ipToNumber(expect.field(message, "destinationIP", "string"))
        if ipconfig[info.device.uuid] and ipconfig[info.device.uuid].ip == ip then
            protocols.send.arp_reply(info, message.source, message.sourceIP)
        end
    end
    if message.sourceIP then
        local ip = ipToNumber(expect.field(message, "sourceIP", "string"))
        arptable[info.device.uuid] = arptable[info.device.uuid] or {}
        arptable[info.device.uuid][ip] = message.source
        -- copy the table so we don't skip any if the function modifies the table
        local tmp = {}
        for i, v in ipairs(waiting.arp) do tmp[i] = v end
        for _, v in ipairs(tmp) do v(v, message.sourceIP, message.source) end
    end
end

function protocols.recv.internet(info, message)
    info.sourceIP = ipToNumber(expect.field(message, "source", "string"))
    local dest = ipToNumber(expect.field(message, "destination", "string"))
    syslog.debug("Received internet message from", message.source, "to", message.destination)
    expect.field(message, "payload", "table")
    if usedMessageIDs[expect.field(message, "messageID", "number", "string")] then return end
    usedMessageIDs[message.messageID] = os.epoch "utc"
    if not ipconfig[info.device.uuid] or ipconfig[info.device.uuid].ip ~= dest then return end
    info.ipPacket = message
    assert(message.payload.PhoenixNetworking)
    expect.field(message.payload, "type", "string")
    if not protocols.recv[message.payload.type] then error("Unknown protocol '" .. message.payload.type .. "'") end
    return protocols.recv[message.payload.type](info, message.payload)
end

function protocols.recv.control(info, message)
    expect.field(message, "messageType", "string")
    syslog.debug("Received control message", message.messageType)
    local retval = false
    if message.messageType == "ping" then protocols.send.control({device = info.device}, info.sourceIP, "pong", nil, info.ipPacket)
    else for _, v in pairs(networkListeners) do retval = v{type = "control", messageType = message.messageType, error = message.error, payload = message.payload, sender = numberToIP(info.sourceIP)} or retval end end
    return retval
end

function protocols.recv.socket(info, message)
    expect.field(message, "sequence", "number")
    expect.field(message, "acknowledgement", "number", "nil")
    expect.field(message, "windowSize", "number", "nil")
    expect.field(message, "payload", "string", "nil")
    if info.channel == 0 or info.replyChannel == 0 then syslog.debug("Received socket event on channel 0; discarding.") return end
    local socket = openSockets[info.channel]
    if not socket then
        if message.acknowledgement then protocols.send.socket.reset(info, info.sourceIP, info.replyChannel, message.acknowledgement, nil, info.channel)
        else protocols.send.socket.reset(info, info.sourceIP, info.replyChannel, 0, message.sequence + (message.windowSize or 0), info.channel) end
        return
    end
    do
        local s = {}
        for k, v in pairs(socket) do if k ~= "process" then s[k] = v end end
        syslog.debug("Received socket message:", serialize(message), "\nSocket info:", serialize(s))
    end
    if socket.status == "listening" then
        if message.reset then return end
        if message.acknowledgement then
            protocols.send.socket.reset(info, info.sourceIP, info.replyChannel, message.acknowledgement, nil, info.channel)
            return
        end
        if not message.synchronize then return end
        socket.ip = info.sourceIP
        socket.port = info.replyChannel
        socket.recvSeq = message.sequence + 1
        socket.recvSeqMax = socket.recvSeq + (message.windowSize or 0)
        socket.sendSeq = math.floor(math.random()*0x1000000000000)
        socket.sendSeqNext = socket.sendSeq + 2
        socket.sendSeqMax = socket.sendSeq + (message.windowSize or 0)
        socket.status = "syn-received"
        socket.nextUpdate = os.epoch "utc" + 5000
        socket.retryCount = 0
        protocols.send.internet({inPort = info.channel, outPort = info.replyChannel}, socket.ip, {
            PhoenixNetworking = true,
            type = "socket",
            sequence = socket.sendSeqNext - 1,
            acknowledgement = socket.recvSeq,
            windowSize = 256,
            synchronize = true
        })
    elseif socket.status == "syn-sent" then
        if message.reset then
            socket.status = "error"
            socket.error = "Connection refused"
            openSockets[info.channel] = nil
            if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "error"}} end
            return true
        end
        if not message.synchronize or not message.acknowledgement or message.acknowledgement < socket.sendSeq then
            protocols.send.socket.reset(info, info.sourceIP, info.replyChannel, message.acknowledgement, nil, info.channel)
            socket.status = "error"
            socket.error = "Connection refused"
            openSockets[info.channel] = nil
            if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "error"}} end
            return true
        end
        socket.status = "connected"
        socket.sendSeq = message.acknowledgement
        socket.sendSeqMax = socket.sendSeq + 256
        socket.recvSeq = message.sequence + 1
        socket.recvSeqMax = socket.recvSeq + (message.windowSize or 0)
        socket.outQueue = {}
        socket.nextUpdate = os.epoch "utc" + 2000
        protocols.send.socket.ack({}, socket.recvSeq, socket)
        if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "connected"}} end
        return true
    else
        if message.sequence < socket.recvSeq or message.sequence > socket.recvSeqMax then
            syslog.debug("Sequence out of range")
            if message.reset then
                socket.status = "error"
                socket.error = "Connection reset by peer"
                openSockets[info.channel] = nil
                if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "error"}} end
                return true
            else
                protocols.send.socket.ack({}, socket.recvSeq, socket)
                return
            end
        end
        if message.reset then
            syslog.debug("Received reset")
            if socket.status == "syn-received" then
                socket.status = "listening"
                return
            elseif socket.status == "connected" or socket.status == "fin-wait" then
                socket.status = "error"
                socket.error = "Connection reset by peer"
                openSockets[info.channel] = nil
                if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "error"}} end
                return true
            else
                socket.status = "closed"
                openSockets[info.channel] = nil
                if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "closed"}} end
                return true
            end
        end
        if message.synchronize then
            protocols.send.socket.reset(info, info.sourceIP, info.replyChannel, message.acknowledgement, nil, info.channel)
            socket.status = "error"
            socket.error = "Connection reset by host"
            openSockets[info.channel] = nil
            if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "error"}} end
            return true
        end
        local retval
        if not message.acknowledgement then syslog.debug("No acknowledgement") return end
        if socket.status == "syn-received" then
            if message.acknowledgement >= socket.sendSeq and message.acknowledgement <= socket.sendSeqNext then
                socket.status = "connected"
                socket.outQueue = {}
                socket.nextUpdate = os.epoch "utc" + 2000
                if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"network_request", {uri = socket.uri, ip = info.sourceIP, handle = makePSPHandle(socket)}} end
                retval = true
            else
                protocols.send.socket.reset(info, info.sourceIP, info.replyChannel, message.acknowledgement, nil, info.channel)
                socket.status = "error"
                socket.error = "Connection reset by host"
                openSockets[info.channel] = nil
                if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "error"}} end
                return true
            end
        elseif socket.status == "close-wait" then
            if message.acknowledgement == socket.sendSeqMax then
                syslog.debug("Socket closed")
                socket.status = "closed"
                openSockets[info.channel] = nil
                if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "closed"}} end
                return true
            end
        elseif socket.status == "time-wait" then
            if message.final then
                protocols.send.socket.ack({}, message.sequence, socket)
                socket.nextUpdate = os.epoch "utc" + 10000
                return
            end
        else
            if message.acknowledgement > socket.sendSeq and message.acknowledgement <= socket.sendSeqNext then
                for i = socket.sendSeq, message.acknowledgement do socket.outQueue[i] = nil end
                socket.sendSeq = message.acknowledgement
                if message.windowSize then socket.sendSeqMax = socket.sendSeq + message.windowSize end
            end
            if socket.status == "fin-wait" then
                if message.acknowledgement == socket.sendSeqMax then
                    if not message.final then
                        protocols.send.socket.reset(info, info.sourceIP, info.replyChannel, message.acknowledgement, nil, info.channel)
                        socket.status = "error"
                        socket.error = "Connection reset by host"
                        openSockets[info.channel] = nil
                        if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "error"}} end
                        return true
                    end
                    socket.status = "time-wait"
                    socket.nextUpdate = os.epoch "utc" + 10000
                end
            elseif socket.status == "closing" then
                if message.acknowledgement == socket.sendSeqMax then
                    socket.status = "time-wait"
                    socket.nextUpdate = os.epoch "utc" + 10000
                end
            end
        end
        if socket.status == "connected" and message.sequence == socket.recvSeq then
            if message.payload then
                socket.buffer = socket.buffer .. message.payload
                socket.nextAck = true
                socket.nextUpdate = os.epoch "utc" + 100
                if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_data_ready", {id = socket.id}} end
                retval = true
            end
            socket.recvSeq = socket.recvSeq + 1
        end
        if message.final then
            syslog.debug("Got final message")
            socket.recvSeq = message.sequence + 1
            if socket.status == "syn-received" or socket.status == "connected" then
                socket.sendSeqMax = socket.sendSeqNext
                protocols.send.socket.data({}, {
                    final = true,
                    acknowledgement = message.sequence
                }, socket)
                socket.status = "close-wait"
                if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "closed"}} end
                return true
            elseif socket.status == "fin-wait" then
                protocols.send.socket.ack({}, message.sequence, socket)
                if message.acknowledgement ~= socket.sendSeqMax then
                    socket.status = "closing"
                else
                    socket.status = "time-wait"
                    socket.nextUpdate = os.epoch "utc" + 10000
                end
            else
                protocols.send.socket.ack({}, message.sequence, socket)
            end
            syslog.debug(socket.status)
        end
        return retval
    end
end

-- This function is called every second, handling any timed updates that may be necessary for sockets.
local function socketUpdate()
    local time = os.epoch "utc"
    local event = false
    for port, socket in pairs(openSockets) do if time >= socket.nextUpdate then
        if socket.status == "syn-sent" then
            socket.status = "error"
            socket.error = "Connection timed out (syn-sent)"
            openSockets[port] = nil
            if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "error"}} event = true end
        elseif socket.status == "syn-received" then
            socket.retryCount = socket.retryCount + 1
            if socket.retryCount > 3 then
                socket.status = "error"
                socket.error = "Connection timed out (syn-received)"
                openSockets[port] = nil
                if socket.process then socket.process.eventQueue[#socket.process.eventQueue+1] = {"handle_status_change", {id = socket.id, status = "error"}} event = true end
            else
                -- TODO: resend syn+ack packet
                socket.nextUpdate = os.epoch "utc" + 2000
            end
        elseif socket.status == "connected" then
            for i = socket.sendSeq + 1, socket.sendSeqNext - 1 do
                if socket.outQueue[i] then
                    protocols.send.socket.data({}, {
                        sequence = i,
                        payload = socket.outQueue[i]
                    }, socket)
                end
            end
            if socket.nextAck then
                protocols.send.socket.ack({}, socket.recvSeq - 1, socket)
                socket.nextAck = nil
            end
            socket.nextUpdate = os.epoch "utc" + 2000
        elseif socket.status == "fin-wait" then

        elseif socket.status == "close-wait" then

        elseif socket.status == "time-wait" then
            syslog.debug("Time wait finished on port " .. port)
            socket.status = "closed"
            openSockets[port] = nil
        end
    end end
    return event
end

eventHooks.modem_message = eventHooks.modem_message or {}
eventHooks.modem_message[#eventHooks.modem_message+1] = function(ev)
    if type(ev[5]) == "table" and ev[5].PhoenixNetworking and type(ev[5].type) == "string" and protocols.recv[ev[5].type] then
        local node = getNodeById(ev[2]) or hardware.get(ev[2])
        if not node then
            syslog.log({level = "notice", module = "Network"}, "Received network event for device ID " .. ev[2] .. ", but no device node was found; ignoring")
            return
        end
        if not ipconfig[node.uuid] or not ipconfig[node.uuid].up then return end
        syslog.debug(ev[2], serialize(ev[5]))
        local ok, err = pcall(protocols.recv[ev[5].type], {channel = ev[3], replyChannel = ev[4], device = node}, ev[5])
        if not ok then syslog.log({level = "debug", module = "Network"}, "Network event errored while processing:", err)
        else return err end
    end
end

local socketTimer = os.startTimer(1)
eventHooks.timer = eventHooks.timer or {}
eventHooks.timer[#eventHooks.timer+1] = function(ev)
    if ev[2] == socketTimer then
        socketTimer = os.startTimer(1)
        return socketUpdate()
    end
end

local function pspHandler(process, options)
    -- TODO: implement device filtering
    local uri = parseURI(options.url)
    if not uri.port then error("No port specified") end
    local ip = ipToNumber(uri.host)
    local port = uri.port
    local socket = {process = process, buffer = ""}
    protocols.send.socket.connect({process = process}, ip, port, socket)
    return makePSPHandle(socket)
end

--#endregion

--#region HTTP/Rednet handlers

local httpRequests = {}
local rednetOpenCount = {}
local rednetHandles = {}
local rednetChannel = os.computerID() % 65500
local receivedRednetMessages = {}

eventHooks.http_success = eventHooks.http_success or {}
eventHooks.http_success[#eventHooks.http_success+1] = function(ev)
    local info = httpRequests[ev[2]]
    if info then
        info.handle, info.status = ev[3], "open"
        info.process.eventQueue[#info.process.eventQueue+1] = {"handle_status_change", {id = info.id, status = "open"}}
        httpRequests[ev[2]] = nil
        return true
    else syslog.log({level = "notice"}, "Received HTTP response for " .. ev[2] .. " but nobody requested it; ignoring.") end
end

eventHooks.http_failure = eventHooks.http_failure or {}
eventHooks.http_failure[#eventHooks.http_failure+1] = function(ev)
    local info = httpRequests[ev[2]]
    if info then
        if ev[4] then info.handle, info.status = ev[3], "open"
        else info.status, info.error = "error", ev[3] end
        info.process.eventQueue[#info.process.eventQueue+1] = {"handle_status_change", {id = info.id, status = info.status}}
        httpRequests[ev[2]] = nil
        return true
    else syslog.log({level = "notice"}, "Received HTTP response for " .. ev[2] .. " but nobody requested it; ignoring.") end
end

eventHooks.websocket_success = eventHooks.websocket_success or {}
eventHooks.websocket_success[#eventHooks.websocket_success+1] = function(ev)
    local info = httpRequests[ev[2]]
    if info then
        info.handle, info.status = ev[3], "open"
        info.process.eventQueue[#info.process.eventQueue+1] = {"handle_status_change", {id = info.id, status = "open"}}
        return true
    else syslog.log({level = "notice"}, "Received WebSocket response for " .. ev[2] .. " but nobody requested it; ignoring.") end
end

eventHooks.websocket_failure = eventHooks.websocket_failure or {}
eventHooks.websocket_failure[#eventHooks.websocket_failure+1] = function(ev)
    local info = httpRequests[ev[2]]
    if info then
        info.status, info.error = "error", ev[3]
        info.process.eventQueue[#info.process.eventQueue+1] = {"handle_status_change", {id = info.id, status = info.status}}
        return true
    else syslog.log({level = "notice"}, "Received WebSocket response for " .. ev[2] .. " but nobody requested it; ignoring.") end
end

eventHooks.websocket_message = eventHooks.websocket_message or {}
eventHooks.websocket_message[#eventHooks.websocket_message+1] = function(ev)
    local info = httpRequests[ev[2]]
    if info then
        -- TODO: decide whether to transcode if the requested encoding doesn't match the message
        info.buffer = info.buffer .. ev[3]
        info.process.eventQueue[#info.process.eventQueue+1] = {"handle_data_ready", {id = info.id}}
        return true
    else syslog.log({level = "notice"}, "Received WebSocket response for " .. ev[2] .. " but nobody requested it; ignoring.") end
end

eventHooks.websocket_closed = eventHooks.websocket_closed or {}
eventHooks.websocket_closed[#eventHooks.websocket_closed+1] = function(ev)
    local info = httpRequests[ev[2]]
    if info then
        info.status = "closed"
        info.process.eventQueue[#info.process.eventQueue+1] = {"handle_status_change", {id = info.id, status = info.status}}
        httpRequests[ev[2]] = nil
        return true
    else syslog.log({level = "notice"}, "Received WebSocket message for " .. ev[2] .. " but it's not open; ignoring.") end
end

eventHooks.modem_message = eventHooks.modem_message or {}
eventHooks.modem_message[#eventHooks.modem_message+1] = function(ev)
    local retval = false
    if rednetOpenCount[ev[2]] and (ev[3] == rednetChannel or ev[3] == 65535) and
       type(ev[5]) == "table" and type(ev[5].nMessageID) == "number" and
       ev[5].nMessageID == ev[5].nMessageID and not receivedRednetMessages[ev[5].nMessageID] and
       ((ev[5].nRecipient and ev[5].nRecipient == os.computerID()) or ev[3] == 65535) then
        if rednetHandles[ev[5].nSender] then
            for _, v in ipairs(rednetHandles[ev[5].nSender]) do
                if not v.protocol or v.protocol == ev[5].sProtocol then
                    v.buffer[#v.buffer+1] = deepcopy(ev[5].message)
                    receivedRednetMessages[ev[5].nMessageID] = os.clock() + 9.5
                    v.process.eventQueue[#v.process.eventQueue+1] = {"handle_data_ready", {id = v.id}}
                    retval = true
                end
            end
        end
        if rednetHandles[0xFFFFFFFF] then
            for _, v in ipairs(rednetHandles[0xFFFFFFFF]) do
                if not v.protocol or v.protocol == ev[5].sProtocol then
                    v.buffer[#v.buffer+1] = deepcopy(ev[5].message)
                    receivedRednetMessages[ev[5].nMessageID] = os.clock() + 9.5
                    v.process.eventQueue[#v.process.eventQueue+1] = {"handle_data_ready", {id = v.id}}
                    retval = true
                end
            end
        end
        for k, v in pairs(receivedRednetMessages) do if v < os.clock() then receivedRednetMessages[k] = nil end end
    end
    return retval
end

-- TODO: Fix handle:read() not being equivalent to handle:read("*l")

local request = http.request
local function httpHandler(process, options)
    expect.field(options, "encoding", "string", "nil")
    expect.field(options, "headers", "table", "nil")
    expect.field(options, "method", "string", "nil")
    expect.field(options, "redirect", "boolean", "nil")
    local info = {status = "ready", process = process, id = nextHandleID}
    local obj = setmetatable({id = nextHandleID}, {__name = "socket"})
    nextHandleID = nextHandleID + 1
    function obj:status()
        return info.status, info.error
    end
    function obj:read(mode, ...)
        if info.status ~= "open" then error("attempt to read from a " .. info.status .. " handle", 2) end
        mode = mode or "*l"
        if type(mode) ~= "string" and type(mode) ~= "number" then error("bad argument (expected string or number, got " .. type(mode) .. ")", 2) end
        mode = mode:gsub("^%*", "")
        if mode == "a" then
            if select("#", ...) > 0 then return info.handle.readAll(), self:read(...)
            else return info.handle.readAll() end
        elseif mode == "l" then
            if select("#", ...) > 0 then return info.handle.readLine(false), self:read(...)
            else return info.handle.readLine(false) end
        elseif mode == "L" then
            if select("#", ...) > 0 then return info.handle.readLine(true), self:read(...)
            else return info.handle.readLine(true) end
        elseif mode == "n" then
            local str
            repeat
                str = info.handle.read(1)
                if not str then return nil end
            until tonumber(str)
            while true do
                local c = info.handle.read(1)
                if not c or not c:match "%d" then break end
                str = str .. c
            end
            if select("#", ...) > 0 then return tonumber(str), self:read(...)
            else return tonumber(str) end
        elseif type(mode) == "number" then
            if select("#", ...) > 0 then return info.handle.read(mode), self:read(...)
            else return info.handle.read(mode) end
        else error("bad argument (invalid mode '" .. mode .. "')", 2) end
    end
    function obj:write(...)
        if info.status ~= "ready" then error("attempt to write to a " .. info.status .. " handle", 2) end
        local data
        if select("#", ...) > 0 then
            data = ""
            for _, v in ipairs{...} do data = data .. tostring(v) end
        end
        local url = options.url .. "#" .. info.id
        local ok, err = request{url = url, body = data, headers = options.headers, binary = options.encoding == "binary", method = options.method, redirect = options.redirect}
        if ok then
            httpRequests[url] = info
            info.status = "connecting"
        else info.status, info.error = "error", err end
    end
    function obj:close()
        if info.status ~= "open" then error("attempt to close a " .. info.status .. " handle", 2) end
        info.handle.close()
        info.status = "closed"
    end
    function obj:responseHeaders()
        if info.status ~= "open" then error("attempt to read from a " .. info.status .. " handle", 2) end
        return info.handle.getResponseHeaders()
    end
    function obj:responseCode()
        if info.status ~= "open" then error("attempt to read from a " .. info.status .. " handle", 2) end
        return info.handle.getResponseCode()
    end
    return obj
end

local function wsHandler(process, options)
    expect.field(options, "encoding", "string", "nil")
    expect.field(options, "headers", "table", "nil")
    local info = {process = process, id = nextHandleID, buffer = ""}
    local obj = setmetatable({id = nextHandleID}, {__name = "socket"})
    nextHandleID = nextHandleID + 1
    function obj:status()
        return info.status, info.error
    end
    function obj:read(mode, ...)
        if info.status ~= "open" then error("attempt to read from a " .. info.status .. " handle", 2) end
        mode = mode or "*l"
        if type(mode) ~= "string" and type(mode) ~= "number" then error("bad argument (expected string or number, got " .. type(mode) .. ")", 2) end
        if info.buffer == "" then return nil end
        mode = mode:gsub("^%*", "")
        if mode == "a" then
            local str = info.buffer
            info.buffer = ""
            return str
        elseif mode == "l" then
            local str, pos = info.buffer:match "^([^\n]*)\n?()"
            if str then
                info.buffer = info.buffer:sub(pos)
                if select("#", ...) > 0 then return str, self:read(...)
                else return str end
            else return nil end
        elseif mode == "L" then
            local str, pos = info.buffer:match "^([^\n]*\n?)()"
            if str then
                info.buffer = info.buffer:sub(pos)
                if select("#", ...) > 0 then return str, self:read(...)
                else return str end
            else return nil end
        elseif mode == "n" then
            local str, pos = info.buffer:match "(%d+)()"
            if str then
                info.buffer = info.buffer:sub(pos)
                if select("#", ...) > 0 then return tonumber(str), self:read(...)
                else return tonumber(str) end
            else return nil end
        elseif type(mode) == "number" then
            local str = info.buffer:sub(1, mode)
            info.buffer = info.buffer:sub(mode + 1)
            if select("#", ...) > 0 then return str, self:read(...)
            else return str end
        else error("bad argument (invalid mode '" .. mode .. "')", 2) end
    end
    function obj:write(data, ...)
        if info.status ~= "open" then error("attempt to write to a " .. info.status .. " handle", 2) end
        info.handle.send(tostring(data), options.encoding == "binary")
        if select("#", ...) > 0 then return self:write(...) end
    end
    function obj:close()
        if info.status ~= "open" then error("attempt to close a " .. info.status .. " handle", 2) end
        info.handle.close()
        info.status = "closed"
    end
    local url = options.url .. "#" .. info.id
    local ok, err = http.websocket(url, options.headers)
    if ok then
        httpRequests[url] = info
        info.status = "connecting"
    else return nil, err end
    return obj
end

-- TODO: consider adding hostname lookup
local function rednetHandler(process, options)
    expect.field(options, "device", "string", "nil")
    local modems
    if options.device then modems = {hardware.get(options.device)}
    else modems = {hardware.find("modem")} end
    if #modems == 0 then error("Could not find a modem", 2) end
    for _, v in ipairs(modems) do
        checkModem(v)
        if not rednetOpenCount[v] then
            hardware.call(process, v, "open", rednetChannel)
            hardware.call(process, v, "open", 65535)
            rednetOpenCount[v] = 1
        else rednetOpenCount[v] = rednetOpenCount[v] + 1 end
    end
    local uri = parseURI(options.url)
    if not uri.host then error("Missing host", 2) end
    local id = ipToNumber(uri.host)
    local info = {process = process, id = nextHandleID, buffer = {}, protocol = uri.scheme:match "rednet%+(.+)"}
    local obj = setmetatable({id = nextHandleID}, {__name = "socket"})
    nextHandleID = nextHandleID + 1
    function obj:status()
        return info.closed and "closed" or "open"
    end
    function obj:read(mode, ...)
        if info.closed then error("attempt to read from a " .. info.status .. " handle", 2) end
        mode = mode or "*l"
        if type(mode) ~= "string" and type(mode) ~= "number" then error("bad argument (expected string or number, got " .. type(mode) .. ")", 2) end
        if #info.buffer == 0 then return nil end
        mode = mode:gsub("^%*", "")
        if mode == "a" then
            return table.remove(info.buffer, 1)
        elseif mode == "l" then
            info.buffer[1] = tostring(info.buffer[1])
            local str, pos = info.buffer[1]:match "^([^\n]*)\n?()"
            if str then
                info.buffer[1] = info.buffer[1]:sub(pos)
                if select("#", ...) > 0 then return str, self:read(...)
                else return str end
            else
                table.remove(info.buffer, 1)
                return self:read(mode, ...)
            end
        elseif mode == "L" then
            info.buffer[1] = tostring(info.buffer[1])
            local str, pos = info.buffer[1]:match "^([^\n]*\n?)()"
            if str then
                info.buffer[1] = info.buffer[1]:sub(pos)
                if select("#", ...) > 0 then return str, self:read(...)
                else return str end
            else
                table.remove(info.buffer, 1)
                return self:read(mode, ...)
            end
        elseif mode == "n" then
            info.buffer[1] = tostring(info.buffer[1])
            local str, pos = info.buffer[1]:match "(%d+)()"
            if str then
                info.buffer[1] = info.buffer[1]:sub(pos)
                if select("#", ...) > 0 then return tonumber(str), self:read(...)
                else return tonumber(str) end
            else
                table.remove(info.buffer, 1)
                return self:read(mode, ...)
            end
        elseif type(mode) == "number" then
            local str = ""
            while #str < mode do
                info.buffer[1] = tostring(info.buffer[1])
                str = str .. info.buffer[1]:sub(1, mode - #str)
                info.buffer[1] = info.buffer[1]:sub(mode - #str + 1)
                if info.buffer[1] == "" then table.remove(info.buffer, 1) end
                if #info.buffer == 0 then break end
            end
            if select("#", ...) > 0 then return str, self:read(...)
            else return str end
        else error("bad argument (invalid mode '" .. mode .. "')", 2) end
    end
    function obj:write(data, ...)
        if info.closed then error("attempt to write to a " .. info.status .. " handle", 2) end
        local msgid = math.random(1, 0x7FFFFFFF)
        local msg = {
            nMessageID = msgid,
            nRecipient = id,
            nSender = os.computerID(),
            message = data,
            sProtocol = info.protocol
        }
        if id == os.computerID() then
            for _, v in ipairs(modems) do
                os.queueEvent("modem_message", v.id, rednetChannel, rednetChannel, msg, 0)
            end
        else
            receivedRednetMessages[msgid] = os.clock() + 9.5
            for _, v in ipairs(modems) do
                hardware.call(process, v, "transmit", id == 0xFFFFFFFF and 65535 or id % 65500, rednetChannel, msg)
                hardware.call(process, v, "transmit", 65533, rednetChannel, msg)
            end
        end
        if select("#", ...) > 0 then return self:write(...) end
    end
    function obj:close()
        if info.closed then error("attempt to close a " .. info.status .. " handle", 2) end
        for _, v in ipairs(modems) do
            rednetOpenCount[v] = rednetOpenCount[v] - 1
            if rednetOpenCount[v] == 0 then
                hardware.call(process, v, "close", rednetChannel)
                hardware.call(process, v, "close", 65535)
                rednetOpenCount[v] = nil
            end
        end
        info.status = "closed"
    end
    return obj
end

--#endregion

-- TODO: add event handling for HTTP/WS servers

--- Stores all URI scheme handlers using Lua patterns as keys.
uriSchemes = {
    ["https?"] = httpHandler,
    ["wss?"] = wsHandler,
    ["rednet"] = rednetHandler,
    ["rednet%+%a+"] = rednetHandler,
    ["psp"] = pspHandler
}

function syscalls.connect(process, thread, options)
    if type(options) == "string" then options = {url = options} end
    expect(1, options, "table")
    expect.field(options, "url", "string")
    local uri = parseURI(options.url)
    local obj, err
    for k, v in pairs(uriSchemes) do
        if uri.scheme:match(k) then
            obj, err = v(process, options)
            break
        end
    end
    if not obj and not err then error("Invalid protocol " .. uri.scheme) end
    if obj then for _, v in pairs(obj) do if type(v) == "function" then setfenv(v, process.env) debug.protect(v) end end end
    return obj, err
end

function syscalls.listen(process, thread, uri)
    expect(1, uri, "string")
    local URI = parseURI(uri)
    if http.addListener then
        if URI.scheme == "http" then
            http.addListener(URI.port or 80)
            return
        elseif URI.scheme == "ws" then
            http.websocket(URI.port or 80)
            return
        end
    end
    if URI.scheme == "psp" then
        if not URI.port then error("Missing port") end
        local ip = ipToNumber(URI.host)
        for k, v in pairs(ipconfig) do
            if v.up and (ip == 0 or v.ip == ip) then
                hardware.call(process, hardware.get(k), "open", URI.port)
            end
        end
        local socket = {
            localPort = URI.port,
            id = nextHandleID,
            status = "listening",
            process = process,
            nextUpdate = math.huge,
            retryCount = 0,
            uri = uri,
            buffer = ""
        }
        nextHandleID = nextHandleID + 1
        openSockets[URI.port] = socket
        return
    end
    error("Invalid protocol " .. URI.scheme)
end

function syscalls.unlisten(process, thread, uri)
    -- TODO
end

function syscalls.ipconfig(process, thread, device, info)
    if process.user ~= "root" then error("Permission denied") end
    expect(1, device, "string")
    expect(2, info, "table", "nil")
    local node = checkModem(hardware.get(device))
    local t = ipconfig[node.uuid]
    if not t then
        if info then
            expect.field(info, "ip", "string", "number")
            expect.field(info, "netmask", "string", "number")
            t = {up = true}
            ipconfig[node.uuid] = t
            hardware.call(KERNEL, node, "open", 0)
        else return nil end
    end
    if info then
        expect.field(info, "ip", "string", "number", "nil")
        expect.field(info, "netmask", "string", "number", "nil")
        expect.field(info, "up", "boolean", "nil")
        local localRoute, broadcastRoute
        if t.ip then
            for _, v in ipairs(routes[0]) do
                if v.source == bit32.band(t.ip, t.netmask) and v.netmask == t.netmask then localRoute = v
                elseif v.source == bit32.bor(bit32.band(t.ip, t.netmask), bit32.bnot(t.netmask)) and v.netmask == 0xFFFFFFFF then broadcastRoute = v end
            end
        end
        if info.ip then
            if arptable[node.uuid] then arptable[node.uuid][t.ip] = nil end
            if type(info.ip) == "number" then t.ip = bit32.band(info.ip, 0xFFFFFFFF)
            else t.ip = ipToNumber(info.ip) end
            if localRoute then localRoute.source = bit32.band(t.ip, t.netmask) end
            if broadcastRoute then broadcastRoute.source = bit32.bor(bit32.band(t.ip, t.netmask), bit32.bnot(t.netmask)) end
            arptable[node.uuid] = arptable[node.uuid] or {}
            arptable[node.uuid][t.ip] = os.computerID()
        end
        if info.netmask then
            if type(info.netmask) == "number" then t.netmask = prefixToMask(info.netmask)
            else t.netmask = ipToNumber(info.netmask) end
            if localRoute then localRoute.source = bit32.band(t.ip, t.netmask) end
            if broadcastRoute then broadcastRoute.source = bit32.bor(bit32.band(t.ip, t.netmask), bit32.bnot(t.netmask)) end
        end
        if info.up ~= nil then
            t.up = info.up
            if t.up then hardware.call(KERNEL, node, "open", 0)
            else hardware.call(KERNEL, node, "close", 0) end
        end
        if not localRoute then routes[0][#routes[0]+1] = {
            source = bit32.band(t.ip, t.netmask),
            sourceNetmask = t.netmask,
            action = "local",
            device = node
        } end
        if not broadcastRoute then routes[0][#routes[0]+1] = {
            source = bit32.bor(bit32.band(t.ip, t.netmask), bit32.bnot(t.netmask)),
            sourceNetmask = 0xFFFFFFFF,
            action = "broadcast",
            device = node
        } end
    end
    return {
        ip = numberToIP(t.ip),
        netmask = maskToPrefix(t.netmask),
        up = t.up
    }
end

function syscalls.routelist(process, thread, num)
    num = expect(1, num, "number", "nil") or 1
    expect.range(num, 0)
    if not routes[num] then return nil end
    local retval = {}
    for i, t in ipairs(routes[num]) do
        retval[i] = {
            source = numberToIP(t.source),
            sourceNetmask = maskToPrefix(t.sourceNetmask),
            action = t.action,
            device = t.device and hardware.path(t.device),
            destination = t.destination
        }
    end
    return retval
end

local actionNames = {unicast = true, broadcast = true, ["local"] = true, unreachable = true, prohibit = true, blackhole = true}

function syscalls.routeadd(process, thread, options)
    if process.user ~= "root" then error("Permission denied") end
    expect(1, options, "table")
    expect.field(options, "source", "string", "number")
    expect.field(options, "sourceNetmask", "string", "number")
    expect.field(options, "action", "string")
    expect.field(options, "device", "string", (options.action ~= "unicast" and options.action ~= "broadcast" and options.action ~= "local") and "nil" or nil)
    expect.field(options, "destination", "string", options.action ~= "unicast" and "nil" or nil)
    expect.range(expect.field(options, "table", "number", "nil") or 1, 1)
    options.table = options.table or 1
    if not actionNames[options.action] then error("bad field 'action' (invalid option '" .. options.action .. "')") end
    local t = {}
    if type(options.source) == "number" then t.source = bit32.band(options.source, 0xFFFFFFFF)
    else t.source = ipToNumber(options.source) end
    if type(options.sourceNetmask) == "number" then t.sourceNetmask = prefixToMask(options.sourceNetmask)
    else t.sourceNetmask = ipToNumber(options.sourceNetmask) end
    t.source = bit32.band(t.source, t.sourceNetmask)
    t.action = options.action
    t.device = options.device and checkModem(hardware.get(options.device))
    t.destination = options.destination and ipToNumber(options.destination)
    routes[options.table] = routes[options.table] or {}
    for _, v in ipairs(routes[options.table]) do if v.source == t.source and v.sourceNetmask == t.sourceNetmask then error("Route already exists") end end
    routes[options.table][#routes[options.table]+1] = t
end

function syscalls.routedel(process, thread, source, mask, num)
    if process.user ~= "root" then error("Permission denied") end
    expect(1, source, "string", "number")
    expect(2, mask, "string", "number")
    num = expect(3, num, "number", "nil") or 1
    expect.range(num, 1)
    if type(mask) == "number" then mask = prefixToMask(mask)
    else mask = ipToNumber(mask) end
    if type(source) == "number" then source = bit32.band(source, mask)
    else source = bit32.band(ipToNumber(source), mask) end
    if not routes[num] then error("Route table does not exist") end
    for i, v in ipairs(routes[num]) do if v.source == t.source and v.sourceNetmask == t.sourceNetmask then table.remove(routes[num], i) return end end
end

function syscalls.arplist(process, thread, device)
    expect(1, device, "string")
    local node = checkModem(hardware.get(device))
    return deepcopy(arptable[node.uuid] or {})
end

function syscalls.arpset(process, thread, device, ip, id)
    if process.user ~= "root" then error("Permission denied") end
    expect(1, device, "string")
    expect(2, ip, "string", "number")
    expect(3, id, "number")
    local node = checkModem(hardware.get(device))
    if type(ip) == "string" then ip = ipToNumber(ip)
    else ip = bit32.band(ip, 0xFFFFFFFF) end
    arptable[node.uuid] = arptable[node.uuid] or {}
    arptable[node.uuid][ip] = id
end

local controlNames = {ping = true, pong = true, unreachable = true, timeout = true}

function syscalls.netcontrol(process, thread, ip, typ, err)
    if process.user ~= "root" then error("Permission denied") end
    expect(1, ip, "string", "number")
    expect(2, typ, "string")
    expect(3, err, "string", "nil")
    if not controlNames[typ] then error("bad argument #2 (invalid option '" .. typ .. "')") end
    if type(ip) == "string" then ip = ipToNumber(ip)
    else ip = bit32.band(ip, 0xFFFFFFFF) end
    protocols.send.control({process = process}, ip, typ, err)
end

function syscalls.netevent(process, thread, state)
    if process.user ~= "root" then error("Permission denied") end
    expect(1, state, "boolean", "nil")
    if state == true then networkListeners[process] = function(message)
        process.eventQueue[#process.eventQueue+1] = {"network_event", deepcopy(message)}
        return true
    end elseif state == false then networkListeners[process] = nil end
    return networkListeners[process] ~= nil
end

function syscalls.checkuri(process, thread, uri)

end

function registerLoopback()
    local node = hardware.get("/lo")
    if node then
        ipconfig[node.uuid] = {ip = 0x7F000001, netmask = 0xFF000000, up = true}
        routes[0][#routes[0]+1] = {
            source = 0x7F000000,
            sourceNetmask = 0xFF000000,
            action = "local",
            device = node
        }
        routes[0][#routes[0]+1] = {
            source = 0x7FFFFFFF,
            sourceNetmask = 0xFFFFFFFF,
            action = "broadcast",
            device = node
        }
        arptable[node.uuid] = setmetatable({}, {__index = function() return os.computerID() end})
        syslog.log("Configured IP for loopback device")
    end
end


--#endregion

--#region 90-kmod.lua

function syscalls.listmodules()
    local retval = {}
    for k in pairs(modules) do retval[#retval+1] = k end
    return retval
end

-- TODO: Implement module dependencies
function syscalls.loadmodule(process, thread, path)
    expect(1, path, "string")
    if process.user ~= "root" then error("Could not load kernel module: Permission denied", 2) end
    local name = v:match "[^%.]+"
    syslog.log("Loading kernel module " .. name .. " from " .. path)
    local file, err = filesystem.open(KERNEL, path, "rb")
    if file then
        local data = file.readAll()
        file.close()
        local fn, err = load(data, "@" .. path)
        if fn then
            local ok, res = pcall(fn, path)
            if ok then modules[name] = res or true
            else syslog.log({level = "error"}, "Kernel module " .. name .. " threw an error:", res) end
        else syslog.log({level = "error"}, "Could not load " .. name .. ":", err) end
    else syslog.log({level = "error"}, "Could not open " .. path .. ":", err) end
end

-- This call doesn't really do much if the module doesn't use the modules table.
function syscalls.unloadmodule(process, thread, name)
    expect(1, name, "string")
    if process.user ~= "root" then error("Could not load kernel module: Permission denied", 2) end
    if type(modules[name]) == "table" and modules[name].unload then modules[name].unload(process, thread) end
    modules[name] = nil
end

function syscalls.callmodule(process, thread, name, func, ...)
    expect(1, name, "string")
    expect(2, func, "string")
    if not modules[name] then error("Module '" .. name .. "' does not exist", 2)
    elseif type(modules[name]) ~= "table" then error("Module '" .. name .. "' does not have a callable interface", 2)
    elseif type(modules[name][func]) ~= "function" then error("Module '" .. name .. "' does not have a method '" .. func .. "'", 2) end
    return modules[name][func](process, thread, ...)
end

syslog.log("Loading kernel modules from /lib/modules")
local ok, modlist = pcall(filesystem.list, KERNEL, "/lib/modules")
if ok then
    for _, v in ipairs(modlist) do
        syscalls.loadmodule(KERNEL, nil, filesystem.combine("/lib/modules", v))
    end
else syslog.log({level = "notice"}, "Could not open /lib/modules:", modlist) end


--#endregion

--#region 99-main.lua

-- The device tree is initialized only once all kernel modules are fully loaded to avoid losses
hardware.register(deviceTreeRoot, rootDriver)
local empty_packed_table = {n = 0}
local init_process = processes[syscalls.fork(KERNEL, nil, function() end, "init")]
local init_pid = init_process.id
local init_ok, init_err
if args.init then
    init_ok, init_err = pcall(syscalls.exec, init_process, nil, args.init)
end
if not init_ok then
    syslog.log({level = "error", process = 0}, "Could not load init:", init_err)
    syslog.log("Could not find provided init, trying default locations")
    for _,v in ipairs{"/sbin/init", "/etc/init", "/bin/init", "/bin/sh"} do
        syslog.log("Trying", v)
        init_ok, init_err = pcall(syscalls.exec, init_process, nil, v)
        if not init_ok then syslog.log({level = "error", process = 0}, "Could not load init:", init_err) end
        if init_ok then break end
    end
    if not init_ok then panic("No working init found") end
end
syslog.log("Starting init from " .. processes[init_pid].name)
local allWaiting = false

-- Basic built-in debugger for testing
-- TODO: Improve this A LOT!
eventHooks.key = eventHooks.key or {}
eventHooks.key[#eventHooks.key+1] = function(ev)
    if keysHeld.ctrl and keysHeld.shift and ev[2] == keys.f10 then
        term.clear()
        term.setCursorPos(1, 1)
        term.write("Entering debug console.")
        local y = 2
        local running = true
        term.setCursorPos(1, y)
        while running do
            local line = ""
            local w, h = term.getSize()
            term.write("lua> ")
            term.setCursorBlink(true)
            while true do
                local ev = {coroutine.yield()}
                if ev[1] == "char" or ev[1] == "paste" then
                    line = line .. ev[2]
                    term.write(ev[2])
                elseif ev[1] == "key" then
                    if ev[2] == keys.backspace and #line > 0 then -- backspace
                        line = line:sub(1, -2)
                        term.setCursorPos(term.getCursorPos() - 1, y)
                        term.write(" ")
                        term.setCursorPos(term.getCursorPos() - 1, y)
                    elseif ev[2] == keys.enter then -- enter
                        break
                    end
                end
            end
            y = y + 1
            if y > h then
                y = y - 1
                term.scroll(1)
            end
            term.setCursorPos(1, y)
            local fn, err = load("return " .. line, "=lua", "t", setmetatable({exit = function() running = false end}, {__index = _G}))
            if not fn then fn, err = load(line, "=lua", "t", setmetatable({exit = function() running = false end}, {__index = _G})) end
            if fn then
                local res = table.pack(pcall(fn))
                if res[1] then
                    for i = 2, res.n do
                        term.write(tostring(res[i]))
                        y = y + 1
                        if y > h then
                            y = y - 1
                            term.scroll(1)
                        end
                        term.setCursorPos(1, y)
                    end
                else
                    term.setTextColor(16384)
                    term.write(res[2])
                    term.setTextColor(1)
                    y = y + 1
                    if y > h then
                        y = y - 1
                        term.scroll(1)
                    end
                    term.setCursorPos(1, y)
                end
            else
                term.setTextColor(16384)
                term.write(err)
                term.setTextColor(1)
                y = y + 1
                if y > h then
                    y = y - 1
                    term.scroll(1)
                end
                term.setCursorPos(1, y)
            end
        end
        term.setCursorBlink(false)
        term.clear()
        terminal.redraw(currentTTY, true)
    end
end

local ttyEvents = {char = true, key = true, key_up = true, mouse_click = true, mouse_up = true, mouse_drag = true, mouse_scroll = true, paste = true}

local ok, err = xpcall(function()
while processes[init_pid] do
    if not allWaiting then os.queueEvent("__event_queue_back") end
    while true do
        local ev = table.pack(coroutine.yield())
        local name = ev[1]
        if name == "__event_queue_back" then break end
        local pushedEvent = false
        if eventHooks[name] then for _, v in ipairs(eventHooks[name]) do pushedEvent = v(ev) or pushedEvent end end
        if eventParameterMap[name] then
            local params = {}
            for i = 2, #eventParameterMap[name] + 1 do
                params[eventParameterMap[name][i-1]] = ev[i]
            end
            if name == "key" or name == "key_up" then
                params.keycode = keymap[params.keycode]
                params.ctrlHeld = keysHeld.ctrl
                params.altHeld = keysHeld.alt
                params.shiftHeld = keysHeld.shift
            end
            if ttyEvents[name] and currentTTY.frontmostProcess then
                currentTTY.frontmostProcess.eventQueue[#currentTTY.frontmostProcess.eventQueue+1] = {name, params}
                pushedEvent = true
            elseif name == "timer" or name == "alarm" then
                local proc
                if name == "timer" then proc = timerMap[ev[2]]
                else proc, params.id = alarmMap[ev[2]], bit32.bor(params.id, 0x80000000) end
                if proc then proc.eventQueue[#proc.eventQueue+1], pushedEvent = {name, params}, true end
            -- TODO: check more events
            end
        end
        if allWaiting and pushedEvent then break end
    end
    allWaiting = true
    for pid, process in pairs(processes) do if pid ~= 0 and not process.paused then
        local gotev, ev = false, nil
        local dead = true
        for tid, thread in pairs(process.threads) do
            if not gotev and thread.status == "suspended" then
                ev = table.remove(process.eventQueue, 1) -- TODO: decide whether to optimize this
                gotev = true
            end
            if ev or thread.status ~= "suspended" then
                dead, allWaiting = executeThread(process, thread, ev or empty_packed_table, dead, allWaiting)
            else dead = false end
        end
        if dead then
            process.isDead = true
            if pid == init_pid then
                init_retval = process.lastReturnValue.value or process.lastReturnValue.error
            elseif processes[process.parent] then
                process.lastReturnValue.id = pid
                processes[process.parent].eventQueue[#processes[process.parent].eventQueue+1] = {"process_complete", process.lastReturnValue}
            end
            reap_process(process)
            processes[pid] = nil
            allWaiting = false
        end
    end end
    --if processes[init_pid].paused then panic("init program paused") end
    terminal.redraw(currentTTY)
end
end, debug.traceback)
if not ok then syslog.log({level = "critical", traceback = true}, err) end

--#endregion



if init_retval ~= nil then
    syslog.log({level = 4}, "init exited with result", init_retval)
end
panic("init program exited")
